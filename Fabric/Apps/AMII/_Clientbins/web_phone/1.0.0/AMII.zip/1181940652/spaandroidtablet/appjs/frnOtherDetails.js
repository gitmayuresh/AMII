define("frnOtherDetails", function() {
    return function(controller) {
        function addWidgetsfrnOtherDetails() {
            this.setDefaultUnit(voltmx.flex.DP);
            var segHeader = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "5%",
                "id": "segHeader",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": "fcMainheader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "FlexContainer0f9a5d5a46d0045": "FlexContainer0f9a5d5a46d0045",
                    "FlexContainer0i002cdfd3b8f4c": "FlexContainer0i002cdfd3b8f4c",
                    "Label0gf45b249bf6445": "Label0gf45b249bf6445",
                    "btnHeaderBack": "btnHeaderBack",
                    "btnHeaderNext": "btnHeaderNext",
                    "fcMainheader": "fcMainheader",
                    "lblHeader": "lblHeader"
                },
                "width": "100%",
                "appName": "AMII"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var fcMain = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "85%",
                "id": "fcMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMain.setDefaultUnit(voltmx.flex.DP);
            var fcLeftPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcLeftPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknfclightGreyborder",
                "top": "0%",
                "width": "33%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcLeftPane.setDefaultUnit(voltmx.flex.DP);
            var fcPatient = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPatient",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f464e035505d489389d47c4d464b592a,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPatient.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0fecbd5d4f3644c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "FlexContainer0fecbd5d4f3644c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0fecbd5d4f3644c.setDefaultUnit(voltmx.flex.DP);
            var lblPatientNav = new voltmx.ui.Label({
                "id": "lblPatientNav",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Patient Data",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            FlexContainer0fecbd5d4f3644c.add(lblPatientNav, lblErrorMsg);
            fcPatient.add(FlexContainer0fecbd5d4f3644c);
            var fcTreatment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcTreatment",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i70875f94cb74a4b8b0580756f29d81c,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTreatment.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0df4325fbec3c44 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0df4325fbec3c44",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0df4325fbec3c44.setDefaultUnit(voltmx.flex.DP);
            var lblTreatmentScreen = new voltmx.ui.Label({
                "id": "lblTreatmentScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Treatment Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblTreatmentErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblTreatmentErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0df4325fbec3c44.add(lblTreatmentScreen, lblTreatmentErrorMsg);
            fcTreatment.add(CopyFlexContainer0df4325fbec3c44);
            var fcOther = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcOther",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcselectedButton",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOther.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0a75a811f614948 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0a75a811f614948",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0a75a811f614948.setDefaultUnit(voltmx.flex.DP);
            var lblOtherScreen = new voltmx.ui.Label({
                "id": "lblOtherScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Other Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblOtherErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblOtherErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0a75a811f614948.add(lblOtherScreen, lblOtherErrorMsg);
            var FlexContainer0b0b44683307d49 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0",
                "centerY": "50%",
                "clipBounds": false,
                "id": "FlexContainer0b0b44683307d49",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "width": "11%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0b0b44683307d49.setDefaultUnit(voltmx.flex.DP);
            var imgArrow = new voltmx.ui.Image2({
                "height": "100%",
                "id": "imgArrow",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "arrow_blue.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0b0b44683307d49.add(imgArrow);
            fcOther.add(CopyFlexContainer0a75a811f614948, FlexContainer0b0b44683307d49);
            var fcPostTX = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPostTX",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_c346d538a39e4962b24828ce1245b1c3,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPostTX.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0f6b7a0518ac744 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0f6b7a0518ac744",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0f6b7a0518ac744.setDefaultUnit(voltmx.flex.DP);
            var lblPostTxScreen = new voltmx.ui.Label({
                "id": "lblPostTxScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Post Treatment",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblPostTxErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblPostTxErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0f6b7a0518ac744.add(lblPostTxScreen, lblPostTxErrormsg);
            fcPostTX.add(CopyFlexContainer0f6b7a0518ac744);
            var fcACOI = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcACOI",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_g526b15a94a44d3c87a2f5a9497ee978,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcACOI.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0e24933d63b4840 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0e24933d63b4840",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0e24933d63b4840.setDefaultUnit(voltmx.flex.DP);
            var lblACOIDetails = new voltmx.ui.Label({
                "id": "lblACOIDetails",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "ACOI Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblAcoiErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblAcoiErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0e24933d63b4840.add(lblACOIDetails, lblAcoiErrormsg);
            fcACOI.add(CopyFlexContainer0e24933d63b4840);
            fcLeftPane.add(fcPatient, fcTreatment, fcOther, fcPostTX, fcACOI);
            var fcRightPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcRightPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknfcrightPane",
                "top": "0%",
                "width": "66%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRightPane.setDefaultUnit(voltmx.flex.DP);
            var fcTwo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": false,
                "height": "100px",
                "id": "fcTwo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "top": "20px",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTwo.setDefaultUnit(voltmx.flex.DP);
            var lblPatientNameCaptured = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPatientNameCaptured",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Patient Name:",
                "textStyle": {},
                "width": "27%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblCapturedPatientName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblCapturedPatientName",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            fcTwo.add(lblPatientNameCaptured, lblCapturedPatientName);
            var fcOne = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcOne",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOne.setDefaultUnit(voltmx.flex.DP);
            var fscOtherDetails = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "fscOtherDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "minHeight": "900px",
                "pagingEnabled": false,
                "right": "0%",
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "noSkinFcScrollbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "96%"
            }, {
                "paddingInPixel": false
            }, {});
            fscOtherDetails.setDefaultUnit(voltmx.flex.DP);
            var fcNursingService = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcNursingService",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcNursingService.setDefaultUnit(voltmx.flex.DP);
            var lblNursingService = new voltmx.ui.Label({
                "bottom": 0,
                "id": "lblNursingService",
                "isVisible": true,
                "left": "0dp",
                "right": 0,
                "skin": "sknlblGreyFont80",
                "text": "Nursing Service",
                "textStyle": {},
                "top": "0",
                "width": "53%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbNursingSvc = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbNursingSvc",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "47%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcNursingService.add(lblNursingService, cmbNursingSvc);
            var fcNursingHrs = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcNursingHrs",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcNursingHrs.setDefaultUnit(voltmx.flex.DP);
            var lblLNursingHrs = new voltmx.ui.Label({
                "id": "lblLNursingHrs",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Nursing Minutes",
                "textStyle": {},
                "top": "0",
                "width": "53%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbNursinghrs = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbNursinghrs",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["null", "Please Select..."],
                    ["00", "00"],
                    ["15", "15"],
                    ["30", "30"],
                    ["45", "45"],
                    ["60", "60"],
                    ["75", "75"],
                    ["90", "90"],
                    ["105", "105"],
                    ["120", "120"],
                    ["135", "135"],
                    ["150", "150"],
                    ["165", "165"],
                    ["180", "180"],
                    ["195", "195"],
                    ["210", "210"],
                    ["225", "225"],
                    ["240", "240"]
                ],
                "selectedKey": "null",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "47%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcNursingHrs.add(lblLNursingHrs, cmbNursinghrs);
            var fcAdditionalSvc = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcAdditionalSvc",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcAdditionalSvc.setDefaultUnit(voltmx.flex.DP);
            var lblAdditionalServ = new voltmx.ui.Label({
                "id": "lblAdditionalServ",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Additional Services",
                "textStyle": {},
                "top": "0",
                "width": "53%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbAdditionalSvc = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbAdditionalSvc",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "47%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcAdditionalSvc.add(lblAdditionalServ, cmbAdditionalSvc);
            var fcDialysate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcDialysate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcDialysate.setDefaultUnit(voltmx.flex.DP);
            var lblDialysate = new voltmx.ui.Label({
                "id": "lblDialysate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Dialysate",
                "textStyle": {},
                "top": "0",
                "width": "53%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbDialysate = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbDialysate",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "47%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcDialysate.add(lblDialysate, cmbDialysate);
            var fcBloodAdmin = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcBloodAdmin",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcBloodAdmin.setDefaultUnit(voltmx.flex.DP);
            var lblBloodAdmin = new voltmx.ui.Label({
                "id": "lblBloodAdmin",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "# of Blood Administrations",
                "textStyle": {},
                "top": "0",
                "width": "53%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbBloodAdmin = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbBloodAdmin",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["null", "Please Select..."],
                    ["1", "1"],
                    ["2", "2"],
                    ["3", "3"],
                    ["4", "4"],
                    ["5", "5"],
                    ["6", "6"],
                    ["7", "7"],
                    ["8", "8"],
                    ["9", "9"],
                    ["10", "10"],
                    ["11", "11"],
                    ["12", "12"],
                    ["13", "13"],
                    ["14", "14"],
                    ["15", "15"],
                    ["16", "16"],
                    ["17", "17"],
                    ["18", "18"],
                    ["19", "19"],
                    ["20", "20"]
                ],
                "selectedKey": "null",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "47%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcBloodAdmin.add(lblBloodAdmin, cmbBloodAdmin);
            var fcRemoveCVC = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcRemoveCVC",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRemoveCVC.setDefaultUnit(voltmx.flex.DP);
            var lblRemoveCVC = new voltmx.ui.Label({
                "id": "lblRemoveCVC",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Non-Tunneled Catheter Removal",
                "textStyle": {},
                "top": "0",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var rbtRemoveCVC = new voltmx.ui.RadioButtonGroup({
                "bottom": 1,
                "id": "rbtRemoveCVC",
                "isVisible": true,
                "left": 2,
                "masterData": [
                    ["1", "Yes"],
                    ["2", "No"]
                ],
                "right": 2,
                "skin": "sknradioblueborder",
                "top": 1,
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcRemoveCVC.add(lblRemoveCVC, rbtRemoveCVC);
            fscOtherDetails.add(fcNursingService, fcNursingHrs, fcAdditionalSvc, fcDialysate, fcBloodAdmin, fcRemoveCVC);
            fcOne.add(fscOtherDetails);
            fcRightPane.add(fcTwo, fcOne);
            fcMain.add(fcLeftPane, fcRightPane);
            var segFooter1 = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "data": [{
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }, {
                    "Label0b57e7188fec34d": "",
                    "btnDelete": "Delete",
                    "btnSave": "Save",
                    "btnSubmit": "Submit",
                    "btnSubmit2": "Button"
                }],
                "groupCells": false,
                "height": "10%",
                "id": "segFooter1",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "fcappFooter",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "FlexContainer0ac17401cea3043": "FlexContainer0ac17401cea3043",
                    "FlexContainer0eb12b1e1a9e845": "FlexContainer0eb12b1e1a9e845",
                    "FlexContainer0g87434182ad74c": "FlexContainer0g87434182ad74c",
                    "Label0b57e7188fec34d": "Label0b57e7188fec34d",
                    "btnDelete": "btnDelete",
                    "btnSave": "btnSave",
                    "btnSubmit": "btnSubmit",
                    "btnSubmit2": "btnSubmit2",
                    "fcappFooter": "fcappFooter"
                },
                "width": "100%",
                "appName": "AMII"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.add(segHeader, fcMain, segFooter1);
        };
        return [{
            "addWidgets": addWidgetsfrnOtherDetails,
            "enabledForIdleTimeout": false,
            "id": "frnOtherDetails",
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_j3415f20696a4aa8b9e951ab1d169356(eventobject);
            },
            "skin": "sknform",
            "appName": "AMII"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_BOTH,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});