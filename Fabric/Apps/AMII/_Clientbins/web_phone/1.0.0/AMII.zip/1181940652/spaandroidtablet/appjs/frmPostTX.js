define("frmPostTX", function() {
    return function(controller) {
        function addWidgetsfrmPostTX() {
            this.setDefaultUnit(voltmx.flex.DP);
            var fcMainHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "5%",
                "id": "fcMainHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcHeader",
                "top": "0",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMainHeader.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0ef6ae736d2ae45 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopyLabel0ef6ae736d2ae45",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblWhiteLogin",
                "text": "Acutes Charge Capture",
                "textStyle": {},
                "width": "33%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopyFlexContainer0c833ac39b80c4c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0c833ac39b80c4c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcbluebgwithblackborder12",
                "top": "0",
                "width": "67%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0c833ac39b80c4c.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0h115220ee8cc4d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0h115220ee8cc4d",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "90%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0h115220ee8cc4d.setDefaultUnit(voltmx.flex.DP);
            var btnBack = new voltmx.ui.Button({
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "height": "80%",
                "id": "btnBack",
                "isVisible": true,
                "left": "0%",
                "onClick": controller.AS_Button_a02a2c736e89455b9d2cc7d350bc2ce3,
                "skin": "sknbtnback",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_appHeader_btnBack\")",
                "top": "0",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [3, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var CopylblHeader0b8ecf484c63746 = new voltmx.ui.Label({
                "id": "CopylblHeader0b8ecf484c63746",
                "isVisible": true,
                "skin": "sknlblWhiteLogin",
                "text": "Patient Data",
                "textStyle": {},
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopybtnHeaderNext0a87fde2554714c = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "80%",
                "id": "CopybtnHeaderNext0a87fde2554714c",
                "isVisible": true,
                "onClick": controller.AS_Button_d3e9d3055fba4da9b022ca14e7dd81cb,
                "skin": "sknbtnnext",
                "text": "Next",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [3, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0h115220ee8cc4d.add(btnBack, CopylblHeader0b8ecf484c63746, CopybtnHeaderNext0a87fde2554714c);
            CopyFlexContainer0c833ac39b80c4c.add(CopyFlexContainer0h115220ee8cc4d);
            fcMainHeader.add(CopyLabel0ef6ae736d2ae45, CopyFlexContainer0c833ac39b80c4c);
            var fcMain = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "95%",
                "id": "fcMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "5%",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMain.setDefaultUnit(voltmx.flex.DP);
            var fcLeftPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcLeftPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfclightGreyborder",
                "top": 0,
                "width": "33%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcLeftPane.setDefaultUnit(voltmx.flex.DP);
            var fcPatient = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPatient",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_eab2cd76af4040879d8a3eeebb5cdfb2,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPatient.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0fecbd5d4f3644c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "FlexContainer0fecbd5d4f3644c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0fecbd5d4f3644c.setDefaultUnit(voltmx.flex.DP);
            var lblPatientNav = new voltmx.ui.Label({
                "id": "lblPatientNav",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Patient Data",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            FlexContainer0fecbd5d4f3644c.add(lblPatientNav, lblErrorMsg);
            fcPatient.add(FlexContainer0fecbd5d4f3644c);
            var fcTreatment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcTreatment",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_a5fa8524bc66444d9fc4f1011688383d,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTreatment.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0df4325fbec3c44 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0df4325fbec3c44",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0df4325fbec3c44.setDefaultUnit(voltmx.flex.DP);
            var lblTreatmentScreen = new voltmx.ui.Label({
                "id": "lblTreatmentScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Treatment Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblTreatmentErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblTreatmentErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0df4325fbec3c44.add(lblTreatmentScreen, lblTreatmentErrorMsg);
            fcTreatment.add(CopyFlexContainer0df4325fbec3c44);
            var fcOther = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcOther",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d21c8db1c2464ef485c4a3142d26d089,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOther.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0a75a811f614948 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0a75a811f614948",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0a75a811f614948.setDefaultUnit(voltmx.flex.DP);
            var lblOtherScreen = new voltmx.ui.Label({
                "id": "lblOtherScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Other Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblOtherErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblOtherErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0a75a811f614948.add(lblOtherScreen, lblOtherErrorMsg);
            fcOther.add(CopyFlexContainer0a75a811f614948);
            var fcPostTX = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPostTX",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcselectedButton",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPostTX.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0f6b7a0518ac744 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0f6b7a0518ac744",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0f6b7a0518ac744.setDefaultUnit(voltmx.flex.DP);
            var lblPostTxScreen = new voltmx.ui.Label({
                "id": "lblPostTxScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Post Treatment",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblPostTxErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblPostTxErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0f6b7a0518ac744.add(lblPostTxScreen, lblPostTxErrormsg);
            var FlexContainer0b0b44683307d49 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0",
                "centerY": "50%",
                "clipBounds": false,
                "id": "FlexContainer0b0b44683307d49",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "width": "11%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0b0b44683307d49.setDefaultUnit(voltmx.flex.DP);
            var imgArrow = new voltmx.ui.Image2({
                "height": "100%",
                "id": "imgArrow",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "arrow_blue.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0b0b44683307d49.add(imgArrow);
            fcPostTX.add(CopyFlexContainer0f6b7a0518ac744, FlexContainer0b0b44683307d49);
            var fcACOI = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcACOI",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_db5d81a515ab4f6ea151ebc0a97f8307,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcACOI.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0e24933d63b4840 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0e24933d63b4840",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0e24933d63b4840.setDefaultUnit(voltmx.flex.DP);
            var lblACOIDetails = new voltmx.ui.Label({
                "id": "lblACOIDetails",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "ACOI Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblAcoiErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblAcoiErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0e24933d63b4840.add(lblACOIDetails, lblAcoiErrormsg);
            fcACOI.add(CopyFlexContainer0e24933d63b4840);
            fcLeftPane.add(fcPatient, fcTreatment, fcOther, fcPostTX, fcACOI);
            var fcRightPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcRightPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0",
                "skin": "sknfcrightPane",
                "top": "0dp",
                "width": "66%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRightPane.setDefaultUnit(voltmx.flex.DP);
            var fcTwo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": false,
                "height": "100px",
                "id": "fcTwo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "top": "20px",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTwo.setDefaultUnit(voltmx.flex.DP);
            var lblPatientNameCaptured = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPatientNameCaptured",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Patient Name:",
                "textStyle": {},
                "width": "27%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblCapturedPatientName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblCapturedPatientName",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            fcTwo.add(lblPatientNameCaptured, lblCapturedPatientName);
            var fcOne = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcOne",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOne.setDefaultUnit(voltmx.flex.DP);
            var fcPatientDetails = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcPatientDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "right": "1%",
                "skin": "CopynoSkinFcScrollbox0e0346b2d641e4d",
                "top": "0dp",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPatientDetails.setDefaultUnit(voltmx.flex.DP);
            var fcDialyzer = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcDialyzer",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcDialyzer.setDefaultUnit(voltmx.flex.DP);
            var lblDialyser = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblDialyser",
                "isVisible": true,
                "left": 0,
                "skin": "sknlblGreyFont80",
                "text": "Additional Dialyzer/Cartridge",
                "textStyle": {},
                "width": "54%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbDialiser = new voltmx.ui.ListBox({
                "bottom": 0,
                "focusSkin": "defListBoxFocus",
                "id": "cmbDialiser",
                "isVisible": true,
                "left": 0,
                "masterData": [
                    ["null", "Please Select..."],
                    ["0", "None"],
                    ["1", "1"],
                    ["2", "2"],
                    ["3", "3"],
                    ["4", "4"]
                ],
                "right": 0,
                "selectedKey": "null",
                "skin": "skncmbWhiteBG",
                "top": 0,
                "width": "46%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcDialyzer.add(lblDialyser, cmbDialiser);
            var fcTimeDelay = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcTimeDelay",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTimeDelay.setDefaultUnit(voltmx.flex.DP);
            var lblTimedelay = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblTimedelay",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Wait Time",
                "textStyle": {},
                "width": "54%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbTimeDelay = new voltmx.ui.ListBox({
                "bottom": 0,
                "focusSkin": "defListBoxFocus",
                "id": "cmbTimeDelay",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["null", "Please Select..."],
                    ["00", "00"],
                    ["15", "15"],
                    ["30", "30"],
                    ["45", "45"],
                    ["60", "60"],
                    ["75", "75"],
                    ["90", "90"],
                    ["105", "105"],
                    ["120", "120"],
                    ["135", "135"],
                    ["150", "150"],
                    ["165", "165"],
                    ["180", "180"],
                    ["195", "195"],
                    ["210", "210"],
                    ["225", "225"],
                    ["240", "240"]
                ],
                "right": 0,
                "selectedKey": "null",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "46%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcTimeDelay.add(lblTimedelay, cmbTimeDelay);
            fcPatientDetails.add(fcDialyzer, fcTimeDelay);
            fcOne.add(fcPatientDetails);
            var fcFour = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcFour",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcFour.setDefaultUnit(voltmx.flex.DP);
            var fcVFour = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcVFour",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "right": "1%",
                "skin": "noSkinFC",
                "top": "0",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcVFour.setDefaultUnit(voltmx.flex.DP);
            var fcEndTreatment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcEndTreatment",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcEndTreatment.setDefaultUnit(voltmx.flex.DP);
            var btnEndTreatment = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "id": "btnEndTreatment",
                "isVisible": true,
                "skin": "startBtnBlue",
                "text": "End Treatment",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [1, 3, 1, 3],
                "paddingInPixel": false
            }, {});
            var lblEndTreatmentInfoText = new voltmx.ui.Label({
                "id": "lblEndTreatmentInfoText",
                "isVisible": true,
                "skin": "sknlblGreyFont80NoBorder",
                "text": "Tap button to pre-populate date and time.",
                "textStyle": {},
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            fcEndTreatment.add(btnEndTreatment, lblEndTreatmentInfoText);
            var CopylblCurDate0e5f2b6571e5641 = new voltmx.ui.Label({
                "id": "CopylblCurDate0e5f2b6571e5641",
                "isVisible": true,
                "left": "0",
                "skin": "lblNormal",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopylblCurTime0ef92efea667942 = new voltmx.ui.Label({
                "id": "CopylblCurTime0ef92efea667942",
                "isVisible": true,
                "left": "0",
                "skin": "lblNormal",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var fcTreatmentEnd = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcTreatmentEnd",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTreatmentEnd.setDefaultUnit(voltmx.flex.DP);
            var lblTretEnd = new voltmx.ui.Label({
                "id": "lblTretEnd",
                "isVisible": true,
                "skin": "sknlblTreatTypedisable",
                "text": "Treatment End",
                "textStyle": {},
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtTreatEnddate = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtTreatEnddate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "text": "MM/DD/YYYY",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "59%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var calTreatmentEnd = new voltmx.ui.Calendar({
                "calendarIcon": "calbtn.png",
                "dateComponents": [null, null, null],
                "dateFormat": "MM/dd/yyyy",
                "hour": 0,
                "id": "calTreatmentEnd",
                "isVisible": true,
                "minutes": 0,
                "seconds": 0,
                "skin": "skncalWhitefont",
                "viewType": constants.CALENDAR_VIEW_TYPE_GRID_ONSCREEN,
                "width": "6%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcTreatmentEnd.add(lblTretEnd, txtTreatEnddate, calTreatmentEnd);
            var fcEndTime = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcEndTime",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcEndTime.setDefaultUnit(voltmx.flex.DP);
            var lblEndTime = new voltmx.ui.Label({
                "id": "lblEndTime",
                "isVisible": true,
                "skin": "sknlblTreatTypedisable",
                "text": "End Time",
                "textStyle": {},
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtEndTime = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtEndTime",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "text": "Hh:mm",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "59%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var calEndTime = new voltmx.ui.Calendar({
                "calendarIcon": "icon_clock.png",
                "dateComponents": [null, null, null],
                "dateFormat": "MM/dd/yyyy",
                "hour": 0,
                "id": "calEndTime",
                "isVisible": true,
                "minutes": 0,
                "seconds": 0,
                "skin": "skncalWhitefont",
                "viewType": constants.CALENDAR_VIEW_TYPE_GRID_ONSCREEN,
                "width": "6%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcEndTime.add(lblEndTime, txtEndTime, calEndTime);
            fcVFour.add(fcEndTreatment, CopylblCurDate0e5f2b6571e5641, CopylblCurTime0ef92efea667942, fcTreatmentEnd, fcEndTime);
            fcFour.add(fcVFour);
            var fcFive = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcFive",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcFive.setDefaultUnit(voltmx.flex.DP);
            var fcVFive = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcVFive",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "right": "1%",
                "skin": "noSkinFC",
                "top": "0",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcVFive.setDefaultUnit(voltmx.flex.DP);
            var fcPostTretHospital = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPostTretHospital",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": 1,
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPostTretHospital.setDefaultUnit(voltmx.flex.DP);
            var lblPostTreatment = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPostTreatment",
                "isVisible": true,
                "skin": "sknlblGreyFont80",
                "text": "Post Treatment Report to Hospital RN",
                "textStyle": {},
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var rbtPediatricPOst = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtPediatricPOst",
                "isVisible": true,
                "masterData": [
                    ["1", "Yes"],
                    ["2", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcPostTretHospital.add(lblPostTreatment, rbtPediatricPOst);
            fcVFive.add(fcPostTretHospital);
            fcFive.add(fcVFive);
            var fcSix = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcSix",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcSix.setDefaultUnit(voltmx.flex.DP);
            var fcVSix = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcVSix",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "right": "1%",
                "skin": "noSkinFC",
                "top": "0",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcVSix.setDefaultUnit(voltmx.flex.DP);
            var fcComments = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcComments",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": 1,
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcComments.setDefaultUnit(voltmx.flex.DP);
            var lblComments = new voltmx.ui.Label({
                "height": "120px",
                "id": "lblComments",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Comments",
                "textStyle": {},
                "top": "0",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            fcComments.add(lblComments);
            var fcCommentsArea = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcCommentsArea",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": 1,
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcCommentsArea.setDefaultUnit(voltmx.flex.DP);
            var txaComments = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_SENTENCES,
                "focusSkin": "defTextAreaFocus",
                "id": "txaComments",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "numberOfVisibleLines": 3,
                "placeholder": "Wait Time & Nursing Service requires comments.",
                "skin": "skntxtareaWtBG",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": true,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            fcCommentsArea.add(txaComments);
            fcVSix.add(fcComments, fcCommentsArea);
            fcSix.add(fcVSix);
            fcRightPane.add(fcTwo, fcOne, fcFour, fcFive, fcSix);
            fcMain.add(fcLeftPane, fcRightPane);
            this.add(fcMainHeader, fcMain);
        };
        return [{
            "addWidgets": addWidgetsfrmPostTX,
            "enabledForIdleTimeout": false,
            "id": "frmPostTX",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknform",
            "appName": "AMII"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_BOTH,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});