define("userfrmHomeController", {
    onFormHomePreShow: function(context) {
        this.view.lblNurseUserName.text = "Welcome " + gblNurseDescription + " !";
        var records = [];
        var record1 = {
            "FirstName": "FirstName1",
            "LastName": "LastName1",
            "MedicalRecordNumber": "MRN1"
        };
        records.push(record1);
        var record2 = {
            "FirstName": "FirstName2",
            "LastName": "LastName2",
            "MedicalRecordNumber": "MRN2"
        };
        records.push(record2);
        records.push(record2);
        records.push(record2);
        records.push(record2);
        this.populateTreatments("segSavedTreatments", records, this.view);
        this.populateTreatments("segWaitingTransmit", records, this.view);
    },
    populateTreatments: function(segmentName, records, targetform) {
        var tempCollection = [];
        for (var i in records) {
            tempCollection.push({
                "lblSavedLastName": {
                    "text": records[i]["LastName"]
                },
                "lblSavedFirstName": {
                    "text": records[i]["FirstName"]
                },
                "lblSavedMedRecordNum": {
                    "text": records[i]["MedicalRecordNumber"]
                }
            });
        }
        voltmx.print("populateTreatments" + JSON.stringify(tempCollection));
        targetform[segmentName].setData(tempCollection);
        // Print the segment data
        var segmentData = targetform[segmentName].data;
        voltmx.print("Segment Data: " + JSON.stringify(segmentData));
    }
});
define("frmHomeControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_jcd29a3920f8497fad00fb728a98790d: function AS_Button_jcd29a3920f8497fad00fb728a98790d(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPatientDetails"
        });
        ntf.navigate();
    },
    AS_Form_df5bc4c27ed64d5092bae578211499d5: function AS_Form_df5bc4c27ed64d5092bae578211499d5(eventobject) {
        var self = this;
        voltmx.print("Inside Postshow");
    },
    AS_Form_dcc0d3087f7e4c4683b1f14b4d3d2b9b: function AS_Form_dcc0d3087f7e4c4683b1f14b4d3d2b9b(eventobject) {
        var self = this;
        voltmx.print("Inside Preshow");
        self.onFormHomePreShow.call(this, null);
    }
});
define("frmHomeController", ["userfrmHomeController", "frmHomeControllerActions"], function() {
    var controller = require("userfrmHomeController");
    var controllerActions = ["frmHomeControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
