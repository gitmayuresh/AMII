define('applicationController',{
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_AppEvents_ee6262c4ea29492a81ea6b7c24070edc: function AS_AppEvents_ee6262c4ea29492a81ea6b7c24070edc(eventobject) {
        var self = this;
        voltmx.print("Inside PostApppinit");
        syncSetup.call(this);
    },
    AS_AppEvents_j212417fb00d4c46a546f7fc6d65e280: function AS_AppEvents_j212417fb00d4c46a546f7fc6d65e280(eventobject) {
        var self = this;
        voltmx.print("Inside PreApppinit");
    },
    appInit: function(params) {
        skinsInit();
        voltmx.mvc.registry.add("flxSampleRowTemplate", {
            "viewName": "flxSampleRowTemplate",
            "controllerName": "flxSampleRowTemplateController"
        });
        voltmx.mvc.registry.add("Flex0d798b50aa6d145", {
            "viewName": "Flex0d798b50aa6d145",
            "controllerName": "Flex0d798b50aa6d145Controller"
        });
        voltmx.mvc.registry.add("fcappFooter", {
            "viewName": "fcappFooter",
            "controllerName": "fcappFooterController"
        });
        voltmx.mvc.registry.add("fcMainheader", {
            "viewName": "fcMainheader",
            "controllerName": "fcMainheaderController"
        });
        voltmx.mvc.registry.add("frmHome", {
            "viewName": "frmHome",
            "controllerName": "frmHomeController"
        });
        voltmx.mvc.registry.add("frmLogin", {
            "viewName": "frmLogin",
            "controllerName": "frmLoginController"
        });
        voltmx.mvc.registry.add("frmPatientDetails", {
            "viewName": "frmPatientDetails",
            "controllerName": "frmPatientDetailsController"
        });
        voltmx.mvc.registry.add("frmPostTX", {
            "viewName": "frmPostTX",
            "controllerName": "frmPostTXController"
        });
        voltmx.mvc.registry.add("frmTreatmentDetails", {
            "viewName": "frmTreatmentDetails",
            "controllerName": "frmTreatmentDetailsController"
        });
        voltmx.mvc.registry.add("frnACOI", {
            "viewName": "frnACOI",
            "controllerName": "frnACOIController"
        });
        voltmx.mvc.registry.add("frnOtherDetails", {
            "viewName": "frnOtherDetails",
            "controllerName": "frnOtherDetailsController"
        });
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {
        return applicationController.AS_AppEvents_ee6262c4ea29492a81ea6b7c24070edc(eventObj);
    },
    appmenuseq: function() {
        new voltmx.mvc.Navigation("frmHome").navigate();
    }
});

define("CopyFBox0e0feafe301d842", [],function() {
    return function(controller) {
        CopyFBox0e0feafe301d842 = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "height": "preferred",
            "id": "CopyFBox0e0feafe301d842",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "isModalContainer": false,
            "skin": "s0543c955be246b9a86c01fc43bdee9b",
            "width": "100%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        CopyFBox0e0feafe301d842.setDefaultUnit(voltmx.flex.DP);
        var lblSavedLastName = new voltmx.ui.Label({
            "id": "lblSavedLastName",
            "isVisible": true,
            "left": "0",
            "skin": "defLabel",
            "text": "Label",
            "textStyle": {},
            "top": "0",
            "width": "30%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var lblSavedFirstName = new voltmx.ui.Label({
            "id": "lblSavedFirstName",
            "isVisible": true,
            "left": "0dp",
            "skin": "defLabel",
            "text": "Label",
            "textStyle": {},
            "top": "0",
            "width": "30%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var lblSavedMedRecordNum = new voltmx.ui.Label({
            "id": "lblSavedMedRecordNum",
            "isVisible": true,
            "left": "0",
            "skin": "defLabel",
            "text": "Label",
            "textStyle": {},
            "top": "0",
            "width": "30%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var btnEdit = new voltmx.ui.Button({
            "focusSkin": "defBtnFocus",
            "id": "btnEdit",
            "isVisible": true,
            "left": "1%",
            "right": "4%",
            "skin": "sknbtnEdit",
            "text": "Button",
            "top": "0",
            "width": "6%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "displayText": true,
            "padding": [0, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        CopyFBox0e0feafe301d842.add(lblSavedLastName, lblSavedFirstName, lblSavedMedRecordNum, btnEdit);
        return CopyFBox0e0feafe301d842;
    }
})
;
define("FBox0d3323315729948", [],function() {
    return function(controller) {
        FBox0d3323315729948 = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "height": "preferred",
            "id": "FBox0d3323315729948",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "100%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        FBox0d3323315729948.setDefaultUnit(voltmx.flex.DP);
        var lblsegHospdesc = new voltmx.ui.Label({
            "id": "lblsegHospdesc",
            "isVisible": true,
            "left": "0",
            "skin": "sknlblwelcomeLabel",
            "text": "Label",
            "textStyle": {},
            "top": "0",
            "width": voltmx.flex.USE_PREFERRED_SIZE
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 1, 1],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        FBox0d3323315729948.add(lblsegHospdesc);
        return FBox0d3323315729948;
    }
})
;
define("FBox0jce3a5b497b34e", [],function() {
    return function(controller) {
        FBox0jce3a5b497b34e = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "height": "preferred",
            "id": "FBox0jce3a5b497b34e",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "100%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        FBox0jce3a5b497b34e.setDefaultUnit(voltmx.flex.DP);
        var lblSavedLastName = new voltmx.ui.Label({
            "id": "lblSavedLastName",
            "isVisible": true,
            "left": "0",
            "skin": "defLabel",
            "text": "Label",
            "textStyle": {},
            "top": "0",
            "width": "30%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var lblSavedFirstName = new voltmx.ui.Label({
            "id": "lblSavedFirstName",
            "isVisible": true,
            "left": "0dp",
            "skin": "defLabel",
            "text": "Label",
            "textStyle": {},
            "top": "0",
            "width": "30%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var lblSavedMedRecordNum = new voltmx.ui.Label({
            "id": "lblSavedMedRecordNum",
            "isVisible": true,
            "left": "0",
            "skin": "defLabel",
            "text": "Label",
            "textStyle": {},
            "top": "0",
            "width": "30%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var btnEdit = new voltmx.ui.Button({
            "focusSkin": "defBtnFocus",
            "id": "btnEdit",
            "isVisible": true,
            "left": "1%",
            "right": "4%",
            "skin": "sknbtnEdit",
            "text": "Button",
            "top": "0",
            "width": "6%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "displayText": true,
            "padding": [0, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        FBox0jce3a5b497b34e.add(lblSavedLastName, lblSavedFirstName, lblSavedMedRecordNum, btnEdit);
        return FBox0jce3a5b497b34e;
    }
})
;
define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate",
            "width": "100%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.setDefaultUnit(voltmx.flex.DP);
        var lblHeading = new voltmx.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var lblDescription = new voltmx.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var lblTime = new voltmx.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": voltmx.flex.USE_PREFERRED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var lblStrip = new voltmx.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": voltmx.flex.USE_PREFERRED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("Flex0d798b50aa6d145", [],function() {
    return function(controller) {
        var Flex0d798b50aa6d145 = new voltmx.ui.FlexContainer({
            "clipBounds": false,
            "height": "80dp",
            "id": "Flex0d798b50aa6d145",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        Flex0d798b50aa6d145.setDefaultUnit(voltmx.flex.DP);
        Flex0d798b50aa6d145.add();
        return Flex0d798b50aa6d145;
    }
})
;
define("fcappFooter", [],function() {
    return function(controller) {
        var fcappFooter = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "fcappFooter",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        fcappFooter.setDefaultUnit(voltmx.flex.DP);
        var FlexContainer0ac17401cea3043 = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "id": "FlexContainer0ac17401cea3043",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0",
            "width": "100%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        FlexContainer0ac17401cea3043.setDefaultUnit(voltmx.flex.DP);
        var FlexContainer0eb12b1e1a9e845 = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": 100,
            "id": "FlexContainer0eb12b1e1a9e845",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0",
            "width": "33%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        FlexContainer0eb12b1e1a9e845.setDefaultUnit(voltmx.flex.DP);
        var Label0b57e7188fec34d = new voltmx.ui.Label({
            "centerY": "50%",
            "id": "Label0b57e7188fec34d",
            "isVisible": true,
            "left": 0,
            "skin": "defLabel",
            "textStyle": {},
            "width": voltmx.flex.USE_PREFERRED_SIZE
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        FlexContainer0eb12b1e1a9e845.add(Label0b57e7188fec34d);
        var FlexContainer0g87434182ad74c = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": 100,
            "id": "FlexContainer0g87434182ad74c",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0",
            "width": "66%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        FlexContainer0g87434182ad74c.setDefaultUnit(voltmx.flex.DP);
        var btnSave = new voltmx.ui.Button({
            "bottom": "1%",
            "centerY": "50%",
            "focusSkin": "defBtnFocus",
            "id": "btnSave",
            "isVisible": true,
            "left": "3%",
            "right": "0%",
            "skin": "sknbtnSave",
            "text": "Save",
            "top": "1%",
            "width": "24%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 2, 0, 2],
            "paddingInPixel": false
        }, {});
        var btnSubmit = new voltmx.ui.Button({
            "bottom": "1%",
            "centerY": "50%",
            "focusSkin": "defBtnFocus",
            "id": "btnSubmit",
            "isVisible": true,
            "left": "3%",
            "right": "0%",
            "skin": "sknbtnSubmit",
            "text": "Submit",
            "top": "1%",
            "width": "24%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 2, 0, 2],
            "paddingInPixel": false
        }, {});
        var btnSubmit2 = new voltmx.ui.Button({
            "bottom": "1%",
            "centerY": "50%",
            "focusSkin": "defBtnFocus",
            "id": "btnSubmit2",
            "isVisible": false,
            "left": "0%",
            "right": "0%",
            "skin": "sknbtnSubmit2",
            "text": "Button",
            "top": "1%",
            "width": "24%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var btnDelete = new voltmx.ui.Button({
            "bottom": "1%",
            "centerY": "50%",
            "focusSkin": "defBtnFocus",
            "id": "btnDelete",
            "isVisible": true,
            "left": "20%",
            "right": "3%",
            "skin": "sknbtnDelete",
            "text": "Delete",
            "top": "1%",
            "width": "24%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 2, 0, 2],
            "paddingInPixel": false
        }, {});
        FlexContainer0g87434182ad74c.add(btnSave, btnSubmit, btnSubmit2, btnDelete);
        FlexContainer0ac17401cea3043.add(FlexContainer0eb12b1e1a9e845, FlexContainer0g87434182ad74c);
        fcappFooter.add(FlexContainer0ac17401cea3043);
        return fcappFooter;
    }
})
;
define("fcMainheader", [],function() {
    return function(controller) {
        var fcMainheader = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100px",
            "id": "fcMainheader",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "isModalContainer": false,
            "skin": "sknfcHeader",
            "width": "100%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        fcMainheader.setDefaultUnit(voltmx.flex.DP);
        var Label0gf45b249bf6445 = new voltmx.ui.Label({
            "centerY": "50%",
            "id": "Label0gf45b249bf6445",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknlblWhiteLogin",
            "text": "Acutes Charge Capture",
            "textStyle": {},
            "width": "33%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var FlexContainer0f9a5d5a46d0045 = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "FlexContainer0f9a5d5a46d0045",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknfcbluebgwithblackborder12",
            "top": "0",
            "width": "67%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        FlexContainer0f9a5d5a46d0045.setDefaultUnit(voltmx.flex.DP);
        var FlexContainer0i002cdfd3b8f4c = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "FlexContainer0i002cdfd3b8f4c",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0",
            "width": "90%",
            "appName": "AMII"
        }, {
            "paddingInPixel": false
        }, {});
        FlexContainer0i002cdfd3b8f4c.setDefaultUnit(voltmx.flex.DP);
        var btnHeaderBack = new voltmx.ui.Button({
            "centerY": "50%",
            "focusSkin": "defBtnFocus",
            "height": "100%",
            "id": "btnHeaderBack",
            "isVisible": true,
            "left": "10%",
            "skin": "sknbtnback",
            "text": "Back",
            "width": "23%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [3, 0, 1, 0],
            "paddingInPixel": false
        }, {});
        var lblHeader = new voltmx.ui.Label({
            "id": "lblHeader",
            "isVisible": true,
            "skin": "sknlblWhiteLogin",
            "textStyle": {},
            "width": "53%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false
        });
        var btnHeaderNext = new voltmx.ui.Button({
            "focusSkin": "defBtnFocus",
            "height": "80%",
            "id": "btnHeaderNext",
            "isVisible": true,
            "skin": "sknbtnnext",
            "text": "Next",
            "width": "24%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [3, 0, 1, 0],
            "paddingInPixel": false
        }, {});
        FlexContainer0i002cdfd3b8f4c.add(btnHeaderBack, lblHeader, btnHeaderNext);
        FlexContainer0f9a5d5a46d0045.add(FlexContainer0i002cdfd3b8f4c);
        fcMainheader.add(Label0gf45b249bf6445, FlexContainer0f9a5d5a46d0045);
        return fcMainheader;
    }
})
;
define("userCopyFBox0e0feafe301d842Controller", {
    //Type your controller code here 
});
define("CopyFBox0e0feafe301d842ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("CopyFBox0e0feafe301d842Controller", ["userCopyFBox0e0feafe301d842Controller", "CopyFBox0e0feafe301d842ControllerActions"], function() {
    var controller = require("userCopyFBox0e0feafe301d842Controller");
    var controllerActions = ["CopyFBox0e0feafe301d842ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userFBox0d3323315729948Controller", {
    //Type your controller code here 
});
define("FBox0d3323315729948ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("FBox0d3323315729948Controller", ["userFBox0d3323315729948Controller", "FBox0d3323315729948ControllerActions"], function() {
    var controller = require("userFBox0d3323315729948Controller");
    var controllerActions = ["FBox0d3323315729948ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userFBox0jce3a5b497b34eController", {
    //Type your controller code here 
});
define("FBox0jce3a5b497b34eControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("FBox0jce3a5b497b34eController", ["userFBox0jce3a5b497b34eController", "FBox0jce3a5b497b34eControllerActions"], function() {
    var controller = require("userFBox0jce3a5b497b34eController");
    var controllerActions = ["FBox0jce3a5b497b34eControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userFlex0d798b50aa6d145Controller", {
    //Type your controller code here 
});
define("Flex0d798b50aa6d145ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Flex0d798b50aa6d145Controller", ["userFlex0d798b50aa6d145Controller", "Flex0d798b50aa6d145ControllerActions"], function() {
    var controller = require("userFlex0d798b50aa6d145Controller");
    var controllerActions = ["Flex0d798b50aa6d145ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userfcappFooterController", {
    //Type your controller code here 
});
define("fcappFooterControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("fcappFooterController", ["userfcappFooterController", "fcappFooterControllerActions"], function() {
    var controller = require("userfcappFooterController");
    var controllerActions = ["fcappFooterControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userfcMainheaderController", {
    //Type your controller code here 
});
define("fcMainheaderControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("fcMainheaderController", ["userfcMainheaderController", "fcMainheaderControllerActions"], function() {
    var controller = require("userfcMainheaderController");
    var controllerActions = ["fcMainheaderControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("navigation/NavigationModel", { 
    "Application": {},
    "Forms" : {},
    "UIModules" : {}
});

define("navigation/NavigationController", {
    //Add your navigation controller code here.
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_AccessType_Desc/MF_Config',[], function() {
    var mappings = {
        "AccessType_Desc": "AccessType_Desc",
        "AccessTypeID": "AccessTypeID",
        "DELETED": "DELETED",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "AccessType_Desc": "string",
        "AccessTypeID": "number",
        "DELETED": "boolean",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["AccessTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_AccessType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_AccessType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_AccessType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        AccessType_Desc: function(val, state) {
            context["field"] = "AccessType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["AccessType_Desc"] : null);
            state['AccessType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        AccessTypeID: function(val, state) {
            context["field"] = "AccessTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["AccessTypeID"] : null);
            state['AccessTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_AccessType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "AccessType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["AccessType_Desc"] : null);
        privateState.AccessType_Desc = defaultValues ? (defaultValues["AccessType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["AccessType_Desc"], context) : null) : null;
        context["field"] = "AccessTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["AccessTypeID"] : null);
        privateState.AccessTypeID = defaultValues ? (defaultValues["AccessTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["AccessTypeID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "AccessType_Desc": {
                get: function() {
                    context["field"] = "AccessType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["AccessType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.AccessType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['AccessType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "AccessTypeID": {
                get: function() {
                    context["field"] = "AccessTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["AccessTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.AccessTypeID, context);
                },
                set: function(val) {
                    setterFunctions['AccessTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.AccessType_Desc = value ? (value["AccessType_Desc"] ? value["AccessType_Desc"] : null) : null;
            privateState.AccessTypeID = value ? (value["AccessTypeID"] ? value["AccessTypeID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_AccessType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_AccessType_Desc);
    var registerValidatorBackup = Ref_AccessType_Desc.registerValidator;
    Ref_AccessType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_AccessType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_AccessType_Desc.relations = relations;
    Ref_AccessType_Desc.prototype.isValid = function() {
        return Ref_AccessType_Desc.isValid(this);
    };
    Ref_AccessType_Desc.prototype.objModelName = "Ref_AccessType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_AccessType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_AccessType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_AccessType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_AccessType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_AccessType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_AdditionalServicesType_Desc/MF_Config',[], function() {
    var mappings = {
        "AdditionalServicesType_Desc": "AdditionalServicesType_Desc",
        "AdditionalServicesTypeID": "AdditionalServicesTypeID",
        "DELETED": "DELETED",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "AdditionalServicesType_Desc": "string",
        "AdditionalServicesTypeID": "number",
        "DELETED": "boolean",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["AdditionalServicesTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_AdditionalServicesType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_AdditionalServicesType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_AdditionalServicesType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        AdditionalServicesType_Desc: function(val, state) {
            context["field"] = "AdditionalServicesType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["AdditionalServicesType_Desc"] : null);
            state['AdditionalServicesType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        AdditionalServicesTypeID: function(val, state) {
            context["field"] = "AdditionalServicesTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["AdditionalServicesTypeID"] : null);
            state['AdditionalServicesTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_AdditionalServicesType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "AdditionalServicesType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["AdditionalServicesType_Desc"] : null);
        privateState.AdditionalServicesType_Desc = defaultValues ? (defaultValues["AdditionalServicesType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["AdditionalServicesType_Desc"], context) : null) : null;
        context["field"] = "AdditionalServicesTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["AdditionalServicesTypeID"] : null);
        privateState.AdditionalServicesTypeID = defaultValues ? (defaultValues["AdditionalServicesTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["AdditionalServicesTypeID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "AdditionalServicesType_Desc": {
                get: function() {
                    context["field"] = "AdditionalServicesType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["AdditionalServicesType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.AdditionalServicesType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['AdditionalServicesType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "AdditionalServicesTypeID": {
                get: function() {
                    context["field"] = "AdditionalServicesTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["AdditionalServicesTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.AdditionalServicesTypeID, context);
                },
                set: function(val) {
                    setterFunctions['AdditionalServicesTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.AdditionalServicesType_Desc = value ? (value["AdditionalServicesType_Desc"] ? value["AdditionalServicesType_Desc"] : null) : null;
            privateState.AdditionalServicesTypeID = value ? (value["AdditionalServicesTypeID"] ? value["AdditionalServicesTypeID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_AdditionalServicesType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_AdditionalServicesType_Desc);
    var registerValidatorBackup = Ref_AdditionalServicesType_Desc.registerValidator;
    Ref_AdditionalServicesType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_AdditionalServicesType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_AdditionalServicesType_Desc.relations = relations;
    Ref_AdditionalServicesType_Desc.prototype.isValid = function() {
        return Ref_AdditionalServicesType_Desc.isValid(this);
    };
    Ref_AdditionalServicesType_Desc.prototype.objModelName = "Ref_AdditionalServicesType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_AdditionalServicesType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_AdditionalServicesType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_AdditionalServicesType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_AdditionalServicesType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_AdditionalServicesType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_ApheresisType_Desc/MF_Config',[], function() {
    var mappings = {
        "ApheresisType_Desc": "ApheresisType_Desc",
        "ApheresisTypeID": "ApheresisTypeID",
        "DELETED": "DELETED",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "ApheresisType_Desc": "string",
        "ApheresisTypeID": "number",
        "DELETED": "boolean",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["ApheresisTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_ApheresisType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_ApheresisType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_ApheresisType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        ApheresisType_Desc: function(val, state) {
            context["field"] = "ApheresisType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["ApheresisType_Desc"] : null);
            state['ApheresisType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ApheresisTypeID: function(val, state) {
            context["field"] = "ApheresisTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["ApheresisTypeID"] : null);
            state['ApheresisTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_ApheresisType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "ApheresisType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["ApheresisType_Desc"] : null);
        privateState.ApheresisType_Desc = defaultValues ? (defaultValues["ApheresisType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ApheresisType_Desc"], context) : null) : null;
        context["field"] = "ApheresisTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["ApheresisTypeID"] : null);
        privateState.ApheresisTypeID = defaultValues ? (defaultValues["ApheresisTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ApheresisTypeID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "ApheresisType_Desc": {
                get: function() {
                    context["field"] = "ApheresisType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["ApheresisType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ApheresisType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['ApheresisType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ApheresisTypeID": {
                get: function() {
                    context["field"] = "ApheresisTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["ApheresisTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ApheresisTypeID, context);
                },
                set: function(val) {
                    setterFunctions['ApheresisTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.ApheresisType_Desc = value ? (value["ApheresisType_Desc"] ? value["ApheresisType_Desc"] : null) : null;
            privateState.ApheresisTypeID = value ? (value["ApheresisTypeID"] ? value["ApheresisTypeID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_ApheresisType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_ApheresisType_Desc);
    var registerValidatorBackup = Ref_ApheresisType_Desc.registerValidator;
    Ref_ApheresisType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_ApheresisType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_ApheresisType_Desc.relations = relations;
    Ref_ApheresisType_Desc.prototype.isValid = function() {
        return Ref_ApheresisType_Desc.isValid(this);
    };
    Ref_ApheresisType_Desc.prototype.objModelName = "Ref_ApheresisType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_ApheresisType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_ApheresisType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_ApheresisType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_ApheresisType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_ApheresisType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_CRRTType_Desc/MF_Config',[], function() {
    var mappings = {
        "CRRTType_Desc": "CRRTType_Desc",
        "CRRTTypeID": "CRRTTypeID",
        "DELETED": "DELETED",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "CRRTType_Desc": "string",
        "CRRTTypeID": "number",
        "DELETED": "boolean",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["CRRTTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_CRRTType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_CRRTType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_CRRTType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        CRRTType_Desc: function(val, state) {
            context["field"] = "CRRTType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["CRRTType_Desc"] : null);
            state['CRRTType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CRRTTypeID: function(val, state) {
            context["field"] = "CRRTTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["CRRTTypeID"] : null);
            state['CRRTTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_CRRTType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "CRRTType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["CRRTType_Desc"] : null);
        privateState.CRRTType_Desc = defaultValues ? (defaultValues["CRRTType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CRRTType_Desc"], context) : null) : null;
        context["field"] = "CRRTTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["CRRTTypeID"] : null);
        privateState.CRRTTypeID = defaultValues ? (defaultValues["CRRTTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CRRTTypeID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "CRRTType_Desc": {
                get: function() {
                    context["field"] = "CRRTType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["CRRTType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CRRTType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['CRRTType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CRRTTypeID": {
                get: function() {
                    context["field"] = "CRRTTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["CRRTTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CRRTTypeID, context);
                },
                set: function(val) {
                    setterFunctions['CRRTTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.CRRTType_Desc = value ? (value["CRRTType_Desc"] ? value["CRRTType_Desc"] : null) : null;
            privateState.CRRTTypeID = value ? (value["CRRTTypeID"] ? value["CRRTTypeID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_CRRTType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_CRRTType_Desc);
    var registerValidatorBackup = Ref_CRRTType_Desc.registerValidator;
    Ref_CRRTType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_CRRTType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_CRRTType_Desc.relations = relations;
    Ref_CRRTType_Desc.prototype.isValid = function() {
        return Ref_CRRTType_Desc.isValid(this);
    };
    Ref_CRRTType_Desc.prototype.objModelName = "Ref_CRRTType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_CRRTType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_CRRTType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_CRRTType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_CRRTType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_CRRTType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_CRRTUltrafiltrationType_Desc/MF_Config',[], function() {
    var mappings = {
        "CRRTUltrafiltrationType_Desc": "CRRTUltrafiltrationType_Desc",
        "CRRTUltrafiltrationTypeID": "CRRTUltrafiltrationTypeID",
        "DELETED": "DELETED",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "CRRTUltrafiltrationType_Desc": "string",
        "CRRTUltrafiltrationTypeID": "number",
        "DELETED": "boolean",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["CRRTUltrafiltrationTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_CRRTUltrafiltrationType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_CRRTUltrafiltrationType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_CRRTUltrafiltrationType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        CRRTUltrafiltrationType_Desc: function(val, state) {
            context["field"] = "CRRTUltrafiltrationType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationType_Desc"] : null);
            state['CRRTUltrafiltrationType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CRRTUltrafiltrationTypeID: function(val, state) {
            context["field"] = "CRRTUltrafiltrationTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationTypeID"] : null);
            state['CRRTUltrafiltrationTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_CRRTUltrafiltrationType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "CRRTUltrafiltrationType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationType_Desc"] : null);
        privateState.CRRTUltrafiltrationType_Desc = defaultValues ? (defaultValues["CRRTUltrafiltrationType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CRRTUltrafiltrationType_Desc"], context) : null) : null;
        context["field"] = "CRRTUltrafiltrationTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationTypeID"] : null);
        privateState.CRRTUltrafiltrationTypeID = defaultValues ? (defaultValues["CRRTUltrafiltrationTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CRRTUltrafiltrationTypeID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "CRRTUltrafiltrationType_Desc": {
                get: function() {
                    context["field"] = "CRRTUltrafiltrationType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CRRTUltrafiltrationType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['CRRTUltrafiltrationType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CRRTUltrafiltrationTypeID": {
                get: function() {
                    context["field"] = "CRRTUltrafiltrationTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CRRTUltrafiltrationTypeID, context);
                },
                set: function(val) {
                    setterFunctions['CRRTUltrafiltrationTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.CRRTUltrafiltrationType_Desc = value ? (value["CRRTUltrafiltrationType_Desc"] ? value["CRRTUltrafiltrationType_Desc"] : null) : null;
            privateState.CRRTUltrafiltrationTypeID = value ? (value["CRRTUltrafiltrationTypeID"] ? value["CRRTUltrafiltrationTypeID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_CRRTUltrafiltrationType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_CRRTUltrafiltrationType_Desc);
    var registerValidatorBackup = Ref_CRRTUltrafiltrationType_Desc.registerValidator;
    Ref_CRRTUltrafiltrationType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_CRRTUltrafiltrationType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_CRRTUltrafiltrationType_Desc.relations = relations;
    Ref_CRRTUltrafiltrationType_Desc.prototype.isValid = function() {
        return Ref_CRRTUltrafiltrationType_Desc.isValid(this);
    };
    Ref_CRRTUltrafiltrationType_Desc.prototype.objModelName = "Ref_CRRTUltrafiltrationType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_CRRTUltrafiltrationType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_CRRTUltrafiltrationType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_CRRTUltrafiltrationType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_CRRTUltrafiltrationType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_CRRTUltrafiltrationType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_CancellationType_Desc/MF_Config',[], function() {
    var mappings = {
        "CancellationType_Desc": "CancellationType_Desc",
        "CancellationTypeID": "CancellationTypeID",
        "DELETED": "DELETED",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "CancellationType_Desc": "string",
        "CancellationTypeID": "number",
        "DELETED": "boolean",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["CancellationTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_CancellationType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_CancellationType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_CancellationType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        CancellationType_Desc: function(val, state) {
            context["field"] = "CancellationType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["CancellationType_Desc"] : null);
            state['CancellationType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CancellationTypeID: function(val, state) {
            context["field"] = "CancellationTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["CancellationTypeID"] : null);
            state['CancellationTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_CancellationType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "CancellationType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["CancellationType_Desc"] : null);
        privateState.CancellationType_Desc = defaultValues ? (defaultValues["CancellationType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CancellationType_Desc"], context) : null) : null;
        context["field"] = "CancellationTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["CancellationTypeID"] : null);
        privateState.CancellationTypeID = defaultValues ? (defaultValues["CancellationTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CancellationTypeID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "CancellationType_Desc": {
                get: function() {
                    context["field"] = "CancellationType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["CancellationType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CancellationType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['CancellationType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CancellationTypeID": {
                get: function() {
                    context["field"] = "CancellationTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["CancellationTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CancellationTypeID, context);
                },
                set: function(val) {
                    setterFunctions['CancellationTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.CancellationType_Desc = value ? (value["CancellationType_Desc"] ? value["CancellationType_Desc"] : null) : null;
            privateState.CancellationTypeID = value ? (value["CancellationTypeID"] ? value["CancellationTypeID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_CancellationType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_CancellationType_Desc);
    var registerValidatorBackup = Ref_CancellationType_Desc.registerValidator;
    Ref_CancellationType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_CancellationType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_CancellationType_Desc.relations = relations;
    Ref_CancellationType_Desc.prototype.isValid = function() {
        return Ref_CancellationType_Desc.isValid(this);
    };
    Ref_CancellationType_Desc.prototype.objModelName = "Ref_CancellationType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_CancellationType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_CancellationType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_CancellationType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_CancellationType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_CancellationType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_DaVitaClinic_Desc/MF_Config',[], function() {
    var mappings = {
        "DaVitaClinic_Desc": "DaVitaClinic_Desc",
        "DaVitaClinicID": "DaVitaClinicID",
        "DELETED": "DELETED",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DaVitaClinic_Desc": "string",
        "DaVitaClinicID": "number",
        "DELETED": "boolean",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["DaVitaClinicID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_DaVitaClinic_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_DaVitaClinic_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_DaVitaClinic_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DaVitaClinic_Desc: function(val, state) {
            context["field"] = "DaVitaClinic_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinic_Desc"] : null);
            state['DaVitaClinic_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DaVitaClinicID: function(val, state) {
            context["field"] = "DaVitaClinicID";
            context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
            state['DaVitaClinicID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_DaVitaClinic_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DaVitaClinic_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinic_Desc"] : null);
        privateState.DaVitaClinic_Desc = defaultValues ? (defaultValues["DaVitaClinic_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DaVitaClinic_Desc"], context) : null) : null;
        context["field"] = "DaVitaClinicID";
        context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
        privateState.DaVitaClinicID = defaultValues ? (defaultValues["DaVitaClinicID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DaVitaClinicID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DaVitaClinic_Desc": {
                get: function() {
                    context["field"] = "DaVitaClinic_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinic_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DaVitaClinic_Desc, context);
                },
                set: function(val) {
                    setterFunctions['DaVitaClinic_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DaVitaClinicID": {
                get: function() {
                    context["field"] = "DaVitaClinicID";
                    context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DaVitaClinicID, context);
                },
                set: function(val) {
                    setterFunctions['DaVitaClinicID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DaVitaClinic_Desc = value ? (value["DaVitaClinic_Desc"] ? value["DaVitaClinic_Desc"] : null) : null;
            privateState.DaVitaClinicID = value ? (value["DaVitaClinicID"] ? value["DaVitaClinicID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_DaVitaClinic_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_DaVitaClinic_Desc);
    var registerValidatorBackup = Ref_DaVitaClinic_Desc.registerValidator;
    Ref_DaVitaClinic_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_DaVitaClinic_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_DaVitaClinic_Desc.relations = relations;
    Ref_DaVitaClinic_Desc.prototype.isValid = function() {
        return Ref_DaVitaClinic_Desc.isValid(this);
    };
    Ref_DaVitaClinic_Desc.prototype.objModelName = "Ref_DaVitaClinic_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_DaVitaClinic_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_DaVitaClinic_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_DaVitaClinic_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_DaVitaClinic_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_DaVitaClinic_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_DialysateType_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "DialysateType_Desc": "DialysateType_Desc",
        "DialysateTypeID": "DialysateTypeID",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "DialysateType_Desc": "string",
        "DialysateTypeID": "number",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["DialysateTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_DialysateType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_DialysateType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_DialysateType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DialysateType_Desc: function(val, state) {
            context["field"] = "DialysateType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["DialysateType_Desc"] : null);
            state['DialysateType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DialysateTypeID: function(val, state) {
            context["field"] = "DialysateTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["DialysateTypeID"] : null);
            state['DialysateTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_DialysateType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "DialysateType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["DialysateType_Desc"] : null);
        privateState.DialysateType_Desc = defaultValues ? (defaultValues["DialysateType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DialysateType_Desc"], context) : null) : null;
        context["field"] = "DialysateTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["DialysateTypeID"] : null);
        privateState.DialysateTypeID = defaultValues ? (defaultValues["DialysateTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DialysateTypeID"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DialysateType_Desc": {
                get: function() {
                    context["field"] = "DialysateType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["DialysateType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DialysateType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['DialysateType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DialysateTypeID": {
                get: function() {
                    context["field"] = "DialysateTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["DialysateTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DialysateTypeID, context);
                },
                set: function(val) {
                    setterFunctions['DialysateTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.DialysateType_Desc = value ? (value["DialysateType_Desc"] ? value["DialysateType_Desc"] : null) : null;
            privateState.DialysateTypeID = value ? (value["DialysateTypeID"] ? value["DialysateTypeID"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_DialysateType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_DialysateType_Desc);
    var registerValidatorBackup = Ref_DialysateType_Desc.registerValidator;
    Ref_DialysateType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_DialysateType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_DialysateType_Desc.relations = relations;
    Ref_DialysateType_Desc.prototype.isValid = function() {
        return Ref_DialysateType_Desc.isValid(this);
    };
    Ref_DialysateType_Desc.prototype.objModelName = "Ref_DialysateType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_DialysateType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_DialysateType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_DialysateType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_DialysateType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_DialysateType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Division_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "Division_Desc": "Division_Desc",
        "DivisionID": "DivisionID",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "Division_Desc": "string",
        "DivisionID": "number",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["DivisionID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_Division_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Division_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_Division_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Division_Desc: function(val, state) {
            context["field"] = "Division_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["Division_Desc"] : null);
            state['Division_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DivisionID: function(val, state) {
            context["field"] = "DivisionID";
            context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
            state['DivisionID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_Division_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "Division_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["Division_Desc"] : null);
        privateState.Division_Desc = defaultValues ? (defaultValues["Division_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Division_Desc"], context) : null) : null;
        context["field"] = "DivisionID";
        context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
        privateState.DivisionID = defaultValues ? (defaultValues["DivisionID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DivisionID"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Division_Desc": {
                get: function() {
                    context["field"] = "Division_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["Division_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Division_Desc, context);
                },
                set: function(val) {
                    setterFunctions['Division_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DivisionID": {
                get: function() {
                    context["field"] = "DivisionID";
                    context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DivisionID, context);
                },
                set: function(val) {
                    setterFunctions['DivisionID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.Division_Desc = value ? (value["Division_Desc"] ? value["Division_Desc"] : null) : null;
            privateState.DivisionID = value ? (value["DivisionID"] ? value["DivisionID"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_Division_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_Division_Desc);
    var registerValidatorBackup = Ref_Division_Desc.registerValidator;
    Ref_Division_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_Division_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_Division_Desc.relations = relations;
    Ref_Division_Desc.prototype.isValid = function() {
        return Ref_Division_Desc.isValid(this);
    };
    Ref_Division_Desc.prototype.objModelName = "Ref_Division_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_Division_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_Division_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_Division_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_Division_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_Division_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_DivisonRegionMappingInfo/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "DivisionID": "DivisionID",
        "last_modified": "last_modified",
        "RegionID": "RegionID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "DivisionID": "number",
        "last_modified": "date",
        "RegionID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["RegionID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_DivisonRegionMappingInfo"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_DivisonRegionMappingInfo/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_DivisonRegionMappingInfo",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DivisionID: function(val, state) {
            context["field"] = "DivisionID";
            context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
            state['DivisionID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        RegionID: function(val, state) {
            context["field"] = "RegionID";
            context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
            state['RegionID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_DivisonRegionMappingInfo(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "DivisionID";
        context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
        privateState.DivisionID = defaultValues ? (defaultValues["DivisionID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DivisionID"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "RegionID";
        context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
        privateState.RegionID = defaultValues ? (defaultValues["RegionID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["RegionID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DivisionID": {
                get: function() {
                    context["field"] = "DivisionID";
                    context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DivisionID, context);
                },
                set: function(val) {
                    setterFunctions['DivisionID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "RegionID": {
                get: function() {
                    context["field"] = "RegionID";
                    context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.RegionID, context);
                },
                set: function(val) {
                    setterFunctions['RegionID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.DivisionID = value ? (value["DivisionID"] ? value["DivisionID"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.RegionID = value ? (value["RegionID"] ? value["RegionID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_DivisonRegionMappingInfo);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_DivisonRegionMappingInfo);
    var registerValidatorBackup = Ref_DivisonRegionMappingInfo.registerValidator;
    Ref_DivisonRegionMappingInfo.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_DivisonRegionMappingInfo.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_DivisonRegionMappingInfo.relations = relations;
    Ref_DivisonRegionMappingInfo.prototype.isValid = function() {
        return Ref_DivisonRegionMappingInfo.isValid(this);
    };
    Ref_DivisonRegionMappingInfo.prototype.objModelName = "Ref_DivisonRegionMappingInfo";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_DivisonRegionMappingInfo.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_DivisonRegionMappingInfo", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_DivisonRegionMappingInfo.clone = function(objectToClone) {
        var clonedObj = new Ref_DivisonRegionMappingInfo();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_DivisonRegionMappingInfo;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_GroupDivisionMappingInfo/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "DivisionID": "DivisionID",
        "GroupID": "GroupID",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "DivisionID": "number",
        "GroupID": "number",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["DivisionID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_GroupDivisionMappingInfo"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_GroupDivisionMappingInfo/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_GroupDivisionMappingInfo",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DivisionID: function(val, state) {
            context["field"] = "DivisionID";
            context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
            state['DivisionID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        GroupID: function(val, state) {
            context["field"] = "GroupID";
            context["metadata"] = (objectMetadata ? objectMetadata["GroupID"] : null);
            state['GroupID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_GroupDivisionMappingInfo(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "DivisionID";
        context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
        privateState.DivisionID = defaultValues ? (defaultValues["DivisionID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DivisionID"], context) : null) : null;
        context["field"] = "GroupID";
        context["metadata"] = (objectMetadata ? objectMetadata["GroupID"] : null);
        privateState.GroupID = defaultValues ? (defaultValues["GroupID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["GroupID"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DivisionID": {
                get: function() {
                    context["field"] = "DivisionID";
                    context["metadata"] = (objectMetadata ? objectMetadata["DivisionID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DivisionID, context);
                },
                set: function(val) {
                    setterFunctions['DivisionID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "GroupID": {
                get: function() {
                    context["field"] = "GroupID";
                    context["metadata"] = (objectMetadata ? objectMetadata["GroupID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.GroupID, context);
                },
                set: function(val) {
                    setterFunctions['GroupID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.DivisionID = value ? (value["DivisionID"] ? value["DivisionID"] : null) : null;
            privateState.GroupID = value ? (value["GroupID"] ? value["GroupID"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_GroupDivisionMappingInfo);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_GroupDivisionMappingInfo);
    var registerValidatorBackup = Ref_GroupDivisionMappingInfo.registerValidator;
    Ref_GroupDivisionMappingInfo.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_GroupDivisionMappingInfo.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_GroupDivisionMappingInfo.relations = relations;
    Ref_GroupDivisionMappingInfo.prototype.isValid = function() {
        return Ref_GroupDivisionMappingInfo.isValid(this);
    };
    Ref_GroupDivisionMappingInfo.prototype.objModelName = "Ref_GroupDivisionMappingInfo";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_GroupDivisionMappingInfo.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_GroupDivisionMappingInfo", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_GroupDivisionMappingInfo.clone = function(objectToClone) {
        var clonedObj = new Ref_GroupDivisionMappingInfo();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_GroupDivisionMappingInfo;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Group_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "Group_Desc": "Group_Desc",
        "GroupID": "GroupID",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "Group_Desc": "string",
        "GroupID": "number",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["GroupID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_Group_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Group_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_Group_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Group_Desc: function(val, state) {
            context["field"] = "Group_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["Group_Desc"] : null);
            state['Group_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        GroupID: function(val, state) {
            context["field"] = "GroupID";
            context["metadata"] = (objectMetadata ? objectMetadata["GroupID"] : null);
            state['GroupID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_Group_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "Group_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["Group_Desc"] : null);
        privateState.Group_Desc = defaultValues ? (defaultValues["Group_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Group_Desc"], context) : null) : null;
        context["field"] = "GroupID";
        context["metadata"] = (objectMetadata ? objectMetadata["GroupID"] : null);
        privateState.GroupID = defaultValues ? (defaultValues["GroupID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["GroupID"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Group_Desc": {
                get: function() {
                    context["field"] = "Group_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["Group_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Group_Desc, context);
                },
                set: function(val) {
                    setterFunctions['Group_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "GroupID": {
                get: function() {
                    context["field"] = "GroupID";
                    context["metadata"] = (objectMetadata ? objectMetadata["GroupID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.GroupID, context);
                },
                set: function(val) {
                    setterFunctions['GroupID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.Group_Desc = value ? (value["Group_Desc"] ? value["Group_Desc"] : null) : null;
            privateState.GroupID = value ? (value["GroupID"] ? value["GroupID"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_Group_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_Group_Desc);
    var registerValidatorBackup = Ref_Group_Desc.registerValidator;
    Ref_Group_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_Group_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_Group_Desc.relations = relations;
    Ref_Group_Desc.prototype.isValid = function() {
        return Ref_Group_Desc.isValid(this);
    };
    Ref_Group_Desc.prototype.objModelName = "Ref_Group_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_Group_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_Group_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_Group_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_Group_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_Group_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_HbsAb_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "HbsAb_Desc": "HbsAb_Desc",
        "HbsAbId": "HbsAbId",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "HbsAb_Desc": "string",
        "HbsAbId": "number",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["HbsAbId", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_HbsAb_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_HbsAb_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_HbsAb_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HbsAb_Desc: function(val, state) {
            context["field"] = "HbsAb_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["HbsAb_Desc"] : null);
            state['HbsAb_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HbsAbId: function(val, state) {
            context["field"] = "HbsAbId";
            context["metadata"] = (objectMetadata ? objectMetadata["HbsAbId"] : null);
            state['HbsAbId'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_HbsAb_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "HbsAb_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["HbsAb_Desc"] : null);
        privateState.HbsAb_Desc = defaultValues ? (defaultValues["HbsAb_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HbsAb_Desc"], context) : null) : null;
        context["field"] = "HbsAbId";
        context["metadata"] = (objectMetadata ? objectMetadata["HbsAbId"] : null);
        privateState.HbsAbId = defaultValues ? (defaultValues["HbsAbId"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HbsAbId"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HbsAb_Desc": {
                get: function() {
                    context["field"] = "HbsAb_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["HbsAb_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HbsAb_Desc, context);
                },
                set: function(val) {
                    setterFunctions['HbsAb_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HbsAbId": {
                get: function() {
                    context["field"] = "HbsAbId";
                    context["metadata"] = (objectMetadata ? objectMetadata["HbsAbId"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HbsAbId, context);
                },
                set: function(val) {
                    setterFunctions['HbsAbId'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.HbsAb_Desc = value ? (value["HbsAb_Desc"] ? value["HbsAb_Desc"] : null) : null;
            privateState.HbsAbId = value ? (value["HbsAbId"] ? value["HbsAbId"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_HbsAb_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_HbsAb_Desc);
    var registerValidatorBackup = Ref_HbsAb_Desc.registerValidator;
    Ref_HbsAb_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_HbsAb_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_HbsAb_Desc.relations = relations;
    Ref_HbsAb_Desc.prototype.isValid = function() {
        return Ref_HbsAb_Desc.isValid(this);
    };
    Ref_HbsAb_Desc.prototype.objModelName = "Ref_HbsAb_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_HbsAb_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_HbsAb_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_HbsAb_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_HbsAb_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_HbsAb_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_HbsAg_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "HbsAg_Desc": "HbsAg_Desc",
        "HbsAgId": "HbsAgId",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "HbsAg_Desc": "string",
        "HbsAgId": "number",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["HbsAgId", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_HbsAg_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_HbsAg_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_HbsAg_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HbsAg_Desc: function(val, state) {
            context["field"] = "HbsAg_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["HbsAg_Desc"] : null);
            state['HbsAg_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HbsAgId: function(val, state) {
            context["field"] = "HbsAgId";
            context["metadata"] = (objectMetadata ? objectMetadata["HbsAgId"] : null);
            state['HbsAgId'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_HbsAg_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "HbsAg_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["HbsAg_Desc"] : null);
        privateState.HbsAg_Desc = defaultValues ? (defaultValues["HbsAg_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HbsAg_Desc"], context) : null) : null;
        context["field"] = "HbsAgId";
        context["metadata"] = (objectMetadata ? objectMetadata["HbsAgId"] : null);
        privateState.HbsAgId = defaultValues ? (defaultValues["HbsAgId"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HbsAgId"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HbsAg_Desc": {
                get: function() {
                    context["field"] = "HbsAg_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["HbsAg_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HbsAg_Desc, context);
                },
                set: function(val) {
                    setterFunctions['HbsAg_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HbsAgId": {
                get: function() {
                    context["field"] = "HbsAgId";
                    context["metadata"] = (objectMetadata ? objectMetadata["HbsAgId"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HbsAgId, context);
                },
                set: function(val) {
                    setterFunctions['HbsAgId'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.HbsAg_Desc = value ? (value["HbsAg_Desc"] ? value["HbsAg_Desc"] : null) : null;
            privateState.HbsAgId = value ? (value["HbsAgId"] ? value["HbsAgId"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_HbsAg_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_HbsAg_Desc);
    var registerValidatorBackup = Ref_HbsAg_Desc.registerValidator;
    Ref_HbsAg_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_HbsAg_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_HbsAg_Desc.relations = relations;
    Ref_HbsAg_Desc.prototype.isValid = function() {
        return Ref_HbsAg_Desc.isValid(this);
    };
    Ref_HbsAg_Desc.prototype.objModelName = "Ref_HbsAg_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_HbsAg_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_HbsAg_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_HbsAg_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_HbsAg_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_HbsAg_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_HemoType_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "HemoType_Desc": "HemoType_Desc",
        "HemotypeID": "HemotypeID",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "HemoType_Desc": "string",
        "HemotypeID": "number",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["HemotypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_HemoType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_HemoType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_HemoType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HemoType_Desc: function(val, state) {
            context["field"] = "HemoType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["HemoType_Desc"] : null);
            state['HemoType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HemotypeID: function(val, state) {
            context["field"] = "HemotypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["HemotypeID"] : null);
            state['HemotypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_HemoType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "HemoType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["HemoType_Desc"] : null);
        privateState.HemoType_Desc = defaultValues ? (defaultValues["HemoType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HemoType_Desc"], context) : null) : null;
        context["field"] = "HemotypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["HemotypeID"] : null);
        privateState.HemotypeID = defaultValues ? (defaultValues["HemotypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HemotypeID"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HemoType_Desc": {
                get: function() {
                    context["field"] = "HemoType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["HemoType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HemoType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['HemoType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HemotypeID": {
                get: function() {
                    context["field"] = "HemotypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["HemotypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HemotypeID, context);
                },
                set: function(val) {
                    setterFunctions['HemotypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.HemoType_Desc = value ? (value["HemoType_Desc"] ? value["HemoType_Desc"] : null) : null;
            privateState.HemotypeID = value ? (value["HemotypeID"] ? value["HemotypeID"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_HemoType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_HemoType_Desc);
    var registerValidatorBackup = Ref_HemoType_Desc.registerValidator;
    Ref_HemoType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_HemoType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_HemoType_Desc.relations = relations;
    Ref_HemoType_Desc.prototype.isValid = function() {
        return Ref_HemoType_Desc.isValid(this);
    };
    Ref_HemoType_Desc.prototype.objModelName = "Ref_HemoType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_HemoType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_HemoType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_HemoType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_HemoType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_HemoType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Hospital_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "Hospital_Desc": "Hospital_Desc",
        "HospitalID": "HospitalID",
        "last_modified": "last_modified",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "Hospital_Desc": "string",
        "HospitalID": "number",
        "last_modified": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["HospitalID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_Hospital_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Hospital_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_Hospital_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Hospital_Desc: function(val, state) {
            context["field"] = "Hospital_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Desc"] : null);
            state['Hospital_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HospitalID: function(val, state) {
            context["field"] = "HospitalID";
            context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
            state['HospitalID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_Hospital_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "Hospital_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Desc"] : null);
        privateState.Hospital_Desc = defaultValues ? (defaultValues["Hospital_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Hospital_Desc"], context) : null) : null;
        context["field"] = "HospitalID";
        context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
        privateState.HospitalID = defaultValues ? (defaultValues["HospitalID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HospitalID"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Hospital_Desc": {
                get: function() {
                    context["field"] = "Hospital_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Hospital_Desc, context);
                },
                set: function(val) {
                    setterFunctions['Hospital_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HospitalID": {
                get: function() {
                    context["field"] = "HospitalID";
                    context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HospitalID, context);
                },
                set: function(val) {
                    setterFunctions['HospitalID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.Hospital_Desc = value ? (value["Hospital_Desc"] ? value["Hospital_Desc"] : null) : null;
            privateState.HospitalID = value ? (value["HospitalID"] ? value["HospitalID"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_Hospital_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_Hospital_Desc);
    var registerValidatorBackup = Ref_Hospital_Desc.registerValidator;
    Ref_Hospital_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_Hospital_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_Hospital_Desc.relations = relations;
    Ref_Hospital_Desc.prototype.isValid = function() {
        return Ref_Hospital_Desc.isValid(this);
    };
    Ref_Hospital_Desc.prototype.objModelName = "Ref_Hospital_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_Hospital_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_Hospital_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_Hospital_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_Hospital_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_Hospital_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Nurse_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "Description": "Description",
        "last_modified": "last_modified",
        "Nurse_UserName": "Nurse_UserName",
        "NurseID": "NurseID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "Description": "string",
        "last_modified": "date",
        "Nurse_UserName": "string",
        "NurseID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["NurseID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_Nurse_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Nurse_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_Nurse_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Description: function(val, state) {
            context["field"] = "Description";
            context["metadata"] = (objectMetadata ? objectMetadata["Description"] : null);
            state['Description'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Nurse_UserName: function(val, state) {
            context["field"] = "Nurse_UserName";
            context["metadata"] = (objectMetadata ? objectMetadata["Nurse_UserName"] : null);
            state['Nurse_UserName'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NurseID: function(val, state) {
            context["field"] = "NurseID";
            context["metadata"] = (objectMetadata ? objectMetadata["NurseID"] : null);
            state['NurseID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_Nurse_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "Description";
        context["metadata"] = (objectMetadata ? objectMetadata["Description"] : null);
        privateState.Description = defaultValues ? (defaultValues["Description"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Description"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "Nurse_UserName";
        context["metadata"] = (objectMetadata ? objectMetadata["Nurse_UserName"] : null);
        privateState.Nurse_UserName = defaultValues ? (defaultValues["Nurse_UserName"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Nurse_UserName"], context) : null) : null;
        context["field"] = "NurseID";
        context["metadata"] = (objectMetadata ? objectMetadata["NurseID"] : null);
        privateState.NurseID = defaultValues ? (defaultValues["NurseID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NurseID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Description": {
                get: function() {
                    context["field"] = "Description";
                    context["metadata"] = (objectMetadata ? objectMetadata["Description"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Description, context);
                },
                set: function(val) {
                    setterFunctions['Description'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Nurse_UserName": {
                get: function() {
                    context["field"] = "Nurse_UserName";
                    context["metadata"] = (objectMetadata ? objectMetadata["Nurse_UserName"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Nurse_UserName, context);
                },
                set: function(val) {
                    setterFunctions['Nurse_UserName'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NurseID": {
                get: function() {
                    context["field"] = "NurseID";
                    context["metadata"] = (objectMetadata ? objectMetadata["NurseID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NurseID, context);
                },
                set: function(val) {
                    setterFunctions['NurseID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.Description = value ? (value["Description"] ? value["Description"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.Nurse_UserName = value ? (value["Nurse_UserName"] ? value["Nurse_UserName"] : null) : null;
            privateState.NurseID = value ? (value["NurseID"] ? value["NurseID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_Nurse_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_Nurse_Desc);
    var registerValidatorBackup = Ref_Nurse_Desc.registerValidator;
    Ref_Nurse_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_Nurse_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_Nurse_Desc.relations = relations;
    Ref_Nurse_Desc.prototype.isValid = function() {
        return Ref_Nurse_Desc.isValid(this);
    };
    Ref_Nurse_Desc.prototype.objModelName = "Ref_Nurse_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_Nurse_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_Nurse_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_Nurse_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_Nurse_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_Nurse_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_NursingService_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "last_modified": "last_modified",
        "NursingService_Desc": "NursingService_Desc",
        "NursingServiceID": "NursingServiceID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "last_modified": "date",
        "NursingService_Desc": "string",
        "NursingServiceID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["NursingServiceID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_NursingService_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_NursingService_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_NursingService_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NursingService_Desc: function(val, state) {
            context["field"] = "NursingService_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["NursingService_Desc"] : null);
            state['NursingService_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NursingServiceID: function(val, state) {
            context["field"] = "NursingServiceID";
            context["metadata"] = (objectMetadata ? objectMetadata["NursingServiceID"] : null);
            state['NursingServiceID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_NursingService_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "NursingService_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["NursingService_Desc"] : null);
        privateState.NursingService_Desc = defaultValues ? (defaultValues["NursingService_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NursingService_Desc"], context) : null) : null;
        context["field"] = "NursingServiceID";
        context["metadata"] = (objectMetadata ? objectMetadata["NursingServiceID"] : null);
        privateState.NursingServiceID = defaultValues ? (defaultValues["NursingServiceID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NursingServiceID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NursingService_Desc": {
                get: function() {
                    context["field"] = "NursingService_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["NursingService_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NursingService_Desc, context);
                },
                set: function(val) {
                    setterFunctions['NursingService_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NursingServiceID": {
                get: function() {
                    context["field"] = "NursingServiceID";
                    context["metadata"] = (objectMetadata ? objectMetadata["NursingServiceID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NursingServiceID, context);
                },
                set: function(val) {
                    setterFunctions['NursingServiceID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.NursingService_Desc = value ? (value["NursingService_Desc"] ? value["NursingService_Desc"] : null) : null;
            privateState.NursingServiceID = value ? (value["NursingServiceID"] ? value["NursingServiceID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_NursingService_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_NursingService_Desc);
    var registerValidatorBackup = Ref_NursingService_Desc.registerValidator;
    Ref_NursingService_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_NursingService_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_NursingService_Desc.relations = relations;
    Ref_NursingService_Desc.prototype.isValid = function() {
        return Ref_NursingService_Desc.isValid(this);
    };
    Ref_NursingService_Desc.prototype.objModelName = "Ref_NursingService_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_NursingService_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_NursingService_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_NursingService_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_NursingService_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_NursingService_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_PDType_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "last_modified": "last_modified",
        "PDType_Desc": "PDType_Desc",
        "PDTypeID": "PDTypeID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "last_modified": "date",
        "PDType_Desc": "string",
        "PDTypeID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["PDTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_PDType_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_PDType_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_PDType_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PDType_Desc: function(val, state) {
            context["field"] = "PDType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["PDType_Desc"] : null);
            state['PDType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PDTypeID: function(val, state) {
            context["field"] = "PDTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["PDTypeID"] : null);
            state['PDTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_PDType_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "PDType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["PDType_Desc"] : null);
        privateState.PDType_Desc = defaultValues ? (defaultValues["PDType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PDType_Desc"], context) : null) : null;
        context["field"] = "PDTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["PDTypeID"] : null);
        privateState.PDTypeID = defaultValues ? (defaultValues["PDTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PDTypeID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PDType_Desc": {
                get: function() {
                    context["field"] = "PDType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["PDType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PDType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['PDType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PDTypeID": {
                get: function() {
                    context["field"] = "PDTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["PDTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PDTypeID, context);
                },
                set: function(val) {
                    setterFunctions['PDTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.PDType_Desc = value ? (value["PDType_Desc"] ? value["PDType_Desc"] : null) : null;
            privateState.PDTypeID = value ? (value["PDTypeID"] ? value["PDTypeID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_PDType_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_PDType_Desc);
    var registerValidatorBackup = Ref_PDType_Desc.registerValidator;
    Ref_PDType_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_PDType_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_PDType_Desc.relations = relations;
    Ref_PDType_Desc.prototype.isValid = function() {
        return Ref_PDType_Desc.isValid(this);
    };
    Ref_PDType_Desc.prototype.objModelName = "Ref_PDType_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_PDType_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_PDType_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_PDType_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_PDType_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_PDType_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_PostTxhosp_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "last_modified": "last_modified",
        "PostTxhosp_Desc": "PostTxhosp_Desc",
        "PostTxhosp_Id": "PostTxhosp_Id",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "last_modified": "date",
        "PostTxhosp_Desc": "string",
        "PostTxhosp_Id": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["PostTxhosp_Id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_PostTxhosp_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_PostTxhosp_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_PostTxhosp_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PostTxhosp_Desc: function(val, state) {
            context["field"] = "PostTxhosp_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["PostTxhosp_Desc"] : null);
            state['PostTxhosp_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PostTxhosp_Id: function(val, state) {
            context["field"] = "PostTxhosp_Id";
            context["metadata"] = (objectMetadata ? objectMetadata["PostTxhosp_Id"] : null);
            state['PostTxhosp_Id'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_PostTxhosp_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "PostTxhosp_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["PostTxhosp_Desc"] : null);
        privateState.PostTxhosp_Desc = defaultValues ? (defaultValues["PostTxhosp_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PostTxhosp_Desc"], context) : null) : null;
        context["field"] = "PostTxhosp_Id";
        context["metadata"] = (objectMetadata ? objectMetadata["PostTxhosp_Id"] : null);
        privateState.PostTxhosp_Id = defaultValues ? (defaultValues["PostTxhosp_Id"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PostTxhosp_Id"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PostTxhosp_Desc": {
                get: function() {
                    context["field"] = "PostTxhosp_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["PostTxhosp_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PostTxhosp_Desc, context);
                },
                set: function(val) {
                    setterFunctions['PostTxhosp_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PostTxhosp_Id": {
                get: function() {
                    context["field"] = "PostTxhosp_Id";
                    context["metadata"] = (objectMetadata ? objectMetadata["PostTxhosp_Id"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PostTxhosp_Id, context);
                },
                set: function(val) {
                    setterFunctions['PostTxhosp_Id'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.PostTxhosp_Desc = value ? (value["PostTxhosp_Desc"] ? value["PostTxhosp_Desc"] : null) : null;
            privateState.PostTxhosp_Id = value ? (value["PostTxhosp_Id"] ? value["PostTxhosp_Id"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_PostTxhosp_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_PostTxhosp_Desc);
    var registerValidatorBackup = Ref_PostTxhosp_Desc.registerValidator;
    Ref_PostTxhosp_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_PostTxhosp_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_PostTxhosp_Desc.relations = relations;
    Ref_PostTxhosp_Desc.prototype.isValid = function() {
        return Ref_PostTxhosp_Desc.isValid(this);
    };
    Ref_PostTxhosp_Desc.prototype.objModelName = "Ref_PostTxhosp_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_PostTxhosp_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_PostTxhosp_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_PostTxhosp_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_PostTxhosp_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_PostTxhosp_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_PreTxhosp_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "last_modified": "last_modified",
        "PreTxhosp_Desc": "PreTxhosp_Desc",
        "PreTxhosp_Id": "PreTxhosp_Id",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "last_modified": "date",
        "PreTxhosp_Desc": "string",
        "PreTxhosp_Id": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["PreTxhosp_Id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_PreTxhosp_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_PreTxhosp_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_PreTxhosp_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PreTxhosp_Desc: function(val, state) {
            context["field"] = "PreTxhosp_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["PreTxhosp_Desc"] : null);
            state['PreTxhosp_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PreTxhosp_Id: function(val, state) {
            context["field"] = "PreTxhosp_Id";
            context["metadata"] = (objectMetadata ? objectMetadata["PreTxhosp_Id"] : null);
            state['PreTxhosp_Id'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_PreTxhosp_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "PreTxhosp_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["PreTxhosp_Desc"] : null);
        privateState.PreTxhosp_Desc = defaultValues ? (defaultValues["PreTxhosp_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PreTxhosp_Desc"], context) : null) : null;
        context["field"] = "PreTxhosp_Id";
        context["metadata"] = (objectMetadata ? objectMetadata["PreTxhosp_Id"] : null);
        privateState.PreTxhosp_Id = defaultValues ? (defaultValues["PreTxhosp_Id"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PreTxhosp_Id"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PreTxhosp_Desc": {
                get: function() {
                    context["field"] = "PreTxhosp_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["PreTxhosp_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PreTxhosp_Desc, context);
                },
                set: function(val) {
                    setterFunctions['PreTxhosp_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PreTxhosp_Id": {
                get: function() {
                    context["field"] = "PreTxhosp_Id";
                    context["metadata"] = (objectMetadata ? objectMetadata["PreTxhosp_Id"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PreTxhosp_Id, context);
                },
                set: function(val) {
                    setterFunctions['PreTxhosp_Id'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.PreTxhosp_Desc = value ? (value["PreTxhosp_Desc"] ? value["PreTxhosp_Desc"] : null) : null;
            privateState.PreTxhosp_Id = value ? (value["PreTxhosp_Id"] ? value["PreTxhosp_Id"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_PreTxhosp_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_PreTxhosp_Desc);
    var registerValidatorBackup = Ref_PreTxhosp_Desc.registerValidator;
    Ref_PreTxhosp_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_PreTxhosp_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_PreTxhosp_Desc.relations = relations;
    Ref_PreTxhosp_Desc.prototype.isValid = function() {
        return Ref_PreTxhosp_Desc.isValid(this);
    };
    Ref_PreTxhosp_Desc.prototype.objModelName = "Ref_PreTxhosp_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_PreTxhosp_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_PreTxhosp_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_PreTxhosp_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_PreTxhosp_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_PreTxhosp_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_RegionDaVitaClinicMappingInfo/MF_Config',[], function() {
    var mappings = {
        "DaVitaClinicID": "DaVitaClinicID",
        "DELETED": "DELETED",
        "last_modified": "last_modified",
        "RegionID": "RegionID",
    };
    Object.freeze(mappings);
    var typings = {
        "DaVitaClinicID": "number",
        "DELETED": "boolean",
        "last_modified": "date",
        "RegionID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["DaVitaClinicID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_RegionDaVitaClinicMappingInfo"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_RegionDaVitaClinicMappingInfo/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_RegionDaVitaClinicMappingInfo",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DaVitaClinicID: function(val, state) {
            context["field"] = "DaVitaClinicID";
            context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
            state['DaVitaClinicID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        RegionID: function(val, state) {
            context["field"] = "RegionID";
            context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
            state['RegionID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_RegionDaVitaClinicMappingInfo(defaultValues) {
        var privateState = {};
        context["field"] = "DaVitaClinicID";
        context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
        privateState.DaVitaClinicID = defaultValues ? (defaultValues["DaVitaClinicID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DaVitaClinicID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "RegionID";
        context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
        privateState.RegionID = defaultValues ? (defaultValues["RegionID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["RegionID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DaVitaClinicID": {
                get: function() {
                    context["field"] = "DaVitaClinicID";
                    context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DaVitaClinicID, context);
                },
                set: function(val) {
                    setterFunctions['DaVitaClinicID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "RegionID": {
                get: function() {
                    context["field"] = "RegionID";
                    context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.RegionID, context);
                },
                set: function(val) {
                    setterFunctions['RegionID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DaVitaClinicID = value ? (value["DaVitaClinicID"] ? value["DaVitaClinicID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.RegionID = value ? (value["RegionID"] ? value["RegionID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_RegionDaVitaClinicMappingInfo);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_RegionDaVitaClinicMappingInfo);
    var registerValidatorBackup = Ref_RegionDaVitaClinicMappingInfo.registerValidator;
    Ref_RegionDaVitaClinicMappingInfo.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_RegionDaVitaClinicMappingInfo.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_RegionDaVitaClinicMappingInfo.relations = relations;
    Ref_RegionDaVitaClinicMappingInfo.prototype.isValid = function() {
        return Ref_RegionDaVitaClinicMappingInfo.isValid(this);
    };
    Ref_RegionDaVitaClinicMappingInfo.prototype.objModelName = "Ref_RegionDaVitaClinicMappingInfo";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_RegionDaVitaClinicMappingInfo.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_RegionDaVitaClinicMappingInfo", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_RegionDaVitaClinicMappingInfo.clone = function(objectToClone) {
        var clonedObj = new Ref_RegionDaVitaClinicMappingInfo();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_RegionDaVitaClinicMappingInfo;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_RegionHospitalMappingInfo/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "HospitalID": "HospitalID",
        "last_modified": "last_modified",
        "RegionID": "RegionID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "HospitalID": "number",
        "last_modified": "date",
        "RegionID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["HospitalID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_RegionHospitalMappingInfo"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_RegionHospitalMappingInfo/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_RegionHospitalMappingInfo",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HospitalID: function(val, state) {
            context["field"] = "HospitalID";
            context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
            state['HospitalID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        RegionID: function(val, state) {
            context["field"] = "RegionID";
            context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
            state['RegionID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_RegionHospitalMappingInfo(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "HospitalID";
        context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
        privateState.HospitalID = defaultValues ? (defaultValues["HospitalID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HospitalID"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "RegionID";
        context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
        privateState.RegionID = defaultValues ? (defaultValues["RegionID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["RegionID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HospitalID": {
                get: function() {
                    context["field"] = "HospitalID";
                    context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HospitalID, context);
                },
                set: function(val) {
                    setterFunctions['HospitalID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "RegionID": {
                get: function() {
                    context["field"] = "RegionID";
                    context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.RegionID, context);
                },
                set: function(val) {
                    setterFunctions['RegionID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.HospitalID = value ? (value["HospitalID"] ? value["HospitalID"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.RegionID = value ? (value["RegionID"] ? value["RegionID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_RegionHospitalMappingInfo);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_RegionHospitalMappingInfo);
    var registerValidatorBackup = Ref_RegionHospitalMappingInfo.registerValidator;
    Ref_RegionHospitalMappingInfo.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_RegionHospitalMappingInfo.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_RegionHospitalMappingInfo.relations = relations;
    Ref_RegionHospitalMappingInfo.prototype.isValid = function() {
        return Ref_RegionHospitalMappingInfo.isValid(this);
    };
    Ref_RegionHospitalMappingInfo.prototype.objModelName = "Ref_RegionHospitalMappingInfo";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_RegionHospitalMappingInfo.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_RegionHospitalMappingInfo", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_RegionHospitalMappingInfo.clone = function(objectToClone) {
        var clonedObj = new Ref_RegionHospitalMappingInfo();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_RegionHospitalMappingInfo;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_RegionNurseMappingInfo/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "last_modified": "last_modified",
        "NurseID": "NurseID",
        "RegionID": "RegionID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "last_modified": "date",
        "NurseID": "number",
        "RegionID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["NurseID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_RegionNurseMappingInfo"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_RegionNurseMappingInfo/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_RegionNurseMappingInfo",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NurseID: function(val, state) {
            context["field"] = "NurseID";
            context["metadata"] = (objectMetadata ? objectMetadata["NurseID"] : null);
            state['NurseID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        RegionID: function(val, state) {
            context["field"] = "RegionID";
            context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
            state['RegionID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_RegionNurseMappingInfo(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "NurseID";
        context["metadata"] = (objectMetadata ? objectMetadata["NurseID"] : null);
        privateState.NurseID = defaultValues ? (defaultValues["NurseID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NurseID"], context) : null) : null;
        context["field"] = "RegionID";
        context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
        privateState.RegionID = defaultValues ? (defaultValues["RegionID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["RegionID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NurseID": {
                get: function() {
                    context["field"] = "NurseID";
                    context["metadata"] = (objectMetadata ? objectMetadata["NurseID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NurseID, context);
                },
                set: function(val) {
                    setterFunctions['NurseID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "RegionID": {
                get: function() {
                    context["field"] = "RegionID";
                    context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.RegionID, context);
                },
                set: function(val) {
                    setterFunctions['RegionID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.NurseID = value ? (value["NurseID"] ? value["NurseID"] : null) : null;
            privateState.RegionID = value ? (value["RegionID"] ? value["RegionID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_RegionNurseMappingInfo);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_RegionNurseMappingInfo);
    var registerValidatorBackup = Ref_RegionNurseMappingInfo.registerValidator;
    Ref_RegionNurseMappingInfo.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_RegionNurseMappingInfo.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_RegionNurseMappingInfo.relations = relations;
    Ref_RegionNurseMappingInfo.prototype.isValid = function() {
        return Ref_RegionNurseMappingInfo.isValid(this);
    };
    Ref_RegionNurseMappingInfo.prototype.objModelName = "Ref_RegionNurseMappingInfo";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_RegionNurseMappingInfo.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_RegionNurseMappingInfo", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_RegionNurseMappingInfo.clone = function(objectToClone) {
        var clonedObj = new Ref_RegionNurseMappingInfo();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_RegionNurseMappingInfo;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Region_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "last_modified": "last_modified",
        "Region_Desc": "Region_Desc",
        "RegionID": "RegionID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "last_modified": "date",
        "Region_Desc": "string",
        "RegionID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["RegionID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_Region_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Region_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_Region_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Region_Desc: function(val, state) {
            context["field"] = "Region_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["Region_Desc"] : null);
            state['Region_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        RegionID: function(val, state) {
            context["field"] = "RegionID";
            context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
            state['RegionID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_Region_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "Region_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["Region_Desc"] : null);
        privateState.Region_Desc = defaultValues ? (defaultValues["Region_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Region_Desc"], context) : null) : null;
        context["field"] = "RegionID";
        context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
        privateState.RegionID = defaultValues ? (defaultValues["RegionID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["RegionID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Region_Desc": {
                get: function() {
                    context["field"] = "Region_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["Region_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Region_Desc, context);
                },
                set: function(val) {
                    setterFunctions['Region_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "RegionID": {
                get: function() {
                    context["field"] = "RegionID";
                    context["metadata"] = (objectMetadata ? objectMetadata["RegionID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.RegionID, context);
                },
                set: function(val) {
                    setterFunctions['RegionID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.Region_Desc = value ? (value["Region_Desc"] ? value["Region_Desc"] : null) : null;
            privateState.RegionID = value ? (value["RegionID"] ? value["RegionID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_Region_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_Region_Desc);
    var registerValidatorBackup = Ref_Region_Desc.registerValidator;
    Ref_Region_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_Region_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_Region_Desc.relations = relations;
    Ref_Region_Desc.prototype.isValid = function() {
        return Ref_Region_Desc.isValid(this);
    };
    Ref_Region_Desc.prototype.objModelName = "Ref_Region_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_Region_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_Region_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_Region_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_Region_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_Region_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Room_Type_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "last_modified": "last_modified",
        "Room_Type_Desc": "Room_Type_Desc",
        "Room_TypeID": "Room_TypeID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "last_modified": "date",
        "Room_Type_Desc": "string",
        "Room_TypeID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["Room_TypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_Room_Type_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_Room_Type_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_Room_Type_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Room_Type_Desc: function(val, state) {
            context["field"] = "Room_Type_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["Room_Type_Desc"] : null);
            state['Room_Type_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Room_TypeID: function(val, state) {
            context["field"] = "Room_TypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["Room_TypeID"] : null);
            state['Room_TypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_Room_Type_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "Room_Type_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["Room_Type_Desc"] : null);
        privateState.Room_Type_Desc = defaultValues ? (defaultValues["Room_Type_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Room_Type_Desc"], context) : null) : null;
        context["field"] = "Room_TypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["Room_TypeID"] : null);
        privateState.Room_TypeID = defaultValues ? (defaultValues["Room_TypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Room_TypeID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Room_Type_Desc": {
                get: function() {
                    context["field"] = "Room_Type_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["Room_Type_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Room_Type_Desc, context);
                },
                set: function(val) {
                    setterFunctions['Room_Type_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Room_TypeID": {
                get: function() {
                    context["field"] = "Room_TypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["Room_TypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Room_TypeID, context);
                },
                set: function(val) {
                    setterFunctions['Room_TypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.Room_Type_Desc = value ? (value["Room_Type_Desc"] ? value["Room_Type_Desc"] : null) : null;
            privateState.Room_TypeID = value ? (value["Room_TypeID"] ? value["Room_TypeID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_Room_Type_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_Room_Type_Desc);
    var registerValidatorBackup = Ref_Room_Type_Desc.registerValidator;
    Ref_Room_Type_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_Room_Type_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_Room_Type_Desc.relations = relations;
    Ref_Room_Type_Desc.prototype.isValid = function() {
        return Ref_Room_Type_Desc.isValid(this);
    };
    Ref_Room_Type_Desc.prototype.objModelName = "Ref_Room_Type_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_Room_Type_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_Room_Type_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_Room_Type_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_Room_Type_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_Room_Type_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_TreatmentQuestions_Desc/MF_Config',[], function() {
    var mappings = {
        "DELETED": "DELETED",
        "Is_Visible": "Is_Visible",
        "last_modified": "last_modified",
        "Sort_Order": "Sort_Order",
        "TreatmentType_Desc": "TreatmentType_Desc",
        "TreatmentType_Options": "TreatmentType_Options",
        "TreatmentType_Question": "TreatmentType_Question",
        "TreatmentTypeID": "TreatmentTypeID",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETED": "boolean",
        "Is_Visible": "number",
        "last_modified": "date",
        "Sort_Order": "number",
        "TreatmentType_Desc": "string",
        "TreatmentType_Options": "string",
        "TreatmentType_Question": "string",
        "TreatmentTypeID": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["TreatmentType_Desc", "TreatmentTypeID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "InBound",
        tableName: "Ref_TreatmentQuestions_Desc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('InBound/Ref_TreatmentQuestions_Desc/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_TreatmentQuestions_Desc",
        "objectService": "InBound"
    };
    var setterFunctions = {
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Is_Visible: function(val, state) {
            context["field"] = "Is_Visible";
            context["metadata"] = (objectMetadata ? objectMetadata["Is_Visible"] : null);
            state['Is_Visible'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Sort_Order: function(val, state) {
            context["field"] = "Sort_Order";
            context["metadata"] = (objectMetadata ? objectMetadata["Sort_Order"] : null);
            state['Sort_Order'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TreatmentType_Desc: function(val, state) {
            context["field"] = "TreatmentType_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Desc"] : null);
            state['TreatmentType_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TreatmentType_Options: function(val, state) {
            context["field"] = "TreatmentType_Options";
            context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Options"] : null);
            state['TreatmentType_Options'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TreatmentType_Question: function(val, state) {
            context["field"] = "TreatmentType_Question";
            context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Question"] : null);
            state['TreatmentType_Question'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TreatmentTypeID: function(val, state) {
            context["field"] = "TreatmentTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["TreatmentTypeID"] : null);
            state['TreatmentTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_TreatmentQuestions_Desc(defaultValues) {
        var privateState = {};
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "Is_Visible";
        context["metadata"] = (objectMetadata ? objectMetadata["Is_Visible"] : null);
        privateState.Is_Visible = defaultValues ? (defaultValues["Is_Visible"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Is_Visible"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "Sort_Order";
        context["metadata"] = (objectMetadata ? objectMetadata["Sort_Order"] : null);
        privateState.Sort_Order = defaultValues ? (defaultValues["Sort_Order"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Sort_Order"], context) : null) : null;
        context["field"] = "TreatmentType_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Desc"] : null);
        privateState.TreatmentType_Desc = defaultValues ? (defaultValues["TreatmentType_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TreatmentType_Desc"], context) : null) : null;
        context["field"] = "TreatmentType_Options";
        context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Options"] : null);
        privateState.TreatmentType_Options = defaultValues ? (defaultValues["TreatmentType_Options"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TreatmentType_Options"], context) : null) : null;
        context["field"] = "TreatmentType_Question";
        context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Question"] : null);
        privateState.TreatmentType_Question = defaultValues ? (defaultValues["TreatmentType_Question"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TreatmentType_Question"], context) : null) : null;
        context["field"] = "TreatmentTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["TreatmentTypeID"] : null);
        privateState.TreatmentTypeID = defaultValues ? (defaultValues["TreatmentTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TreatmentTypeID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Is_Visible": {
                get: function() {
                    context["field"] = "Is_Visible";
                    context["metadata"] = (objectMetadata ? objectMetadata["Is_Visible"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Is_Visible, context);
                },
                set: function(val) {
                    setterFunctions['Is_Visible'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Sort_Order": {
                get: function() {
                    context["field"] = "Sort_Order";
                    context["metadata"] = (objectMetadata ? objectMetadata["Sort_Order"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Sort_Order, context);
                },
                set: function(val) {
                    setterFunctions['Sort_Order'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TreatmentType_Desc": {
                get: function() {
                    context["field"] = "TreatmentType_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TreatmentType_Desc, context);
                },
                set: function(val) {
                    setterFunctions['TreatmentType_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TreatmentType_Options": {
                get: function() {
                    context["field"] = "TreatmentType_Options";
                    context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Options"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TreatmentType_Options, context);
                },
                set: function(val) {
                    setterFunctions['TreatmentType_Options'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TreatmentType_Question": {
                get: function() {
                    context["field"] = "TreatmentType_Question";
                    context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Question"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TreatmentType_Question, context);
                },
                set: function(val) {
                    setterFunctions['TreatmentType_Question'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TreatmentTypeID": {
                get: function() {
                    context["field"] = "TreatmentTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["TreatmentTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TreatmentTypeID, context);
                },
                set: function(val) {
                    setterFunctions['TreatmentTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.Is_Visible = value ? (value["Is_Visible"] ? value["Is_Visible"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.Sort_Order = value ? (value["Sort_Order"] ? value["Sort_Order"] : null) : null;
            privateState.TreatmentType_Desc = value ? (value["TreatmentType_Desc"] ? value["TreatmentType_Desc"] : null) : null;
            privateState.TreatmentType_Options = value ? (value["TreatmentType_Options"] ? value["TreatmentType_Options"] : null) : null;
            privateState.TreatmentType_Question = value ? (value["TreatmentType_Question"] ? value["TreatmentType_Question"] : null) : null;
            privateState.TreatmentTypeID = value ? (value["TreatmentTypeID"] ? value["TreatmentTypeID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_TreatmentQuestions_Desc);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_TreatmentQuestions_Desc);
    var registerValidatorBackup = Ref_TreatmentQuestions_Desc.registerValidator;
    Ref_TreatmentQuestions_Desc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_TreatmentQuestions_Desc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_TreatmentQuestions_Desc.relations = relations;
    Ref_TreatmentQuestions_Desc.prototype.isValid = function() {
        return Ref_TreatmentQuestions_Desc.isValid(this);
    };
    Ref_TreatmentQuestions_Desc.prototype.objModelName = "Ref_TreatmentQuestions_Desc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_TreatmentQuestions_Desc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("InBound", "Ref_TreatmentQuestions_Desc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_TreatmentQuestions_Desc.clone = function(objectToClone) {
        var clonedObj = new Ref_TreatmentQuestions_Desc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_TreatmentQuestions_Desc;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('NurseHospital/Ref_Hospital/MF_Config',[], function() {
    var mappings = {
        "appnurseID": "appnurseID",
        "Hospital_Desc": "Hospital_Desc",
        "HospitalID": "HospitalID",
    };
    Object.freeze(mappings);
    var typings = {
        "appnurseID": "string",
        "Hospital_Desc": "string",
        "HospitalID": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["HospitalID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "NurseHospital",
        tableName: "Ref_Hospital"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('NurseHospital/Ref_Hospital/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Ref_Hospital",
        "objectService": "NurseHospital"
    };
    var setterFunctions = {
        appnurseID: function(val, state) {
            context["field"] = "appnurseID";
            context["metadata"] = (objectMetadata ? objectMetadata["appnurseID"] : null);
            state['appnurseID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Hospital_Desc: function(val, state) {
            context["field"] = "Hospital_Desc";
            context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Desc"] : null);
            state['Hospital_Desc'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HospitalID: function(val, state) {
            context["field"] = "HospitalID";
            context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
            state['HospitalID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Ref_Hospital(defaultValues) {
        var privateState = {};
        context["field"] = "appnurseID";
        context["metadata"] = (objectMetadata ? objectMetadata["appnurseID"] : null);
        privateState.appnurseID = defaultValues ? (defaultValues["appnurseID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["appnurseID"], context) : null) : null;
        context["field"] = "Hospital_Desc";
        context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Desc"] : null);
        privateState.Hospital_Desc = defaultValues ? (defaultValues["Hospital_Desc"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Hospital_Desc"], context) : null) : null;
        context["field"] = "HospitalID";
        context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
        privateState.HospitalID = defaultValues ? (defaultValues["HospitalID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HospitalID"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "appnurseID": {
                get: function() {
                    context["field"] = "appnurseID";
                    context["metadata"] = (objectMetadata ? objectMetadata["appnurseID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.appnurseID, context);
                },
                set: function(val) {
                    setterFunctions['appnurseID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Hospital_Desc": {
                get: function() {
                    context["field"] = "Hospital_Desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Desc"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Hospital_Desc, context);
                },
                set: function(val) {
                    setterFunctions['Hospital_Desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HospitalID": {
                get: function() {
                    context["field"] = "HospitalID";
                    context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HospitalID, context);
                },
                set: function(val) {
                    setterFunctions['HospitalID'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.appnurseID = value ? (value["appnurseID"] ? value["appnurseID"] : null) : null;
            privateState.Hospital_Desc = value ? (value["Hospital_Desc"] ? value["Hospital_Desc"] : null) : null;
            privateState.HospitalID = value ? (value["HospitalID"] ? value["HospitalID"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Ref_Hospital);
    //Create new class level validator object
    BaseModel.Validator.call(Ref_Hospital);
    var registerValidatorBackup = Ref_Hospital.registerValidator;
    Ref_Hospital.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Ref_Hospital.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Ref_Hospital.relations = relations;
    Ref_Hospital.prototype.isValid = function() {
        return Ref_Hospital.isValid(this);
    };
    Ref_Hospital.prototype.objModelName = "Ref_Hospital";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Ref_Hospital.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("NurseHospital", "Ref_Hospital", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Ref_Hospital.clone = function(objectToClone) {
        var clonedObj = new Ref_Hospital();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Ref_Hospital;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('OutBound/PatientTreatmentInfo/MF_Config',[], function() {
    var mappings = {
        "AccessTypeID": "AccessTypeID",
        "AddtlSvcsTypeID": "AddtlSvcsTypeID",
        "ApheresisTypeID": "ApheresisTypeID",
        "App_Version_Number": "App_Version_Number",
        "Blood_Administration_Qty": "Blood_Administration_Qty",
        "Comments": "Comments",
        "CRRTTypeID": "CRRTTypeID",
        "CRRTUltrafiltrationTypeID": "CRRTUltrafiltrationTypeID",
        "CxlTypeID": "CxlTypeID",
        "Date_Of_Birth": "Date_Of_Birth",
        "DaVitaClinicID": "DaVitaClinicID",
        "DELETED": "DELETED",
        "Device_PIN": "Device_PIN",
        "Dialysate": "Dialysate",
        "First_Name": "First_Name",
        "HbsAbID": "HbsAbID",
        "HbsAgID": "HbsAgID",
        "HemoTypeID": "HemoTypeID",
        "Hospital_Delay_Time_Units": "Hospital_Delay_Time_Units",
        "HospitalID": "HospitalID",
        "ID": "ID",
        "Is_End_Date_Modified": "Is_End_Date_Modified",
        "Is_End_Time_Modified": "Is_End_Time_Modified",
        "Is_Start_Date_Modified": "Is_Start_Date_Modified",
        "Is_Start_Time_Modified": "Is_Start_Time_Modified",
        "Is_Synched_With_AXDB": "Is_Synched_With_AXDB",
        "IV_Antibiotic": "IV_Antibiotic",
        "last_modified": "last_modified",
        "Last_Name": "Last_Name",
        "Medical_Record_Number": "Medical_Record_Number",
        "Nurse_UserName": "Nurse_UserName",
        "Nursing_Service_Time_Units": "Nursing_Service_Time_Units",
        "NursingServiceID": "NursingServiceID",
        "PDTypeID": "PDTypeID",
        "Pediatric": "Pediatric",
        "Physician_First_Name": "Physician_First_Name",
        "Physician_Last_Name": "Physician_Last_Name",
        "posttx_hosp_id": "posttx_hosp_id",
        "pretx_hosp_id": "pretx_hosp_id",
        "Removal_Of_Non_Tunneled_Catheter": "Removal_Of_Non_Tunneled_Catheter",
        "Room_Number": "Room_Number",
        "RoomTypeID": "RoomTypeID",
        "Stat_Treatment": "Stat_Treatment",
        "Treatment_Date": "Treatment_Date",
        "Treatment_End_Date": "Treatment_End_Date",
        "Treatment_End_Time": "Treatment_End_Time",
        "Treatment_Start_Time": "Treatment_Start_Time",
        "TreatmentType_Results": "TreatmentType_Results",
        "TreatmentTypeID": "TreatmentTypeID",
        "Upgraded_Dialyzer": "Upgraded_Dialyzer",
    };
    Object.freeze(mappings);
    var typings = {
        "AccessTypeID": "number",
        "AddtlSvcsTypeID": "number",
        "ApheresisTypeID": "number",
        "App_Version_Number": "string",
        "Blood_Administration_Qty": "number",
        "Comments": "string",
        "CRRTTypeID": "number",
        "CRRTUltrafiltrationTypeID": "number",
        "CxlTypeID": "number",
        "Date_Of_Birth": "date",
        "DaVitaClinicID": "number",
        "DELETED": "boolean",
        "Device_PIN": "string",
        "Dialysate": "number",
        "First_Name": "string",
        "HbsAbID": "number",
        "HbsAgID": "number",
        "HemoTypeID": "number",
        "Hospital_Delay_Time_Units": "number",
        "HospitalID": "number",
        "ID": "number",
        "Is_End_Date_Modified": "number",
        "Is_End_Time_Modified": "number",
        "Is_Start_Date_Modified": "number",
        "Is_Start_Time_Modified": "number",
        "Is_Synched_With_AXDB": "number",
        "IV_Antibiotic": "number",
        "last_modified": "date",
        "Last_Name": "string",
        "Medical_Record_Number": "string",
        "Nurse_UserName": "string",
        "Nursing_Service_Time_Units": "number",
        "NursingServiceID": "number",
        "PDTypeID": "number",
        "Pediatric": "number",
        "Physician_First_Name": "string",
        "Physician_Last_Name": "string",
        "posttx_hosp_id": "number",
        "pretx_hosp_id": "number",
        "Removal_Of_Non_Tunneled_Catheter": "number",
        "Room_Number": "string",
        "RoomTypeID": "number",
        "Stat_Treatment": "number",
        "Treatment_Date": "date",
        "Treatment_End_Date": "date",
        "Treatment_End_Time": "string",
        "Treatment_Start_Time": "string",
        "TreatmentType_Results": "string",
        "TreatmentTypeID": "number",
        "Upgraded_Dialyzer": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["ID", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "OutBound",
        tableName: "PatientTreatmentInfo"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('OutBound/PatientTreatmentInfo/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "PatientTreatmentInfo",
        "objectService": "OutBound"
    };
    var setterFunctions = {
        AccessTypeID: function(val, state) {
            context["field"] = "AccessTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["AccessTypeID"] : null);
            state['AccessTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        AddtlSvcsTypeID: function(val, state) {
            context["field"] = "AddtlSvcsTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["AddtlSvcsTypeID"] : null);
            state['AddtlSvcsTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ApheresisTypeID: function(val, state) {
            context["field"] = "ApheresisTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["ApheresisTypeID"] : null);
            state['ApheresisTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        App_Version_Number: function(val, state) {
            context["field"] = "App_Version_Number";
            context["metadata"] = (objectMetadata ? objectMetadata["App_Version_Number"] : null);
            state['App_Version_Number'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Blood_Administration_Qty: function(val, state) {
            context["field"] = "Blood_Administration_Qty";
            context["metadata"] = (objectMetadata ? objectMetadata["Blood_Administration_Qty"] : null);
            state['Blood_Administration_Qty'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Comments: function(val, state) {
            context["field"] = "Comments";
            context["metadata"] = (objectMetadata ? objectMetadata["Comments"] : null);
            state['Comments'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CRRTTypeID: function(val, state) {
            context["field"] = "CRRTTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["CRRTTypeID"] : null);
            state['CRRTTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CRRTUltrafiltrationTypeID: function(val, state) {
            context["field"] = "CRRTUltrafiltrationTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationTypeID"] : null);
            state['CRRTUltrafiltrationTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CxlTypeID: function(val, state) {
            context["field"] = "CxlTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["CxlTypeID"] : null);
            state['CxlTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Date_Of_Birth: function(val, state) {
            context["field"] = "Date_Of_Birth";
            context["metadata"] = (objectMetadata ? objectMetadata["Date_Of_Birth"] : null);
            state['Date_Of_Birth'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DaVitaClinicID: function(val, state) {
            context["field"] = "DaVitaClinicID";
            context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
            state['DaVitaClinicID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETED: function(val, state) {
            context["field"] = "DELETED";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
            state['DELETED'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Device_PIN: function(val, state) {
            context["field"] = "Device_PIN";
            context["metadata"] = (objectMetadata ? objectMetadata["Device_PIN"] : null);
            state['Device_PIN'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Dialysate: function(val, state) {
            context["field"] = "Dialysate";
            context["metadata"] = (objectMetadata ? objectMetadata["Dialysate"] : null);
            state['Dialysate'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        First_Name: function(val, state) {
            context["field"] = "First_Name";
            context["metadata"] = (objectMetadata ? objectMetadata["First_Name"] : null);
            state['First_Name'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HbsAbID: function(val, state) {
            context["field"] = "HbsAbID";
            context["metadata"] = (objectMetadata ? objectMetadata["HbsAbID"] : null);
            state['HbsAbID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HbsAgID: function(val, state) {
            context["field"] = "HbsAgID";
            context["metadata"] = (objectMetadata ? objectMetadata["HbsAgID"] : null);
            state['HbsAgID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HemoTypeID: function(val, state) {
            context["field"] = "HemoTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["HemoTypeID"] : null);
            state['HemoTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Hospital_Delay_Time_Units: function(val, state) {
            context["field"] = "Hospital_Delay_Time_Units";
            context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Delay_Time_Units"] : null);
            state['Hospital_Delay_Time_Units'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HospitalID: function(val, state) {
            context["field"] = "HospitalID";
            context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
            state['HospitalID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ID: function(val, state) {
            context["field"] = "ID";
            context["metadata"] = (objectMetadata ? objectMetadata["ID"] : null);
            state['ID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Is_End_Date_Modified: function(val, state) {
            context["field"] = "Is_End_Date_Modified";
            context["metadata"] = (objectMetadata ? objectMetadata["Is_End_Date_Modified"] : null);
            state['Is_End_Date_Modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Is_End_Time_Modified: function(val, state) {
            context["field"] = "Is_End_Time_Modified";
            context["metadata"] = (objectMetadata ? objectMetadata["Is_End_Time_Modified"] : null);
            state['Is_End_Time_Modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Is_Start_Date_Modified: function(val, state) {
            context["field"] = "Is_Start_Date_Modified";
            context["metadata"] = (objectMetadata ? objectMetadata["Is_Start_Date_Modified"] : null);
            state['Is_Start_Date_Modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Is_Start_Time_Modified: function(val, state) {
            context["field"] = "Is_Start_Time_Modified";
            context["metadata"] = (objectMetadata ? objectMetadata["Is_Start_Time_Modified"] : null);
            state['Is_Start_Time_Modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Is_Synched_With_AXDB: function(val, state) {
            context["field"] = "Is_Synched_With_AXDB";
            context["metadata"] = (objectMetadata ? objectMetadata["Is_Synched_With_AXDB"] : null);
            state['Is_Synched_With_AXDB'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        IV_Antibiotic: function(val, state) {
            context["field"] = "IV_Antibiotic";
            context["metadata"] = (objectMetadata ? objectMetadata["IV_Antibiotic"] : null);
            state['IV_Antibiotic'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        last_modified: function(val, state) {
            context["field"] = "last_modified";
            context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
            state['last_modified'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Last_Name: function(val, state) {
            context["field"] = "Last_Name";
            context["metadata"] = (objectMetadata ? objectMetadata["Last_Name"] : null);
            state['Last_Name'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Medical_Record_Number: function(val, state) {
            context["field"] = "Medical_Record_Number";
            context["metadata"] = (objectMetadata ? objectMetadata["Medical_Record_Number"] : null);
            state['Medical_Record_Number'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Nurse_UserName: function(val, state) {
            context["field"] = "Nurse_UserName";
            context["metadata"] = (objectMetadata ? objectMetadata["Nurse_UserName"] : null);
            state['Nurse_UserName'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Nursing_Service_Time_Units: function(val, state) {
            context["field"] = "Nursing_Service_Time_Units";
            context["metadata"] = (objectMetadata ? objectMetadata["Nursing_Service_Time_Units"] : null);
            state['Nursing_Service_Time_Units'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NursingServiceID: function(val, state) {
            context["field"] = "NursingServiceID";
            context["metadata"] = (objectMetadata ? objectMetadata["NursingServiceID"] : null);
            state['NursingServiceID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PDTypeID: function(val, state) {
            context["field"] = "PDTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["PDTypeID"] : null);
            state['PDTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Pediatric: function(val, state) {
            context["field"] = "Pediatric";
            context["metadata"] = (objectMetadata ? objectMetadata["Pediatric"] : null);
            state['Pediatric'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Physician_First_Name: function(val, state) {
            context["field"] = "Physician_First_Name";
            context["metadata"] = (objectMetadata ? objectMetadata["Physician_First_Name"] : null);
            state['Physician_First_Name'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Physician_Last_Name: function(val, state) {
            context["field"] = "Physician_Last_Name";
            context["metadata"] = (objectMetadata ? objectMetadata["Physician_Last_Name"] : null);
            state['Physician_Last_Name'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        posttx_hosp_id: function(val, state) {
            context["field"] = "posttx_hosp_id";
            context["metadata"] = (objectMetadata ? objectMetadata["posttx_hosp_id"] : null);
            state['posttx_hosp_id'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        pretx_hosp_id: function(val, state) {
            context["field"] = "pretx_hosp_id";
            context["metadata"] = (objectMetadata ? objectMetadata["pretx_hosp_id"] : null);
            state['pretx_hosp_id'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Removal_Of_Non_Tunneled_Catheter: function(val, state) {
            context["field"] = "Removal_Of_Non_Tunneled_Catheter";
            context["metadata"] = (objectMetadata ? objectMetadata["Removal_Of_Non_Tunneled_Catheter"] : null);
            state['Removal_Of_Non_Tunneled_Catheter'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Room_Number: function(val, state) {
            context["field"] = "Room_Number";
            context["metadata"] = (objectMetadata ? objectMetadata["Room_Number"] : null);
            state['Room_Number'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        RoomTypeID: function(val, state) {
            context["field"] = "RoomTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["RoomTypeID"] : null);
            state['RoomTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Stat_Treatment: function(val, state) {
            context["field"] = "Stat_Treatment";
            context["metadata"] = (objectMetadata ? objectMetadata["Stat_Treatment"] : null);
            state['Stat_Treatment'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Treatment_Date: function(val, state) {
            context["field"] = "Treatment_Date";
            context["metadata"] = (objectMetadata ? objectMetadata["Treatment_Date"] : null);
            state['Treatment_Date'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Treatment_End_Date: function(val, state) {
            context["field"] = "Treatment_End_Date";
            context["metadata"] = (objectMetadata ? objectMetadata["Treatment_End_Date"] : null);
            state['Treatment_End_Date'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Treatment_End_Time: function(val, state) {
            context["field"] = "Treatment_End_Time";
            context["metadata"] = (objectMetadata ? objectMetadata["Treatment_End_Time"] : null);
            state['Treatment_End_Time'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Treatment_Start_Time: function(val, state) {
            context["field"] = "Treatment_Start_Time";
            context["metadata"] = (objectMetadata ? objectMetadata["Treatment_Start_Time"] : null);
            state['Treatment_Start_Time'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TreatmentType_Results: function(val, state) {
            context["field"] = "TreatmentType_Results";
            context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Results"] : null);
            state['TreatmentType_Results'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TreatmentTypeID: function(val, state) {
            context["field"] = "TreatmentTypeID";
            context["metadata"] = (objectMetadata ? objectMetadata["TreatmentTypeID"] : null);
            state['TreatmentTypeID'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Upgraded_Dialyzer: function(val, state) {
            context["field"] = "Upgraded_Dialyzer";
            context["metadata"] = (objectMetadata ? objectMetadata["Upgraded_Dialyzer"] : null);
            state['Upgraded_Dialyzer'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function PatientTreatmentInfo(defaultValues) {
        var privateState = {};
        context["field"] = "AccessTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["AccessTypeID"] : null);
        privateState.AccessTypeID = defaultValues ? (defaultValues["AccessTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["AccessTypeID"], context) : null) : null;
        context["field"] = "AddtlSvcsTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["AddtlSvcsTypeID"] : null);
        privateState.AddtlSvcsTypeID = defaultValues ? (defaultValues["AddtlSvcsTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["AddtlSvcsTypeID"], context) : null) : null;
        context["field"] = "ApheresisTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["ApheresisTypeID"] : null);
        privateState.ApheresisTypeID = defaultValues ? (defaultValues["ApheresisTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ApheresisTypeID"], context) : null) : null;
        context["field"] = "App_Version_Number";
        context["metadata"] = (objectMetadata ? objectMetadata["App_Version_Number"] : null);
        privateState.App_Version_Number = defaultValues ? (defaultValues["App_Version_Number"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["App_Version_Number"], context) : null) : null;
        context["field"] = "Blood_Administration_Qty";
        context["metadata"] = (objectMetadata ? objectMetadata["Blood_Administration_Qty"] : null);
        privateState.Blood_Administration_Qty = defaultValues ? (defaultValues["Blood_Administration_Qty"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Blood_Administration_Qty"], context) : null) : null;
        context["field"] = "Comments";
        context["metadata"] = (objectMetadata ? objectMetadata["Comments"] : null);
        privateState.Comments = defaultValues ? (defaultValues["Comments"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Comments"], context) : null) : null;
        context["field"] = "CRRTTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["CRRTTypeID"] : null);
        privateState.CRRTTypeID = defaultValues ? (defaultValues["CRRTTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CRRTTypeID"], context) : null) : null;
        context["field"] = "CRRTUltrafiltrationTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationTypeID"] : null);
        privateState.CRRTUltrafiltrationTypeID = defaultValues ? (defaultValues["CRRTUltrafiltrationTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CRRTUltrafiltrationTypeID"], context) : null) : null;
        context["field"] = "CxlTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["CxlTypeID"] : null);
        privateState.CxlTypeID = defaultValues ? (defaultValues["CxlTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CxlTypeID"], context) : null) : null;
        context["field"] = "Date_Of_Birth";
        context["metadata"] = (objectMetadata ? objectMetadata["Date_Of_Birth"] : null);
        privateState.Date_Of_Birth = defaultValues ? (defaultValues["Date_Of_Birth"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Date_Of_Birth"], context) : null) : null;
        context["field"] = "DaVitaClinicID";
        context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
        privateState.DaVitaClinicID = defaultValues ? (defaultValues["DaVitaClinicID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DaVitaClinicID"], context) : null) : null;
        context["field"] = "DELETED";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
        privateState.DELETED = defaultValues ? (defaultValues["DELETED"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETED"], context) : null) : null;
        context["field"] = "Device_PIN";
        context["metadata"] = (objectMetadata ? objectMetadata["Device_PIN"] : null);
        privateState.Device_PIN = defaultValues ? (defaultValues["Device_PIN"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Device_PIN"], context) : null) : null;
        context["field"] = "Dialysate";
        context["metadata"] = (objectMetadata ? objectMetadata["Dialysate"] : null);
        privateState.Dialysate = defaultValues ? (defaultValues["Dialysate"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Dialysate"], context) : null) : null;
        context["field"] = "First_Name";
        context["metadata"] = (objectMetadata ? objectMetadata["First_Name"] : null);
        privateState.First_Name = defaultValues ? (defaultValues["First_Name"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["First_Name"], context) : null) : null;
        context["field"] = "HbsAbID";
        context["metadata"] = (objectMetadata ? objectMetadata["HbsAbID"] : null);
        privateState.HbsAbID = defaultValues ? (defaultValues["HbsAbID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HbsAbID"], context) : null) : null;
        context["field"] = "HbsAgID";
        context["metadata"] = (objectMetadata ? objectMetadata["HbsAgID"] : null);
        privateState.HbsAgID = defaultValues ? (defaultValues["HbsAgID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HbsAgID"], context) : null) : null;
        context["field"] = "HemoTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["HemoTypeID"] : null);
        privateState.HemoTypeID = defaultValues ? (defaultValues["HemoTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HemoTypeID"], context) : null) : null;
        context["field"] = "Hospital_Delay_Time_Units";
        context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Delay_Time_Units"] : null);
        privateState.Hospital_Delay_Time_Units = defaultValues ? (defaultValues["Hospital_Delay_Time_Units"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Hospital_Delay_Time_Units"], context) : null) : null;
        context["field"] = "HospitalID";
        context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
        privateState.HospitalID = defaultValues ? (defaultValues["HospitalID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HospitalID"], context) : null) : null;
        context["field"] = "ID";
        context["metadata"] = (objectMetadata ? objectMetadata["ID"] : null);
        privateState.ID = defaultValues ? (defaultValues["ID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ID"], context) : null) : null;
        context["field"] = "Is_End_Date_Modified";
        context["metadata"] = (objectMetadata ? objectMetadata["Is_End_Date_Modified"] : null);
        privateState.Is_End_Date_Modified = defaultValues ? (defaultValues["Is_End_Date_Modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Is_End_Date_Modified"], context) : null) : null;
        context["field"] = "Is_End_Time_Modified";
        context["metadata"] = (objectMetadata ? objectMetadata["Is_End_Time_Modified"] : null);
        privateState.Is_End_Time_Modified = defaultValues ? (defaultValues["Is_End_Time_Modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Is_End_Time_Modified"], context) : null) : null;
        context["field"] = "Is_Start_Date_Modified";
        context["metadata"] = (objectMetadata ? objectMetadata["Is_Start_Date_Modified"] : null);
        privateState.Is_Start_Date_Modified = defaultValues ? (defaultValues["Is_Start_Date_Modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Is_Start_Date_Modified"], context) : null) : null;
        context["field"] = "Is_Start_Time_Modified";
        context["metadata"] = (objectMetadata ? objectMetadata["Is_Start_Time_Modified"] : null);
        privateState.Is_Start_Time_Modified = defaultValues ? (defaultValues["Is_Start_Time_Modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Is_Start_Time_Modified"], context) : null) : null;
        context["field"] = "Is_Synched_With_AXDB";
        context["metadata"] = (objectMetadata ? objectMetadata["Is_Synched_With_AXDB"] : null);
        privateState.Is_Synched_With_AXDB = defaultValues ? (defaultValues["Is_Synched_With_AXDB"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Is_Synched_With_AXDB"], context) : null) : null;
        context["field"] = "IV_Antibiotic";
        context["metadata"] = (objectMetadata ? objectMetadata["IV_Antibiotic"] : null);
        privateState.IV_Antibiotic = defaultValues ? (defaultValues["IV_Antibiotic"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["IV_Antibiotic"], context) : null) : null;
        context["field"] = "last_modified";
        context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
        privateState.last_modified = defaultValues ? (defaultValues["last_modified"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["last_modified"], context) : null) : null;
        context["field"] = "Last_Name";
        context["metadata"] = (objectMetadata ? objectMetadata["Last_Name"] : null);
        privateState.Last_Name = defaultValues ? (defaultValues["Last_Name"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Last_Name"], context) : null) : null;
        context["field"] = "Medical_Record_Number";
        context["metadata"] = (objectMetadata ? objectMetadata["Medical_Record_Number"] : null);
        privateState.Medical_Record_Number = defaultValues ? (defaultValues["Medical_Record_Number"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Medical_Record_Number"], context) : null) : null;
        context["field"] = "Nurse_UserName";
        context["metadata"] = (objectMetadata ? objectMetadata["Nurse_UserName"] : null);
        privateState.Nurse_UserName = defaultValues ? (defaultValues["Nurse_UserName"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Nurse_UserName"], context) : null) : null;
        context["field"] = "Nursing_Service_Time_Units";
        context["metadata"] = (objectMetadata ? objectMetadata["Nursing_Service_Time_Units"] : null);
        privateState.Nursing_Service_Time_Units = defaultValues ? (defaultValues["Nursing_Service_Time_Units"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Nursing_Service_Time_Units"], context) : null) : null;
        context["field"] = "NursingServiceID";
        context["metadata"] = (objectMetadata ? objectMetadata["NursingServiceID"] : null);
        privateState.NursingServiceID = defaultValues ? (defaultValues["NursingServiceID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NursingServiceID"], context) : null) : null;
        context["field"] = "PDTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["PDTypeID"] : null);
        privateState.PDTypeID = defaultValues ? (defaultValues["PDTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PDTypeID"], context) : null) : null;
        context["field"] = "Pediatric";
        context["metadata"] = (objectMetadata ? objectMetadata["Pediatric"] : null);
        privateState.Pediatric = defaultValues ? (defaultValues["Pediatric"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Pediatric"], context) : null) : null;
        context["field"] = "Physician_First_Name";
        context["metadata"] = (objectMetadata ? objectMetadata["Physician_First_Name"] : null);
        privateState.Physician_First_Name = defaultValues ? (defaultValues["Physician_First_Name"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Physician_First_Name"], context) : null) : null;
        context["field"] = "Physician_Last_Name";
        context["metadata"] = (objectMetadata ? objectMetadata["Physician_Last_Name"] : null);
        privateState.Physician_Last_Name = defaultValues ? (defaultValues["Physician_Last_Name"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Physician_Last_Name"], context) : null) : null;
        context["field"] = "posttx_hosp_id";
        context["metadata"] = (objectMetadata ? objectMetadata["posttx_hosp_id"] : null);
        privateState.posttx_hosp_id = defaultValues ? (defaultValues["posttx_hosp_id"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["posttx_hosp_id"], context) : null) : null;
        context["field"] = "pretx_hosp_id";
        context["metadata"] = (objectMetadata ? objectMetadata["pretx_hosp_id"] : null);
        privateState.pretx_hosp_id = defaultValues ? (defaultValues["pretx_hosp_id"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["pretx_hosp_id"], context) : null) : null;
        context["field"] = "Removal_Of_Non_Tunneled_Catheter";
        context["metadata"] = (objectMetadata ? objectMetadata["Removal_Of_Non_Tunneled_Catheter"] : null);
        privateState.Removal_Of_Non_Tunneled_Catheter = defaultValues ? (defaultValues["Removal_Of_Non_Tunneled_Catheter"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Removal_Of_Non_Tunneled_Catheter"], context) : null) : null;
        context["field"] = "Room_Number";
        context["metadata"] = (objectMetadata ? objectMetadata["Room_Number"] : null);
        privateState.Room_Number = defaultValues ? (defaultValues["Room_Number"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Room_Number"], context) : null) : null;
        context["field"] = "RoomTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["RoomTypeID"] : null);
        privateState.RoomTypeID = defaultValues ? (defaultValues["RoomTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["RoomTypeID"], context) : null) : null;
        context["field"] = "Stat_Treatment";
        context["metadata"] = (objectMetadata ? objectMetadata["Stat_Treatment"] : null);
        privateState.Stat_Treatment = defaultValues ? (defaultValues["Stat_Treatment"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Stat_Treatment"], context) : null) : null;
        context["field"] = "Treatment_Date";
        context["metadata"] = (objectMetadata ? objectMetadata["Treatment_Date"] : null);
        privateState.Treatment_Date = defaultValues ? (defaultValues["Treatment_Date"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Treatment_Date"], context) : null) : null;
        context["field"] = "Treatment_End_Date";
        context["metadata"] = (objectMetadata ? objectMetadata["Treatment_End_Date"] : null);
        privateState.Treatment_End_Date = defaultValues ? (defaultValues["Treatment_End_Date"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Treatment_End_Date"], context) : null) : null;
        context["field"] = "Treatment_End_Time";
        context["metadata"] = (objectMetadata ? objectMetadata["Treatment_End_Time"] : null);
        privateState.Treatment_End_Time = defaultValues ? (defaultValues["Treatment_End_Time"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Treatment_End_Time"], context) : null) : null;
        context["field"] = "Treatment_Start_Time";
        context["metadata"] = (objectMetadata ? objectMetadata["Treatment_Start_Time"] : null);
        privateState.Treatment_Start_Time = defaultValues ? (defaultValues["Treatment_Start_Time"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Treatment_Start_Time"], context) : null) : null;
        context["field"] = "TreatmentType_Results";
        context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Results"] : null);
        privateState.TreatmentType_Results = defaultValues ? (defaultValues["TreatmentType_Results"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TreatmentType_Results"], context) : null) : null;
        context["field"] = "TreatmentTypeID";
        context["metadata"] = (objectMetadata ? objectMetadata["TreatmentTypeID"] : null);
        privateState.TreatmentTypeID = defaultValues ? (defaultValues["TreatmentTypeID"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TreatmentTypeID"], context) : null) : null;
        context["field"] = "Upgraded_Dialyzer";
        context["metadata"] = (objectMetadata ? objectMetadata["Upgraded_Dialyzer"] : null);
        privateState.Upgraded_Dialyzer = defaultValues ? (defaultValues["Upgraded_Dialyzer"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Upgraded_Dialyzer"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "AccessTypeID": {
                get: function() {
                    context["field"] = "AccessTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["AccessTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.AccessTypeID, context);
                },
                set: function(val) {
                    setterFunctions['AccessTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "AddtlSvcsTypeID": {
                get: function() {
                    context["field"] = "AddtlSvcsTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["AddtlSvcsTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.AddtlSvcsTypeID, context);
                },
                set: function(val) {
                    setterFunctions['AddtlSvcsTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ApheresisTypeID": {
                get: function() {
                    context["field"] = "ApheresisTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["ApheresisTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ApheresisTypeID, context);
                },
                set: function(val) {
                    setterFunctions['ApheresisTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "App_Version_Number": {
                get: function() {
                    context["field"] = "App_Version_Number";
                    context["metadata"] = (objectMetadata ? objectMetadata["App_Version_Number"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.App_Version_Number, context);
                },
                set: function(val) {
                    setterFunctions['App_Version_Number'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Blood_Administration_Qty": {
                get: function() {
                    context["field"] = "Blood_Administration_Qty";
                    context["metadata"] = (objectMetadata ? objectMetadata["Blood_Administration_Qty"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Blood_Administration_Qty, context);
                },
                set: function(val) {
                    setterFunctions['Blood_Administration_Qty'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Comments": {
                get: function() {
                    context["field"] = "Comments";
                    context["metadata"] = (objectMetadata ? objectMetadata["Comments"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Comments, context);
                },
                set: function(val) {
                    setterFunctions['Comments'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CRRTTypeID": {
                get: function() {
                    context["field"] = "CRRTTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["CRRTTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CRRTTypeID, context);
                },
                set: function(val) {
                    setterFunctions['CRRTTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CRRTUltrafiltrationTypeID": {
                get: function() {
                    context["field"] = "CRRTUltrafiltrationTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["CRRTUltrafiltrationTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CRRTUltrafiltrationTypeID, context);
                },
                set: function(val) {
                    setterFunctions['CRRTUltrafiltrationTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CxlTypeID": {
                get: function() {
                    context["field"] = "CxlTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["CxlTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CxlTypeID, context);
                },
                set: function(val) {
                    setterFunctions['CxlTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Date_Of_Birth": {
                get: function() {
                    context["field"] = "Date_Of_Birth";
                    context["metadata"] = (objectMetadata ? objectMetadata["Date_Of_Birth"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Date_Of_Birth, context);
                },
                set: function(val) {
                    setterFunctions['Date_Of_Birth'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DaVitaClinicID": {
                get: function() {
                    context["field"] = "DaVitaClinicID";
                    context["metadata"] = (objectMetadata ? objectMetadata["DaVitaClinicID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DaVitaClinicID, context);
                },
                set: function(val) {
                    setterFunctions['DaVitaClinicID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETED": {
                get: function() {
                    context["field"] = "DELETED";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETED"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETED, context);
                },
                set: function(val) {
                    setterFunctions['DELETED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Device_PIN": {
                get: function() {
                    context["field"] = "Device_PIN";
                    context["metadata"] = (objectMetadata ? objectMetadata["Device_PIN"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Device_PIN, context);
                },
                set: function(val) {
                    setterFunctions['Device_PIN'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Dialysate": {
                get: function() {
                    context["field"] = "Dialysate";
                    context["metadata"] = (objectMetadata ? objectMetadata["Dialysate"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Dialysate, context);
                },
                set: function(val) {
                    setterFunctions['Dialysate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "First_Name": {
                get: function() {
                    context["field"] = "First_Name";
                    context["metadata"] = (objectMetadata ? objectMetadata["First_Name"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.First_Name, context);
                },
                set: function(val) {
                    setterFunctions['First_Name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HbsAbID": {
                get: function() {
                    context["field"] = "HbsAbID";
                    context["metadata"] = (objectMetadata ? objectMetadata["HbsAbID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HbsAbID, context);
                },
                set: function(val) {
                    setterFunctions['HbsAbID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HbsAgID": {
                get: function() {
                    context["field"] = "HbsAgID";
                    context["metadata"] = (objectMetadata ? objectMetadata["HbsAgID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HbsAgID, context);
                },
                set: function(val) {
                    setterFunctions['HbsAgID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HemoTypeID": {
                get: function() {
                    context["field"] = "HemoTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["HemoTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HemoTypeID, context);
                },
                set: function(val) {
                    setterFunctions['HemoTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Hospital_Delay_Time_Units": {
                get: function() {
                    context["field"] = "Hospital_Delay_Time_Units";
                    context["metadata"] = (objectMetadata ? objectMetadata["Hospital_Delay_Time_Units"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Hospital_Delay_Time_Units, context);
                },
                set: function(val) {
                    setterFunctions['Hospital_Delay_Time_Units'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HospitalID": {
                get: function() {
                    context["field"] = "HospitalID";
                    context["metadata"] = (objectMetadata ? objectMetadata["HospitalID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HospitalID, context);
                },
                set: function(val) {
                    setterFunctions['HospitalID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ID": {
                get: function() {
                    context["field"] = "ID";
                    context["metadata"] = (objectMetadata ? objectMetadata["ID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ID, context);
                },
                set: function(val) {
                    setterFunctions['ID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Is_End_Date_Modified": {
                get: function() {
                    context["field"] = "Is_End_Date_Modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["Is_End_Date_Modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Is_End_Date_Modified, context);
                },
                set: function(val) {
                    setterFunctions['Is_End_Date_Modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Is_End_Time_Modified": {
                get: function() {
                    context["field"] = "Is_End_Time_Modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["Is_End_Time_Modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Is_End_Time_Modified, context);
                },
                set: function(val) {
                    setterFunctions['Is_End_Time_Modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Is_Start_Date_Modified": {
                get: function() {
                    context["field"] = "Is_Start_Date_Modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["Is_Start_Date_Modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Is_Start_Date_Modified, context);
                },
                set: function(val) {
                    setterFunctions['Is_Start_Date_Modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Is_Start_Time_Modified": {
                get: function() {
                    context["field"] = "Is_Start_Time_Modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["Is_Start_Time_Modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Is_Start_Time_Modified, context);
                },
                set: function(val) {
                    setterFunctions['Is_Start_Time_Modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Is_Synched_With_AXDB": {
                get: function() {
                    context["field"] = "Is_Synched_With_AXDB";
                    context["metadata"] = (objectMetadata ? objectMetadata["Is_Synched_With_AXDB"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Is_Synched_With_AXDB, context);
                },
                set: function(val) {
                    setterFunctions['Is_Synched_With_AXDB'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "IV_Antibiotic": {
                get: function() {
                    context["field"] = "IV_Antibiotic";
                    context["metadata"] = (objectMetadata ? objectMetadata["IV_Antibiotic"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.IV_Antibiotic, context);
                },
                set: function(val) {
                    setterFunctions['IV_Antibiotic'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "last_modified": {
                get: function() {
                    context["field"] = "last_modified";
                    context["metadata"] = (objectMetadata ? objectMetadata["last_modified"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.last_modified, context);
                },
                set: function(val) {
                    setterFunctions['last_modified'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Last_Name": {
                get: function() {
                    context["field"] = "Last_Name";
                    context["metadata"] = (objectMetadata ? objectMetadata["Last_Name"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Last_Name, context);
                },
                set: function(val) {
                    setterFunctions['Last_Name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Medical_Record_Number": {
                get: function() {
                    context["field"] = "Medical_Record_Number";
                    context["metadata"] = (objectMetadata ? objectMetadata["Medical_Record_Number"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Medical_Record_Number, context);
                },
                set: function(val) {
                    setterFunctions['Medical_Record_Number'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Nurse_UserName": {
                get: function() {
                    context["field"] = "Nurse_UserName";
                    context["metadata"] = (objectMetadata ? objectMetadata["Nurse_UserName"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Nurse_UserName, context);
                },
                set: function(val) {
                    setterFunctions['Nurse_UserName'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Nursing_Service_Time_Units": {
                get: function() {
                    context["field"] = "Nursing_Service_Time_Units";
                    context["metadata"] = (objectMetadata ? objectMetadata["Nursing_Service_Time_Units"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Nursing_Service_Time_Units, context);
                },
                set: function(val) {
                    setterFunctions['Nursing_Service_Time_Units'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NursingServiceID": {
                get: function() {
                    context["field"] = "NursingServiceID";
                    context["metadata"] = (objectMetadata ? objectMetadata["NursingServiceID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NursingServiceID, context);
                },
                set: function(val) {
                    setterFunctions['NursingServiceID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PDTypeID": {
                get: function() {
                    context["field"] = "PDTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["PDTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PDTypeID, context);
                },
                set: function(val) {
                    setterFunctions['PDTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Pediatric": {
                get: function() {
                    context["field"] = "Pediatric";
                    context["metadata"] = (objectMetadata ? objectMetadata["Pediatric"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Pediatric, context);
                },
                set: function(val) {
                    setterFunctions['Pediatric'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Physician_First_Name": {
                get: function() {
                    context["field"] = "Physician_First_Name";
                    context["metadata"] = (objectMetadata ? objectMetadata["Physician_First_Name"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Physician_First_Name, context);
                },
                set: function(val) {
                    setterFunctions['Physician_First_Name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Physician_Last_Name": {
                get: function() {
                    context["field"] = "Physician_Last_Name";
                    context["metadata"] = (objectMetadata ? objectMetadata["Physician_Last_Name"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Physician_Last_Name, context);
                },
                set: function(val) {
                    setterFunctions['Physician_Last_Name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "posttx_hosp_id": {
                get: function() {
                    context["field"] = "posttx_hosp_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["posttx_hosp_id"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.posttx_hosp_id, context);
                },
                set: function(val) {
                    setterFunctions['posttx_hosp_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "pretx_hosp_id": {
                get: function() {
                    context["field"] = "pretx_hosp_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["pretx_hosp_id"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.pretx_hosp_id, context);
                },
                set: function(val) {
                    setterFunctions['pretx_hosp_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Removal_Of_Non_Tunneled_Catheter": {
                get: function() {
                    context["field"] = "Removal_Of_Non_Tunneled_Catheter";
                    context["metadata"] = (objectMetadata ? objectMetadata["Removal_Of_Non_Tunneled_Catheter"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Removal_Of_Non_Tunneled_Catheter, context);
                },
                set: function(val) {
                    setterFunctions['Removal_Of_Non_Tunneled_Catheter'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Room_Number": {
                get: function() {
                    context["field"] = "Room_Number";
                    context["metadata"] = (objectMetadata ? objectMetadata["Room_Number"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Room_Number, context);
                },
                set: function(val) {
                    setterFunctions['Room_Number'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "RoomTypeID": {
                get: function() {
                    context["field"] = "RoomTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["RoomTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.RoomTypeID, context);
                },
                set: function(val) {
                    setterFunctions['RoomTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Stat_Treatment": {
                get: function() {
                    context["field"] = "Stat_Treatment";
                    context["metadata"] = (objectMetadata ? objectMetadata["Stat_Treatment"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Stat_Treatment, context);
                },
                set: function(val) {
                    setterFunctions['Stat_Treatment'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Treatment_Date": {
                get: function() {
                    context["field"] = "Treatment_Date";
                    context["metadata"] = (objectMetadata ? objectMetadata["Treatment_Date"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Treatment_Date, context);
                },
                set: function(val) {
                    setterFunctions['Treatment_Date'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Treatment_End_Date": {
                get: function() {
                    context["field"] = "Treatment_End_Date";
                    context["metadata"] = (objectMetadata ? objectMetadata["Treatment_End_Date"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Treatment_End_Date, context);
                },
                set: function(val) {
                    setterFunctions['Treatment_End_Date'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Treatment_End_Time": {
                get: function() {
                    context["field"] = "Treatment_End_Time";
                    context["metadata"] = (objectMetadata ? objectMetadata["Treatment_End_Time"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Treatment_End_Time, context);
                },
                set: function(val) {
                    setterFunctions['Treatment_End_Time'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Treatment_Start_Time": {
                get: function() {
                    context["field"] = "Treatment_Start_Time";
                    context["metadata"] = (objectMetadata ? objectMetadata["Treatment_Start_Time"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Treatment_Start_Time, context);
                },
                set: function(val) {
                    setterFunctions['Treatment_Start_Time'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TreatmentType_Results": {
                get: function() {
                    context["field"] = "TreatmentType_Results";
                    context["metadata"] = (objectMetadata ? objectMetadata["TreatmentType_Results"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TreatmentType_Results, context);
                },
                set: function(val) {
                    setterFunctions['TreatmentType_Results'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TreatmentTypeID": {
                get: function() {
                    context["field"] = "TreatmentTypeID";
                    context["metadata"] = (objectMetadata ? objectMetadata["TreatmentTypeID"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TreatmentTypeID, context);
                },
                set: function(val) {
                    setterFunctions['TreatmentTypeID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Upgraded_Dialyzer": {
                get: function() {
                    context["field"] = "Upgraded_Dialyzer";
                    context["metadata"] = (objectMetadata ? objectMetadata["Upgraded_Dialyzer"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Upgraded_Dialyzer, context);
                },
                set: function(val) {
                    setterFunctions['Upgraded_Dialyzer'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.AccessTypeID = value ? (value["AccessTypeID"] ? value["AccessTypeID"] : null) : null;
            privateState.AddtlSvcsTypeID = value ? (value["AddtlSvcsTypeID"] ? value["AddtlSvcsTypeID"] : null) : null;
            privateState.ApheresisTypeID = value ? (value["ApheresisTypeID"] ? value["ApheresisTypeID"] : null) : null;
            privateState.App_Version_Number = value ? (value["App_Version_Number"] ? value["App_Version_Number"] : null) : null;
            privateState.Blood_Administration_Qty = value ? (value["Blood_Administration_Qty"] ? value["Blood_Administration_Qty"] : null) : null;
            privateState.Comments = value ? (value["Comments"] ? value["Comments"] : null) : null;
            privateState.CRRTTypeID = value ? (value["CRRTTypeID"] ? value["CRRTTypeID"] : null) : null;
            privateState.CRRTUltrafiltrationTypeID = value ? (value["CRRTUltrafiltrationTypeID"] ? value["CRRTUltrafiltrationTypeID"] : null) : null;
            privateState.CxlTypeID = value ? (value["CxlTypeID"] ? value["CxlTypeID"] : null) : null;
            privateState.Date_Of_Birth = value ? (value["Date_Of_Birth"] ? value["Date_Of_Birth"] : null) : null;
            privateState.DaVitaClinicID = value ? (value["DaVitaClinicID"] ? value["DaVitaClinicID"] : null) : null;
            privateState.DELETED = value ? (value["DELETED"] ? value["DELETED"] : null) : null;
            privateState.Device_PIN = value ? (value["Device_PIN"] ? value["Device_PIN"] : null) : null;
            privateState.Dialysate = value ? (value["Dialysate"] ? value["Dialysate"] : null) : null;
            privateState.First_Name = value ? (value["First_Name"] ? value["First_Name"] : null) : null;
            privateState.HbsAbID = value ? (value["HbsAbID"] ? value["HbsAbID"] : null) : null;
            privateState.HbsAgID = value ? (value["HbsAgID"] ? value["HbsAgID"] : null) : null;
            privateState.HemoTypeID = value ? (value["HemoTypeID"] ? value["HemoTypeID"] : null) : null;
            privateState.Hospital_Delay_Time_Units = value ? (value["Hospital_Delay_Time_Units"] ? value["Hospital_Delay_Time_Units"] : null) : null;
            privateState.HospitalID = value ? (value["HospitalID"] ? value["HospitalID"] : null) : null;
            privateState.ID = value ? (value["ID"] ? value["ID"] : null) : null;
            privateState.Is_End_Date_Modified = value ? (value["Is_End_Date_Modified"] ? value["Is_End_Date_Modified"] : null) : null;
            privateState.Is_End_Time_Modified = value ? (value["Is_End_Time_Modified"] ? value["Is_End_Time_Modified"] : null) : null;
            privateState.Is_Start_Date_Modified = value ? (value["Is_Start_Date_Modified"] ? value["Is_Start_Date_Modified"] : null) : null;
            privateState.Is_Start_Time_Modified = value ? (value["Is_Start_Time_Modified"] ? value["Is_Start_Time_Modified"] : null) : null;
            privateState.Is_Synched_With_AXDB = value ? (value["Is_Synched_With_AXDB"] ? value["Is_Synched_With_AXDB"] : null) : null;
            privateState.IV_Antibiotic = value ? (value["IV_Antibiotic"] ? value["IV_Antibiotic"] : null) : null;
            privateState.last_modified = value ? (value["last_modified"] ? value["last_modified"] : null) : null;
            privateState.Last_Name = value ? (value["Last_Name"] ? value["Last_Name"] : null) : null;
            privateState.Medical_Record_Number = value ? (value["Medical_Record_Number"] ? value["Medical_Record_Number"] : null) : null;
            privateState.Nurse_UserName = value ? (value["Nurse_UserName"] ? value["Nurse_UserName"] : null) : null;
            privateState.Nursing_Service_Time_Units = value ? (value["Nursing_Service_Time_Units"] ? value["Nursing_Service_Time_Units"] : null) : null;
            privateState.NursingServiceID = value ? (value["NursingServiceID"] ? value["NursingServiceID"] : null) : null;
            privateState.PDTypeID = value ? (value["PDTypeID"] ? value["PDTypeID"] : null) : null;
            privateState.Pediatric = value ? (value["Pediatric"] ? value["Pediatric"] : null) : null;
            privateState.Physician_First_Name = value ? (value["Physician_First_Name"] ? value["Physician_First_Name"] : null) : null;
            privateState.Physician_Last_Name = value ? (value["Physician_Last_Name"] ? value["Physician_Last_Name"] : null) : null;
            privateState.posttx_hosp_id = value ? (value["posttx_hosp_id"] ? value["posttx_hosp_id"] : null) : null;
            privateState.pretx_hosp_id = value ? (value["pretx_hosp_id"] ? value["pretx_hosp_id"] : null) : null;
            privateState.Removal_Of_Non_Tunneled_Catheter = value ? (value["Removal_Of_Non_Tunneled_Catheter"] ? value["Removal_Of_Non_Tunneled_Catheter"] : null) : null;
            privateState.Room_Number = value ? (value["Room_Number"] ? value["Room_Number"] : null) : null;
            privateState.RoomTypeID = value ? (value["RoomTypeID"] ? value["RoomTypeID"] : null) : null;
            privateState.Stat_Treatment = value ? (value["Stat_Treatment"] ? value["Stat_Treatment"] : null) : null;
            privateState.Treatment_Date = value ? (value["Treatment_Date"] ? value["Treatment_Date"] : null) : null;
            privateState.Treatment_End_Date = value ? (value["Treatment_End_Date"] ? value["Treatment_End_Date"] : null) : null;
            privateState.Treatment_End_Time = value ? (value["Treatment_End_Time"] ? value["Treatment_End_Time"] : null) : null;
            privateState.Treatment_Start_Time = value ? (value["Treatment_Start_Time"] ? value["Treatment_Start_Time"] : null) : null;
            privateState.TreatmentType_Results = value ? (value["TreatmentType_Results"] ? value["TreatmentType_Results"] : null) : null;
            privateState.TreatmentTypeID = value ? (value["TreatmentTypeID"] ? value["TreatmentTypeID"] : null) : null;
            privateState.Upgraded_Dialyzer = value ? (value["Upgraded_Dialyzer"] ? value["Upgraded_Dialyzer"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(PatientTreatmentInfo);
    //Create new class level validator object
    BaseModel.Validator.call(PatientTreatmentInfo);
    var registerValidatorBackup = PatientTreatmentInfo.registerValidator;
    PatientTreatmentInfo.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (PatientTreatmentInfo.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    PatientTreatmentInfo.relations = relations;
    PatientTreatmentInfo.prototype.isValid = function() {
        return PatientTreatmentInfo.isValid(this);
    };
    PatientTreatmentInfo.prototype.objModelName = "PatientTreatmentInfo";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    PatientTreatmentInfo.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("OutBound", "PatientTreatmentInfo", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    PatientTreatmentInfo.clone = function(objectToClone) {
        var clonedObj = new PatientTreatmentInfo();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return PatientTreatmentInfo;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RepoManagerConfig',[], function() {
    var repoMapping = {
        Ref_Hospital: {
            model: "NurseHospital/Ref_Hospital/Model",
            config: "NurseHospital/Ref_Hospital/MF_Config",
            repository: "",
        },
        Ref_Hospital_Desc: {
            model: "InBound/Ref_Hospital_Desc/Model",
            config: "InBound/Ref_Hospital_Desc/MF_Config",
            repository: "",
        },
        Ref_PDType_Desc: {
            model: "InBound/Ref_PDType_Desc/Model",
            config: "InBound/Ref_PDType_Desc/MF_Config",
            repository: "",
        },
        Ref_CancellationType_Desc: {
            model: "InBound/Ref_CancellationType_Desc/Model",
            config: "InBound/Ref_CancellationType_Desc/MF_Config",
            repository: "",
        },
        Ref_DialysateType_Desc: {
            model: "InBound/Ref_DialysateType_Desc/Model",
            config: "InBound/Ref_DialysateType_Desc/MF_Config",
            repository: "",
        },
        Ref_DivisonRegionMappingInfo: {
            model: "InBound/Ref_DivisonRegionMappingInfo/Model",
            config: "InBound/Ref_DivisonRegionMappingInfo/MF_Config",
            repository: "",
        },
        Ref_CRRTUltrafiltrationType_Desc: {
            model: "InBound/Ref_CRRTUltrafiltrationType_Desc/Model",
            config: "InBound/Ref_CRRTUltrafiltrationType_Desc/MF_Config",
            repository: "",
        },
        Ref_GroupDivisionMappingInfo: {
            model: "InBound/Ref_GroupDivisionMappingInfo/Model",
            config: "InBound/Ref_GroupDivisionMappingInfo/MF_Config",
            repository: "",
        },
        Ref_Nurse_Desc: {
            model: "InBound/Ref_Nurse_Desc/Model",
            config: "InBound/Ref_Nurse_Desc/MF_Config",
            repository: "",
        },
        Ref_Group_Desc: {
            model: "InBound/Ref_Group_Desc/Model",
            config: "InBound/Ref_Group_Desc/MF_Config",
            repository: "",
        },
        Ref_CRRTType_Desc: {
            model: "InBound/Ref_CRRTType_Desc/Model",
            config: "InBound/Ref_CRRTType_Desc/MF_Config",
            repository: "",
        },
        Ref_TreatmentQuestions_Desc: {
            model: "InBound/Ref_TreatmentQuestions_Desc/Model",
            config: "InBound/Ref_TreatmentQuestions_Desc/MF_Config",
            repository: "",
        },
        Ref_Region_Desc: {
            model: "InBound/Ref_Region_Desc/Model",
            config: "InBound/Ref_Region_Desc/MF_Config",
            repository: "",
        },
        Ref_AccessType_Desc: {
            model: "InBound/Ref_AccessType_Desc/Model",
            config: "InBound/Ref_AccessType_Desc/MF_Config",
            repository: "",
        },
        Ref_NursingService_Desc: {
            model: "InBound/Ref_NursingService_Desc/Model",
            config: "InBound/Ref_NursingService_Desc/MF_Config",
            repository: "",
        },
        Ref_AdditionalServicesType_Desc: {
            model: "InBound/Ref_AdditionalServicesType_Desc/Model",
            config: "InBound/Ref_AdditionalServicesType_Desc/MF_Config",
            repository: "",
        },
        Ref_HemoType_Desc: {
            model: "InBound/Ref_HemoType_Desc/Model",
            config: "InBound/Ref_HemoType_Desc/MF_Config",
            repository: "",
        },
        Ref_Room_Type_Desc: {
            model: "InBound/Ref_Room_Type_Desc/Model",
            config: "InBound/Ref_Room_Type_Desc/MF_Config",
            repository: "",
        },
        Ref_PreTxhosp_Desc: {
            model: "InBound/Ref_PreTxhosp_Desc/Model",
            config: "InBound/Ref_PreTxhosp_Desc/MF_Config",
            repository: "",
        },
        Ref_RegionHospitalMappingInfo: {
            model: "InBound/Ref_RegionHospitalMappingInfo/Model",
            config: "InBound/Ref_RegionHospitalMappingInfo/MF_Config",
            repository: "",
        },
        Ref_PostTxhosp_Desc: {
            model: "InBound/Ref_PostTxhosp_Desc/Model",
            config: "InBound/Ref_PostTxhosp_Desc/MF_Config",
            repository: "",
        },
        Ref_HbsAg_Desc: {
            model: "InBound/Ref_HbsAg_Desc/Model",
            config: "InBound/Ref_HbsAg_Desc/MF_Config",
            repository: "",
        },
        Ref_HbsAb_Desc: {
            model: "InBound/Ref_HbsAb_Desc/Model",
            config: "InBound/Ref_HbsAb_Desc/MF_Config",
            repository: "",
        },
        Ref_RegionDaVitaClinicMappingInfo: {
            model: "InBound/Ref_RegionDaVitaClinicMappingInfo/Model",
            config: "InBound/Ref_RegionDaVitaClinicMappingInfo/MF_Config",
            repository: "",
        },
        Ref_RegionNurseMappingInfo: {
            model: "InBound/Ref_RegionNurseMappingInfo/Model",
            config: "InBound/Ref_RegionNurseMappingInfo/MF_Config",
            repository: "",
        },
        Ref_ApheresisType_Desc: {
            model: "InBound/Ref_ApheresisType_Desc/Model",
            config: "InBound/Ref_ApheresisType_Desc/MF_Config",
            repository: "",
        },
        Ref_Division_Desc: {
            model: "InBound/Ref_Division_Desc/Model",
            config: "InBound/Ref_Division_Desc/MF_Config",
            repository: "",
        },
        Ref_DaVitaClinic_Desc: {
            model: "InBound/Ref_DaVitaClinic_Desc/Model",
            config: "InBound/Ref_DaVitaClinic_Desc/MF_Config",
            repository: "",
        },
        PatientTreatmentInfo: {
            model: "OutBound/PatientTreatmentInfo/Model",
            config: "OutBound/PatientTreatmentInfo/MF_Config",
            repository: "",
        },
    };
    return repoMapping;
})
;
require(['applicationController','CopyFBox0e0feafe301d842','FBox0d3323315729948','FBox0jce3a5b497b34e','flxSampleRowTemplate','Flex0d798b50aa6d145','fcappFooter','fcMainheader','CopyFBox0e0feafe301d842Controller','FBox0d3323315729948Controller','FBox0jce3a5b497b34eController','flxSampleRowTemplateController','Flex0d798b50aa6d145Controller','fcappFooterController','fcMainheaderController','navigation/NavigationModel','navigation/NavigationController','InBound/Ref_AccessType_Desc/MF_Config','InBound/Ref_AccessType_Desc/Model','InBound/Ref_AdditionalServicesType_Desc/MF_Config','InBound/Ref_AdditionalServicesType_Desc/Model','InBound/Ref_ApheresisType_Desc/MF_Config','InBound/Ref_ApheresisType_Desc/Model','InBound/Ref_CRRTType_Desc/MF_Config','InBound/Ref_CRRTType_Desc/Model','InBound/Ref_CRRTUltrafiltrationType_Desc/MF_Config','InBound/Ref_CRRTUltrafiltrationType_Desc/Model','InBound/Ref_CancellationType_Desc/MF_Config','InBound/Ref_CancellationType_Desc/Model','InBound/Ref_DaVitaClinic_Desc/MF_Config','InBound/Ref_DaVitaClinic_Desc/Model','InBound/Ref_DialysateType_Desc/MF_Config','InBound/Ref_DialysateType_Desc/Model','InBound/Ref_Division_Desc/MF_Config','InBound/Ref_Division_Desc/Model','InBound/Ref_DivisonRegionMappingInfo/MF_Config','InBound/Ref_DivisonRegionMappingInfo/Model','InBound/Ref_GroupDivisionMappingInfo/MF_Config','InBound/Ref_GroupDivisionMappingInfo/Model','InBound/Ref_Group_Desc/MF_Config','InBound/Ref_Group_Desc/Model','InBound/Ref_HbsAb_Desc/MF_Config','InBound/Ref_HbsAb_Desc/Model','InBound/Ref_HbsAg_Desc/MF_Config','InBound/Ref_HbsAg_Desc/Model','InBound/Ref_HemoType_Desc/MF_Config','InBound/Ref_HemoType_Desc/Model','InBound/Ref_Hospital_Desc/MF_Config','InBound/Ref_Hospital_Desc/Model','InBound/Ref_Nurse_Desc/MF_Config','InBound/Ref_Nurse_Desc/Model','InBound/Ref_NursingService_Desc/MF_Config','InBound/Ref_NursingService_Desc/Model','InBound/Ref_PDType_Desc/MF_Config','InBound/Ref_PDType_Desc/Model','InBound/Ref_PostTxhosp_Desc/MF_Config','InBound/Ref_PostTxhosp_Desc/Model','InBound/Ref_PreTxhosp_Desc/MF_Config','InBound/Ref_PreTxhosp_Desc/Model','InBound/Ref_RegionDaVitaClinicMappingInfo/MF_Config','InBound/Ref_RegionDaVitaClinicMappingInfo/Model','InBound/Ref_RegionHospitalMappingInfo/MF_Config','InBound/Ref_RegionHospitalMappingInfo/Model','InBound/Ref_RegionNurseMappingInfo/MF_Config','InBound/Ref_RegionNurseMappingInfo/Model','InBound/Ref_Region_Desc/MF_Config','InBound/Ref_Region_Desc/Model','InBound/Ref_Room_Type_Desc/MF_Config','InBound/Ref_Room_Type_Desc/Model','InBound/Ref_TreatmentQuestions_Desc/MF_Config','InBound/Ref_TreatmentQuestions_Desc/Model','NurseHospital/Ref_Hospital/MF_Config','NurseHospital/Ref_Hospital/Model','OutBound/PatientTreatmentInfo/MF_Config','OutBound/PatientTreatmentInfo/Model','RepoManagerConfig'], function(){});

define("sparequirefileslist", function(){});

