define("userfrnOtherDetailsController", {
    populateListBoxFromObject: function(objectName, listBoxName, keyField, valueField, serviceId, operationId, targetForm) {
        if (!targetForm) {
            voltmx.print("Target Form is not defined");
            return;
        }
        var inputparam = {};
        inputparam["serviceID"] = serviceId;
        inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var httpheaders = {};
        inputparam["httpheaders"] = httpheaders;
        var httpconfigs = {};
        inputparam["httpconfig"] = httpconfigs;
        var callback = function(response) {
            voltmx.application.dismissLoadingScreen();
            voltmx.print("******In " + objectName + " Callback********");
            if (response && response.opstatus === 0) { // Added response check
                var listData = [];
                var data = response.records; // Access data using response.records
                if (data && data.length > 0) { // Check if data exists AND is not empty
                    listData.push(["null", "Please Select..."]);
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        var key = item[keyField];
                        var value = item[valueField];
                        listData.push([key, value]);
                        voltmx.print(key + " - " + value);
                    }
                    targetForm[listBoxName].masterData = listData;
                } else {
                    voltmx.print("No data received from service for " + objectName);
                }
            } else {
                voltmx.ui.Alert({
                    message: objectName + " Callback - Error: " + JSON.stringify(response)
                }, {});
            }
        }.bind(this); // Very important: bind 'this'
        mfobjectsecureinvokerasync(inputparam, "InBound", objectName, callback);
    },
    onFormOtherDetailsPreShow: function(context) {
        voltmx.print("In frmTreatmentDetails preShow");
        voltmx.print("this in preShow:", this); // VERY IMPORTANT: Check 'this' here
        if (context && context !== null) {
            voltmx.print("Context Data: " + JSON.stringify(context));
        } else {
            voltmx.print("No context data was passed to frmTreatmentDetails");
        }
        //Call populateListBoxFromObject only if this.view is defined
        if (this.view) {
            this.populateListBoxFromObject("Ref_NursingService_Desc", "cmbNursingSvc", "NursingServiceID", "NursingService_Desc", "InBound$Ref_NursingService_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_AdditionalServicesType_Desc", "cmbAdditionalSvc", "AdditionalServicesTypeID", "AdditionalServicesType_Desc", "InBound$Ref_AdditionalServicesType_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_DialysateType_Desc", "cmbDialysate", "DialysateTypeID", "DialysateType_Desc", "InBound$Ref_DialysateType_Desc$get", "get", this.view);
        } else {
            voltmx.print("this.view is undefined. Cannot populate listboxes.");
        }
    }
});
define("frnOtherDetailsControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_g526b15a94a44d3c87a2f5a9497ee978: function AS_FlexContainer_g526b15a94a44d3c87a2f5a9497ee978(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frnACOI"
        });
        ntf.navigate();
    },
    AS_FlexContainer_f464e035505d489389d47c4d464b592a: function AS_FlexContainer_f464e035505d489389d47c4d464b592a(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPatientDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_c346d538a39e4962b24828ce1245b1c3: function AS_FlexContainer_c346d538a39e4962b24828ce1245b1c3(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPostTX"
        });
        ntf.navigate();
    },
    AS_FlexContainer_i70875f94cb74a4b8b0580756f29d81c: function AS_FlexContainer_i70875f94cb74a4b8b0580756f29d81c(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    },
    AS_Form_j3415f20696a4aa8b9e951ab1d169356: function AS_Form_j3415f20696a4aa8b9e951ab1d169356(eventobject) {
        var self = this;
        return self.onFormOtherDetailsPreShow.call(this, null);
    }
});
define("frnOtherDetailsController", ["userfrnOtherDetailsController", "frnOtherDetailsControllerActions"], function() {
    var controller = require("userfrnOtherDetailsController");
    var controllerActions = ["frnOtherDetailsControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
