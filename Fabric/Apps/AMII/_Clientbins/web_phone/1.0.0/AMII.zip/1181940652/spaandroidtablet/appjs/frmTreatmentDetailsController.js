define("userfrmTreatmentDetailsController", {
    //   saveButtonReference: null, // Store a reference to the button
    //   onFormInit: function() {
    //     voltmx.print("frmTreatmentDetails onInit triggered.");
    //   },
    // //   onFormPreShow: function() {
    // //     voltmx.print("frmTreatmentDetails onPreShow triggered.");
    // //     require(["SaveModule"], function(SaveModule) {
    // //       this.setupSaveButton(SaveModule);
    // //     }.bind(this));
    // //   },
    //   onFormTreatmentDetailsPostShow: function(){
    //     voltmx.print("frmTreatmentDetails onPostShow triggered.");
    //     this.setupSaveButton(); // Call setupSaveButton directly
    //   },
    //   onFormDestroy: function() {
    //     voltmx.print("frmTreatmentDetails onDestroy triggered.");
    //     require(["SaveModule"], function(SaveModule) {
    //       this.removeSaveButton(SaveModule);
    //     }.bind(this));
    //   },
    //   setupSaveButton: function() {
    //     if (this.view && this.view.btnSave) { // Directly access the button
    //       var btnSaveWidget = this.view.btnSave;
    //       var self = this; // Store the controller's 'this' context
    //       btnSaveWidget.onClick = function() {
    //         try {
    //           if (typeof voltmx !== "undefined" && typeof voltmx.application !== "undefined" && typeof voltmx.application.publish === "function") {
    //             voltmx.application.publish("saveRequested", {
    //               form: self,
    //               callback: self.saveCallback.bind(self)
    //             });
    //           } else {
    //             voltmx.print("voltmx.application.publish is not available.");
    //             if(typeof voltmx === "undefined"){
    //               voltmx.print("voltmx is undefined");
    //             } else if(typeof voltmx.application === "undefined"){
    //               voltmx.print("voltmx.application is undefined");
    //             } else if(typeof voltmx.application.publish !== "function"){
    //               voltmx.print("typeof voltmx.application.publish is " + typeof voltmx.application.publish);
    //             }
    //           }
    //         } catch (err) {
    //           voltmx.print("Error publishing event: " + err);
    //         }
    //       };
    //       this.saveButtonReference = btnSaveWidget;
    //       voltmx.print("btnSaveWidget set successfully");
    //     } else {
    //       if (!this.view) {
    //         voltmx.print("this.view is undefined");
    //       } else if (!this.view.btnSave) {
    //         voltmx.print("this.view.btnSave is undefined");
    //       }
    //       voltmx.print("btnSave not found on the form.");
    //     }
    //   },
    //   removeSaveButton: function(SaveModule) {
    //     if (this.saveButtonReference) {
    //       this.saveButtonReference.onClick = null;
    //       this.saveButtonReference = null;
    //     }
    //   },
    collectFormData: function() {
        var self = this; // Important: Keep this for context
        var patient = {};
        // Correct way to access widgets: use self.view.widgetName
        patient.TreatmentTypeID = self.view.cmbTreatType.selectedKey;
        patient.CxlTypeID = self.view.cmbCancelType.selectedKey;
        patient.HemoTypeID = self.view.cmbHDType.selectedKey;
        patient.PDTypeID = self.view.cmbPDType.selectedKey;
        patient.CRRTTypeID = self.view.cmbCRTTtype.selectedKey;
        patient.ApheresisTypeID = self.view.cmbAphtype.selectedKey;
        patient.AccessTypeID = self.view.cmbAccessType.selectedKey;
        patient.HbsAgID = self.view.cmbHbsag.selectedKey;
        patient.HbsAbID = self.view.cmbHbsab.selectedKey;
        //Example of collecting data from widgets. Adapt to your form's widgets.
        //     patient.TreatmentTypeID = self.view[cmbTreatType].selectedKey;
        //     patient.CxlTypeID = self.view[cmbCancelType].selectedKey;
        // 	patient.TreatmentTypeID = frmTreatmentDetails.cmbTreatType.selectedKey;
        // 	patient.CxlTypeID = frmTreatmentDetails.cmbCancelType.selectedKey;
        // 	patient.HemoTypeID = self.view[cmbHDType].selectedKey;
        // 	patient.PDTypeID = self.view.cmbPDType.selectedKey;
        // 	patient.CRRTTypeID = self.view.cmbCRTTtype.selectedKey;
        // 	patient.ApheresisTypeID = self.view.cmbAphtype.selectedKey;
        // 	patient.AccessTypeID = self.view.cmbAccessType.selectedKey;
        // 	patient.HbsAgID =self.view.cmbHbsag.selectedKey;
        // 	patient.HbsAbID =self.view.cmbHbsab.selectedKey;	
        // ... collect other data from your form's widgets ...	
        return patient;
    },
    populateListBoxFromObject: function(objectName, listBoxName, keyField, valueField, serviceId, operationId, targetForm) {
        if (!targetForm) {
            voltmx.print("Target Form is not defined");
            return;
        }
        var callback = function(response) {
            voltmx.application.dismissLoadingScreen();
            voltmx.print("******In " + objectName + " Callback********");
            if (response && response.opstatus === 0) { // Added response check
                var listData = [];
                var data = response.records; // Access data using response.records
                if (data && data.length > 0) { // Check if data exists AND is not empty
                    listData.push(["null", "Please Select..."]);
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        var key = item[keyField];
                        var value = item[valueField];
                        listData.push([key, value]);
                        voltmx.print(key + " - " + value);
                    }
                    targetForm[listBoxName].masterData = listData;
                } else {
                    voltmx.print("No data received from service for " + objectName);
                }
            } else {
                voltmx.ui.Alert({
                    message: objectName + " Callback - Error: " + JSON.stringify(response)
                }, {});
            }
        }.bind(this); // Very important: bind 'this'
        var callbackFail = function(error) {
            voltmx.print("unable to retrieve records from db" + error.code);
            console.log(error);
        }
        var ofl_objectName = new voltmx.sdk.VMXObj(objectName);
        // all records of object are returned as an argument to success callback.
        ofl_objectName.get(null, callbackSuccess, callbackFail);
    },
    onFormTreatmentDetailsPreShow: function(context) {
        if (context && context !== null) {
            voltmx.print("Context Data: " + JSON.stringify(context));
        } else {
            voltmx.print("No context data was passed to frmTreatmentDetails");
        }
        //       voltmx.print("frmTreatmentDetails onPreShow triggered.");
        //       require(["SaveModule"], function(SaveModule) {
        //         this.setupSaveButton(SaveModule);
        //       }.bind(this));
        //Call populateListBoxFromObject only if this.view is defined
        if (this.view) {
            this.populateListBoxFromObject("Ref_CancellationType_Desc", "cmbCancelType", "CancellationTypeID", "CancellationType_Desc", "InBound$Ref_CancellationType_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_HemoType_Desc", "cmbHDType", "HemotypeID", "HemoType_Desc", "InBound$Ref_HemoType_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_PDType_Desc", "cmbPDType", "PDTypeID", "PDType_Desc", "InBound$Ref_PDType_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_CRRTType_Desc", "cmbCRTTtype", "CRRTTypeID", "CRRTType_Desc", "InBound$Ref_CRRTType_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_ApheresisType_Desc", "cmbAphtype", "ApheresisTypeID", "ApheresisType_Desc", "InBound$Ref_ApheresisType_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_ApheresisType_Desc", "cmbAphtype", "ApheresisTypeID", "ApheresisType_Desc", "InBound$Ref_ApheresisType_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_AccessType_Desc", "cmbAccessType", "AccessTypeID", "AccessType_Desc", "InBound$Ref_AccessType_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_HbsAg_Desc", "cmbHbsag", "HbsAgId", "HbsAg_Desc", "InBound$Ref_HbsAg_Desc$get", "get", this.view);
            this.populateListBoxFromObject("Ref_HbsAb_Desc", "cmbHbsab", "HbsAbId", "HbsAb_Desc", "InBound$Ref_HbsAb_Desc$get", "get", this.view);
        } else {
            voltmx.print("this.view is undefined. Cannot populate listboxes.");
        }
    }
});
define("frmTreatmentDetailsControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_c1ef1a9c7cdb4c78ac6e4abd663abf3a: function AS_Button_c1ef1a9c7cdb4c78ac6e4abd663abf3a(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    },
    AS_Button_f2be68c4ffea4d248b2d224121347e41: function AS_Button_f2be68c4ffea4d248b2d224121347e41(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    },
    AS_Button_d364b817e58344eab6fca7c420717199: function AS_Button_d364b817e58344eab6fca7c420717199(eventobject) {
        var self = this;
        return onClickbtnSave.call(this);
    },
    AS_FlexContainer_h0ba2bb3b5404c44aa75f60de936ab5d: function AS_FlexContainer_h0ba2bb3b5404c44aa75f60de936ab5d(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frnACOI"
        });
        ntf.navigate();
    },
    AS_FlexContainer_e2370251344341fb83d5abde982be3e7: function AS_FlexContainer_e2370251344341fb83d5abde982be3e7(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frnOtherDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_fc9106fa175b441782f4ce5d85b51bfc: function AS_FlexContainer_fc9106fa175b441782f4ce5d85b51bfc(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPatientDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_f006e3a4a21641f19c09c47406d66a88: function AS_FlexContainer_f006e3a4a21641f19c09c47406d66a88(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPostTX"
        });
        ntf.navigate();
    },
    AS_Form_bd6ea424817741fba65e9d89a5044ac3: function AS_Form_bd6ea424817741fba65e9d89a5044ac3(eventobject) {
        var self = this;
    },
    AS_Form_af1edc76653848f8b0591f958548c5fa: function AS_Form_af1edc76653848f8b0591f958548c5fa(eventobject) {
        var self = this;
        return self.onFormTreatmentDetailsPreShow.call(this, null);
    }
});
define("frmTreatmentDetailsController", ["userfrmTreatmentDetailsController", "frmTreatmentDetailsControllerActions"], function() {
    var controller = require("userfrmTreatmentDetailsController");
    var controllerActions = ["frmTreatmentDetailsControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
