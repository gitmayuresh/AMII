define("frmPatientDetails", function() {
    return function(controller) {
        function addWidgetsfrmPatientDetails() {
            this.setDefaultUnit(voltmx.flex.DP);
            var fcMainheader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "5%",
                "id": "fcMainheader",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcHeader",
                "top": "0",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMainheader.setDefaultUnit(voltmx.flex.DP);
            var Label0gf45b249bf6445 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "Label0gf45b249bf6445",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblWhiteLogin",
                "text": "Acutes Charge Capture",
                "textStyle": {},
                "width": "33%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var FlexContainer0f9a5d5a46d0045 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "FlexContainer0f9a5d5a46d0045",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcbluebgwithblackborder12",
                "top": "0",
                "width": "67%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0f9a5d5a46d0045.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0i002cdfd3b8f4c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "FlexContainer0i002cdfd3b8f4c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "90%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0i002cdfd3b8f4c.setDefaultUnit(voltmx.flex.DP);
            var lblHeader = new voltmx.ui.Label({
                "id": "lblHeader",
                "isVisible": true,
                "skin": "sknlblWhiteLogin",
                "text": "Patient Data",
                "textStyle": {},
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [23, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var btnHeaderNext = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "80%",
                "id": "btnHeaderNext",
                "isVisible": true,
                "onClick": controller.AS_Button_a28d2fa27f464f3cbad7591d1bfe22d5,
                "skin": "sknbtnnext",
                "text": "Next",
                "width": "24%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [3, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0i002cdfd3b8f4c.add(lblHeader, btnHeaderNext);
            FlexContainer0f9a5d5a46d0045.add(FlexContainer0i002cdfd3b8f4c);
            fcMainheader.add(Label0gf45b249bf6445, FlexContainer0f9a5d5a46d0045);
            var fcMain = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80%",
                "id": "fcMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "5%",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMain.setDefaultUnit(voltmx.flex.DP);
            var fcLeftPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcLeftPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknfclightGreyborder",
                "top": 0,
                "width": "33%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcLeftPane.setDefaultUnit(voltmx.flex.DP);
            var fcPatient = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPatient",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_h2ae983dff6d4f019e24c742d7419e14,
                "skin": "sknfcselectedButton",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPatient.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0a1c2bf81506348 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0a1c2bf81506348",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0a1c2bf81506348.setDefaultUnit(voltmx.flex.DP);
            var CopylblPatientNav0f62a966982744b = new voltmx.ui.Label({
                "id": "CopylblPatientNav0f62a966982744b",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Patient Data",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopylblErrorMsg0a061f1eaf9134c = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "CopylblErrorMsg0a061f1eaf9134c",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0a1c2bf81506348.add(CopylblPatientNav0f62a966982744b, CopylblErrorMsg0a061f1eaf9134c);
            var CopyFlexContainer0d8ff321bb4d147 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0",
                "centerY": "50%",
                "clipBounds": false,
                "id": "CopyFlexContainer0d8ff321bb4d147",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "width": "11%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0d8ff321bb4d147.setDefaultUnit(voltmx.flex.DP);
            var CopyimgArrow0i6fb811fe32848 = new voltmx.ui.Image2({
                "height": "100%",
                "id": "CopyimgArrow0i6fb811fe32848",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "arrow_blue.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0d8ff321bb4d147.add(CopyimgArrow0i6fb811fe32848);
            fcPatient.add(CopyFlexContainer0a1c2bf81506348, CopyFlexContainer0d8ff321bb4d147);
            var fcTreatment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcTreatment",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_adf3c6e6080d4de591053967485c170c,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTreatment.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0g3d6060756cf41 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0g3d6060756cf41",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0g3d6060756cf41.setDefaultUnit(voltmx.flex.DP);
            var CopylblTreatmentScreen0d8561826ac4046 = new voltmx.ui.Label({
                "id": "CopylblTreatmentScreen0d8561826ac4046",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Treatment Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopylblTreatmentErrorMsg0bf0c5153a71340 = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "CopylblTreatmentErrorMsg0bf0c5153a71340",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0g3d6060756cf41.add(CopylblTreatmentScreen0d8561826ac4046, CopylblTreatmentErrorMsg0bf0c5153a71340);
            fcTreatment.add(CopyFlexContainer0g3d6060756cf41);
            var fcOther = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcOther",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f19beae0f091477aad9acdafb2ee3a25,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOther.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0cf9420e0b25f4d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0cf9420e0b25f4d",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0cf9420e0b25f4d.setDefaultUnit(voltmx.flex.DP);
            var CopylblOtherScreen0cded0d93bb3f40 = new voltmx.ui.Label({
                "id": "CopylblOtherScreen0cded0d93bb3f40",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Other Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopylblOtherErrorMsg0h69497c6e9e642 = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "CopylblOtherErrorMsg0h69497c6e9e642",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0cf9420e0b25f4d.add(CopylblOtherScreen0cded0d93bb3f40, CopylblOtherErrorMsg0h69497c6e9e642);
            fcOther.add(CopyFlexContainer0cf9420e0b25f4d);
            var fcPostTX = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPostTX",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_a296ac9a63c1428190a8049b93d7c15f,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPostTX.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0f6b7a0518ac744 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0f6b7a0518ac744",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0f6b7a0518ac744.setDefaultUnit(voltmx.flex.DP);
            var lblPostTxScreen = new voltmx.ui.Label({
                "id": "lblPostTxScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Post Treatment",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblPostTxErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblPostTxErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0f6b7a0518ac744.add(lblPostTxScreen, lblPostTxErrormsg);
            fcPostTX.add(CopyFlexContainer0f6b7a0518ac744);
            var fcACOI = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcACOI",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_e1e98b4ed818484d807c907627358124,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcACOI.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0h4898d3efae542 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0h4898d3efae542",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0h4898d3efae542.setDefaultUnit(voltmx.flex.DP);
            var CopylblACOIDetails0feb5d7bc976947 = new voltmx.ui.Label({
                "id": "CopylblACOIDetails0feb5d7bc976947",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "ACOI Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopylblAcoiErrormsg0d27c2a56cf324a = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "CopylblAcoiErrormsg0d27c2a56cf324a",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0h4898d3efae542.add(CopylblACOIDetails0feb5d7bc976947, CopylblAcoiErrormsg0d27c2a56cf324a);
            fcACOI.add(CopyFlexContainer0h4898d3efae542);
            fcLeftPane.add(fcPatient, fcTreatment, fcOther, fcPostTX, fcACOI);
            var fcRightPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcRightPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": 0,
                "skin": "sknfcrightPane",
                "top": "0",
                "width": "66%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRightPane.setDefaultUnit(voltmx.flex.DP);
            var fcFour = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": false,
                "height": "100px",
                "id": "fcFour",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "top": "20px",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcFour.setDefaultUnit(voltmx.flex.DP);
            var lblmandatfields = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblmandatfields",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "* Represents required fields to save treatment.",
                "textStyle": {},
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            fcFour.add(lblmandatfields);
            var fcOne = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcOne",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOne.setDefaultUnit(voltmx.flex.DP);
            var fscPatientDetails = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "fscPatientDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0%",
                "minHeight": "1200px",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "noSkinFcScrollbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "96%"
            }, {
                "paddingInPixel": false
            }, {});
            fscPatientDetails.setDefaultUnit(voltmx.flex.DP);
            var fcPLName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPLName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPLName.setDefaultUnit(voltmx.flex.DP);
            var lblLName = new voltmx.ui.Label({
                "id": "lblLName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Patient Last Name*",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtLastName = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtLastName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "maxTextLength": 25,
                "right": "0%",
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": 0,
                "width": "64%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            fcPLName.add(lblLName, txtLastName);
            var fcPFName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPFName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPFName.setDefaultUnit(voltmx.flex.DP);
            var lblFName = new voltmx.ui.Label({
                "id": "lblFName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Patient First Name*",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtFirstName = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtFirstName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 25,
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "64%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            fcPFName.add(lblFName, txtFirstName);
            var fcDOB = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcDOB",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcDOB.setDefaultUnit(voltmx.flex.DP);
            var lblDOB = new voltmx.ui.Label({
                "id": "lblDOB",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Date of Birth",
                "textStyle": {},
                "top": "0",
                "width": "33%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtDOB = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_WORDS,
                "focusSkin": "defTextBoxFocus",
                "id": "txtDOB",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 10,
                "placeholder": "MM/DD/YYYY",
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "top": "0",
                "width": "60%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var calDOB = new voltmx.ui.Calendar({
                "calendarIcon": "calbtn.png",
                "dateComponents": [3, 12, 2024, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "day": 3,
                "formattedDate": "03/12/2024",
                "height": "40dp",
                "hour": 0,
                "id": "calDOB",
                "isVisible": true,
                "left": "0",
                "minutes": 0,
                "month": 12,
                "seconds": 0,
                "skin": "slCalendar",
                "top": "0",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "5%",
                "year": 2024
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcDOB.add(lblDOB, txtDOB, calDOB);
            var fcPreTreatment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPreTreatment",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPreTreatment.setDefaultUnit(voltmx.flex.DP);
            var lblPreTreatment = new voltmx.ui.Label({
                "id": "lblPreTreatment",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Pre-Treatment Report from Hospital RN  ",
                "textStyle": {},
                "top": "0",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var rbtPreTreatmentRN = new voltmx.ui.RadioButtonGroup({
                "bottom": 1,
                "id": "rbtPreTreatmentRN",
                "isVisible": true,
                "left": 2,
                "masterData": [
                    ["1", "Yes"],
                    ["2", "No"]
                ],
                "right": 2,
                "skin": "sknradioblueborder",
                "top": 1,
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcPreTreatment.add(lblPreTreatment, rbtPreTreatmentRN);
            var fcPediatric = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPediatric",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPediatric.setDefaultUnit(voltmx.flex.DP);
            var lblPediatricPatient = new voltmx.ui.Label({
                "id": "lblPediatricPatient",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Pediatric",
                "textStyle": {},
                "top": "0",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var rbtPediatric = new voltmx.ui.RadioButtonGroup({
                "bottom": 1,
                "id": "rbtPediatric",
                "isVisible": true,
                "left": 2,
                "masterData": [
                    ["1", "Yes"],
                    ["2", "No"]
                ],
                "right": 2,
                "skin": "sknradioblueborder",
                "top": 1,
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcPediatric.add(lblPediatricPatient, rbtPediatric);
            var fcHospitalName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcHospitalName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcHospitalName.setDefaultUnit(voltmx.flex.DP);
            var lblHospital = new voltmx.ui.Label({
                "id": "lblHospital",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Hospital*",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbHospital = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbHospital",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "defListBoxNormal",
                "top": "0",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSearch = new voltmx.ui.Button({
                "bottom": 0,
                "focusSkin": "defBtnFocus",
                "id": "btnSearch",
                "isVisible": true,
                "left": "0%",
                "right": 0,
                "skin": "btnsknSearch",
                "top": "0%",
                "width": "15%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [3, 3, 4, 1],
                "paddingInPixel": false
            }, {});
            fcHospitalName.add(lblHospital, cmbHospital, btnSearch);
            var fcRoomType = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcRoomType",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRoomType.setDefaultUnit(voltmx.flex.DP);
            var lblTreatLoc = new voltmx.ui.Label({
                "id": "lblTreatLoc",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Treatment Location*",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbRoomType = new voltmx.ui.ListBox({
                "bottom": 0,
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "cmbRoomType",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": 0,
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcRoomType.add(lblTreatLoc, cmbRoomType);
            var fcRoomNum = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcRoomNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRoomNum.setDefaultUnit(voltmx.flex.DP);
            var lblRoomNumber = new voltmx.ui.Label({
                "id": "lblRoomNumber",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Room #*",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtRoomNum = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtRoomNum",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 25,
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "65%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            fcRoomNum.add(lblRoomNumber, txtRoomNum);
            var fcMedRecord = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcMedRecord",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMedRecord.setDefaultUnit(voltmx.flex.DP);
            var lblMRNumber = new voltmx.ui.Label({
                "id": "lblMRNumber",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Medical Record #*",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtMRNum = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtMRNum",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 25,
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "65%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            fcMedRecord.add(lblMRNumber, txtMRNum);
            var fcDoctorFName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcDoctorFName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcDoctorFName.setDefaultUnit(voltmx.flex.DP);
            var lblDoctorsFName = new voltmx.ui.Label({
                "id": "lblDoctorsFName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Doctor First Name",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtDoctorFirstName = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtDoctorFirstName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 25,
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "65%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            fcDoctorFName.add(lblDoctorsFName, txtDoctorFirstName);
            var fcDoctorLName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcDoctorLName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcDoctorLName.setDefaultUnit(voltmx.flex.DP);
            var lblDoctorLName = new voltmx.ui.Label({
                "id": "lblDoctorLName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Doctor Last Name",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtDoctorLastName = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtDoctorLastName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 25,
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "65%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            fcDoctorLName.add(lblDoctorLName, txtDoctorLastName);
            var fcStat = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcStat",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcStat.setDefaultUnit(voltmx.flex.DP);
            var lblStat = new voltmx.ui.Label({
                "id": "lblStat",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Stat",
                "textStyle": {},
                "top": "0",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var rbtStat = new voltmx.ui.RadioButtonGroup({
                "bottom": 1,
                "id": "rbtStat",
                "isVisible": true,
                "left": 2,
                "masterData": [
                    ["1", "Yes"],
                    ["2", "No"]
                ],
                "right": 2,
                "skin": "sknradioblueborder",
                "top": 1,
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcStat.add(lblStat, rbtStat);
            var fcIsolation = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcIsolation",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcIsolation.setDefaultUnit(voltmx.flex.DP);
            var lblIsolation = new voltmx.ui.Label({
                "id": "lblIsolation",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Isolation",
                "textStyle": {},
                "top": "0",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var rbtIsolation = new voltmx.ui.RadioButtonGroup({
                "bottom": 1,
                "id": "rbtIsolation",
                "isVisible": true,
                "left": 2,
                "masterData": [
                    ["1", "Yes"],
                    ["2", "No"]
                ],
                "right": 2,
                "skin": "sknradioblueborder",
                "top": 1,
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcIsolation.add(lblIsolation, rbtIsolation);
            fscPatientDetails.add(fcPLName, fcPFName, fcDOB, fcPreTreatment, fcPediatric, fcHospitalName, fcRoomType, fcRoomNum, fcMedRecord, fcDoctorFName, fcDoctorLName, fcStat, fcIsolation);
            fcOne.add(fscPatientDetails);
            var fcThree = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcThree",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcThree.setDefaultUnit(voltmx.flex.DP);
            var CopyfcVThree0db6cf321ad3747 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyfcVThree0db6cf321ad3747",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "0",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyfcVThree0db6cf321ad3747.setDefaultUnit(voltmx.flex.DP);
            var fcStartTreatment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcStartTreatment",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 1,
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcStartTreatment.setDefaultUnit(voltmx.flex.DP);
            var btnStartTreatment = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "id": "btnStartTreatment",
                "isVisible": true,
                "left": "0dp",
                "skin": "startBtnBlue",
                "text": "Start Treatment",
                "top": "0",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [1, 3, 1, 3],
                "paddingInPixel": false
            }, {});
            var lblStartTreatmentInfoText = new voltmx.ui.Label({
                "bottom": 1,
                "id": "lblStartTreatmentInfoText",
                "isVisible": true,
                "left": "0dp",
                "right": 0,
                "skin": "sknlblGreyFont80NoBorder",
                "text": "Tap button to pre-populate date and time.",
                "textStyle": {},
                "top": 1,
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            fcStartTreatment.add(btnStartTreatment, lblStartTreatmentInfoText);
            var CopylblCurDate0ja09ef4030e74e = new voltmx.ui.Label({
                "id": "CopylblCurDate0ja09ef4030e74e",
                "isVisible": true,
                "left": "0",
                "skin": "lblNormal",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopylblCurTime0e3f0f5084c9b4e = new voltmx.ui.Label({
                "id": "CopylblCurTime0e3f0f5084c9b4e",
                "isVisible": true,
                "left": "0",
                "skin": "lblNormal",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var fcLine1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20px",
                "id": "fcLine1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcLine1.setDefaultUnit(voltmx.flex.DP);
            fcLine1.add();
            var fcTreatmentDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcTreatmentDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 1,
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTreatmentDate.setDefaultUnit(voltmx.flex.DP);
            var lblDateofTreatment = new voltmx.ui.Label({
                "id": "lblDateofTreatment",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblTreatTypedisable",
                "text": "Date of Treatment",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtTretstartdate = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtTretstartdate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "text": "MM/DD/YYYY",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "59%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var calDOT = new voltmx.ui.Calendar({
                "bottom": 1,
                "calendarIcon": "calbtn.png",
                "dateComponents": [null, null, null],
                "dateFormat": "MM/dd/yyyy",
                "hour": 0,
                "id": "calDOT",
                "isVisible": true,
                "left": "0",
                "minutes": 0,
                "seconds": 0,
                "skin": "skncalWhitefont",
                "top": 1,
                "viewType": constants.CALENDAR_VIEW_TYPE_GRID_ONSCREEN,
                "width": "6%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcTreatmentDate.add(lblDateofTreatment, txtTretstartdate, calDOT);
            var fcLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20px",
                "id": "fcLine",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcLine.setDefaultUnit(voltmx.flex.DP);
            fcLine.add();
            var hbxTreatmentStartTime = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "hbxTreatmentStartTime",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 1,
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            hbxTreatmentStartTime.setDefaultUnit(voltmx.flex.DP);
            var lblTreatmentStartTime = new voltmx.ui.Label({
                "id": "lblTreatmentStartTime",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblTreatTypedisable",
                "text": "Treatment Start Time",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtStartTime = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtStartTime",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntbxtransparent",
                "text": "Hh:mm",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "59%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var calTreatmentStartTime = new voltmx.ui.Calendar({
                "bottom": 1,
                "calendarIcon": "icon_clock.png",
                "dateComponents": [null, null, null],
                "dateFormat": "MM/dd/yyyy",
                "hour": 0,
                "id": "calTreatmentStartTime",
                "isVisible": true,
                "left": "0",
                "minutes": 0,
                "seconds": 0,
                "skin": "skncalWhitefont",
                "top": 1,
                "viewType": constants.CALENDAR_VIEW_TYPE_GRID_ONSCREEN,
                "width": "6%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            hbxTreatmentStartTime.add(lblTreatmentStartTime, txtStartTime, calTreatmentStartTime);
            CopyfcVThree0db6cf321ad3747.add(fcStartTreatment, CopylblCurDate0ja09ef4030e74e, CopylblCurTime0e3f0f5084c9b4e, fcLine1, fcTreatmentDate, fcLine, hbxTreatmentStartTime);
            fcThree.add(CopyfcVThree0db6cf321ad3747);
            fcRightPane.add(fcFour, fcOne, fcThree);
            fcMain.add(fcLeftPane, fcRightPane);
            var fcpopupHospitalSearch = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "70%",
                "id": "fcpopupHospitalSearch",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "0",
                "width": "80%",
                "zIndex": 2,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcpopupHospitalSearch.setDefaultUnit(voltmx.flex.PERCENTAGE);
            var CopyFlexContainer0b332bcc929584e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "CopyFlexContainer0b332bcc929584e",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcbluebgwithblackborder12",
                "top": "0",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0b332bcc929584e.setDefaultUnit(voltmx.flex.DP);
            var CopylblHeader0fc007f258bb94e = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "CopylblHeader0fc007f258bb94e",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblWhiteLogin",
                "text": "Hospital Search",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0b332bcc929584e.add(CopylblHeader0fc007f258bb94e);
            var FlexContainer0c3872d724a6c4b = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90%",
                "id": "FlexContainer0c3872d724a6c4b",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcblueBorder",
                "top": "10%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0c3872d724a6c4b.setDefaultUnit(voltmx.flex.DP);
            var fcGroup = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcGroup",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcWhtBG",
                "top": "0",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcGroup.setDefaultUnit(voltmx.flex.DP);
            var lblGroup = new voltmx.ui.Label({
                "id": "lblGroup",
                "isVisible": true,
                "left": "0dp",
                "skin": "defLabel",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_popupHospSearch_lblGroup\")",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbGroup = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbGroup",
                "isVisible": true,
                "masterData": [
                    ["null", "Please Select..."]
                ],
                "onSelection": controller.AS_ListBox_fe3acfb2285d4456ac78699ad0a38a4a,
                "right": "0dp",
                "selectedKey": "null",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {});
            fcGroup.add(lblGroup, cmbGroup);
            var fcDivision = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcDivision",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknfcWhtBG",
                "top": "10%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcDivision.setDefaultUnit(voltmx.flex.DP);
            var lblDivision = new voltmx.ui.Label({
                "id": "lblDivision",
                "isVisible": true,
                "left": "0dp",
                "skin": "defLabel",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_popupHospSearch_lblDivision\")",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbDivision = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbDivision",
                "isVisible": true,
                "masterData": [
                    ["null", "Please Select..."]
                ],
                "right": "0dp",
                "selectedKey": "null",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {});
            fcDivision.add(lblDivision, cmbDivision);
            var fcRegion = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcRegion",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknfcWhtBG",
                "top": "20%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRegion.setDefaultUnit(voltmx.flex.DP);
            var lblRegion = new voltmx.ui.Label({
                "id": "lblRegion",
                "isVisible": true,
                "left": "0dp",
                "skin": "defLabel",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_popupHospSearch_lblRegion\")",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbRegion = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "id": "cmbRegion",
                "isVisible": true,
                "masterData": [
                    ["null", "Please Select..."]
                ],
                "right": "0dp",
                "selectedKey": "null",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {});
            fcRegion.add(lblRegion, cmbRegion);
            var FlexContainer0ddbe5c96989649 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "FlexContainer0ddbe5c96989649",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcLightGreyBG",
                "top": "30%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0ddbe5c96989649.setDefaultUnit(voltmx.flex.DP);
            var btnLoad = new voltmx.ui.Button({
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnLoad",
                "isVisible": true,
                "left": "2%",
                "skin": "btnsknLoad",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_popupHospSearch_btnLoad\")",
                "top": "0",
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new voltmx.ui.Button({
                "bottom": "0",
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "10dp",
                "skin": "btnskncancel",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_popupHospSearch_btnCancel\")",
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0ddbe5c96989649.add(btnLoad, btnCancel);
            var FlexContainer0f17422f82ca645 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "FlexContainer0f17422f82ca645",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcDarkGreyBG",
                "top": "40%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0f17422f82ca645.setDefaultUnit(voltmx.flex.DP);
            var lblHospitalPopup = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblHospitalPopup",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlblWhiteLogin",
                "text": "Hospital",
                "textStyle": {},
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            FlexContainer0f17422f82ca645.add(lblHospitalPopup);
            voltmx.mvc.registry.add('FBox0d3323315729948', 'FBox0d3323315729948', 'FBox0d3323315729948Controller');
            var segHospitalData = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblsegHospdesc": "Label"
                }, {
                    "lblsegHospdesc": "Label"
                }, {
                    "lblsegHospdesc": "Label"
                }, {
                    "lblsegHospdesc": "Label"
                }, {
                    "lblsegHospdesc": "Label"
                }],
                "groupCells": false,
                "id": "segHospitalData",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "FBox0d3323315729948",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "50%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "lblsegHospdesc": "lblsegHospdesc"
                },
                "width": "100%",
                "appName": "AMII"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0c3872d724a6c4b.add(fcGroup, fcDivision, fcRegion, FlexContainer0ddbe5c96989649, FlexContainer0f17422f82ca645, segHospitalData);
            fcpopupHospitalSearch.add(CopyFlexContainer0b332bcc929584e, FlexContainer0c3872d724a6c4b);
            this.add(fcMainheader, fcMain, fcpopupHospitalSearch);
        };
        return [{
            "addWidgets": addWidgetsfrmPatientDetails,
            "enabledForIdleTimeout": false,
            "id": "frmPatientDetails",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_d6695b5549d6428eb19178f9161badfb,
            "preShow": function(eventobject) {
                controller.AS_Form_abe7caa7ee744c28840c016c4492109a(eventobject);
                controller.AS_Form_i386ac18cbe543cba4f3bc0e85348c1f(eventobject);
            },
            "skin": "sknform",
            "appName": "AMII"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_BOTH,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});