define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(voltmx.flex.DP);
            var fcOne = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "fcOne",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0c4c4d816c42d48",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOne.setDefaultUnit(voltmx.flex.DP);
            var lblAccHeader = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "lblAccHeader",
                "isVisible": true,
                "skin": "sknlblHomeHeaderWhitefont",
                "text": "Acutes Charge Capture",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 2, 0, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblVersion = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "lblVersion",
                "isVisible": true,
                "skin": "sknlblHomeHeaderWhitefont",
                "text": "Version: 5",
                "textStyle": {},
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            fcOne.add(lblAccHeader, lblVersion);
            var fcTwo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "5%",
                "id": "fcTwo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "sknfcblueBorder",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTwo.setDefaultUnit(voltmx.flex.DP);
            var lblNurseUserName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblNurseUserName",
                "isVisible": true,
                "left": "5%",
                "skin": "sknlblwelcomeLabel",
                "textStyle": {},
                "width": "69%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var fcbtnLogout = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerY": "50%",
                "clipBounds": false,
                "enableScrolling": true,
                "height": "80px",
                "horizontalScrollIndicator": true,
                "id": "fcbtnLogout",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "19%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            fcbtnLogout.setDefaultUnit(voltmx.flex.DP);
            var btnLogout = new voltmx.ui.Button({
                "bottom": "1%",
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "height": "70px",
                "id": "btnLogout",
                "isVisible": true,
                "right": "0%",
                "skin": "sknbtnlogout",
                "top": "0%",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 1],
                "paddingInPixel": false
            }, {});
            fcbtnLogout.add(btnLogout);
            fcTwo.add(lblNurseUserName, fcbtnLogout);
            var fcThree = new voltmx.ui.FlexContainer({
                "clipBounds": false,
                "height": "85%",
                "id": "fcThree",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcmainbg",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcThree.setDefaultUnit(voltmx.flex.DP);
            var fcHomeOne = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "10%",
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "fcHomeOne",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "10%",
                "isModalContainer": false,
                "right": "10%",
                "skin": "noSkinFC",
                "top": "0%",
                "width": "80%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcHomeOne.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0a6e76b788f3b49 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35%",
                "id": "FlexContainer0a6e76b788f3b49",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcWhtBG",
                "top": "6%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0a6e76b788f3b49.setDefaultUnit(voltmx.flex.DP);
            var fcSavedTreatments = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "6%",
                "clipBounds": false,
                "height": "88%",
                "id": "fcSavedTreatments",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcblueBorder",
                "top": "6%",
                "width": "96%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcSavedTreatments.setDefaultUnit(voltmx.flex.DP);
            var lblSavedTrtmnts = new voltmx.ui.Label({
                "height": "10%",
                "id": "lblSavedTrtmnts",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblSavetreatment",
                "text": "Saved Treatment(s)",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 2, 0, 2],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var FlexContainer0cbae1435768546 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "10%",
                "id": "FlexContainer0cbae1435768546",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfclightBlue",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0cbae1435768546.setDefaultUnit(voltmx.flex.DP);
            var lblSLastName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblSLastName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblLightgreyfont",
                "text": "Last Name",
                "textStyle": {},
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblSFirstName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblSFirstName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblLightgreyfont",
                "text": "First Name",
                "textStyle": {},
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblSMRNum = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblSMRNum",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblLightgreyfont",
                "text": "Medical Record #",
                "textStyle": {},
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            FlexContainer0cbae1435768546.add(lblSLastName, lblSFirstName, lblSMRNum);
            var scfcSavedtreatments = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "80%",
                "horizontalScrollIndicator": true,
                "id": "scfcSavedtreatments",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            scfcSavedtreatments.setDefaultUnit(voltmx.flex.DP);
            voltmx.mvc.registry.add('FBox0jce3a5b497b34e', 'FBox0jce3a5b497b34e', 'FBox0jce3a5b497b34eController');
            var segSavedTreatments = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "data": [{
                    "btnEdit": "",
                    "lblSavedFirstName": "",
                    "lblSavedLastName": "",
                    "lblSavedMedRecordNum": ""
                }],
                "groupCells": false,
                "height": "90%",
                "id": "segSavedTreatments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "sknsegWhtBG",
                "rowTemplate": "FBox0jce3a5b497b34e",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnEdit": "btnEdit",
                    "lblSavedFirstName": "lblSavedFirstName",
                    "lblSavedLastName": "lblSavedLastName",
                    "lblSavedMedRecordNum": "lblSavedMedRecordNum"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            scfcSavedtreatments.add(segSavedTreatments);
            fcSavedTreatments.add(lblSavedTrtmnts, FlexContainer0cbae1435768546, scfcSavedtreatments);
            FlexContainer0a6e76b788f3b49.add(fcSavedTreatments);
            var FlexContainer0ieddbe59b4424e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35%",
                "id": "FlexContainer0ieddbe59b4424e",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcWhtBG",
                "top": "6%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0ieddbe59b4424e.setDefaultUnit(voltmx.flex.DP);
            var fcTransmitWait = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "6%",
                "clipBounds": false,
                "id": "fcTransmitWait",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcblueBorder",
                "top": "6%",
                "width": "96%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTransmitWait.setDefaultUnit(voltmx.flex.DP);
            var lblTransmitWait = new voltmx.ui.Label({
                "id": "lblTransmitWait",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblSavetreatment",
                "text": "Waiting to Transmit",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 2, 0, 2],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var CopyFlexContainer0e4d55485531f4e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": 40,
                "id": "CopyFlexContainer0e4d55485531f4e",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfclightBlue",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0e4d55485531f4e.setDefaultUnit(voltmx.flex.DP);
            var lblWLastName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblWLastName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblLightgreyfont",
                "text": "Last Name",
                "textStyle": {},
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblWFirstName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblWFirstName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblLightgreyfont",
                "text": "First Name",
                "textStyle": {},
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblWMRNum = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblWMRNum",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblLightgreyfont",
                "text": "Medical Record #",
                "textStyle": {},
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            CopyFlexContainer0e4d55485531f4e.add(lblWLastName, lblWFirstName, lblWMRNum);
            var scfcWaitingtotansmit = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "scfcWaitingtotansmit",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            scfcWaitingtotansmit.setDefaultUnit(voltmx.flex.DP);
            voltmx.mvc.registry.add('CopyFBox0e0feafe301d842', 'CopyFBox0e0feafe301d842', 'CopyFBox0e0feafe301d842Controller');
            var segWaitingTransmit = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "data": [{
                    "btnEdit": "",
                    "lblSavedFirstName": "",
                    "lblSavedLastName": "",
                    "lblSavedMedRecordNum": ""
                }],
                "groupCells": false,
                "height": "90%",
                "id": "segWaitingTransmit",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "sknsegWhtBG",
                "rowTemplate": "CopyFBox0e0feafe301d842",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnEdit": "btnEdit",
                    "lblSavedFirstName": "lblSavedFirstName",
                    "lblSavedLastName": "lblSavedLastName",
                    "lblSavedMedRecordNum": "lblSavedMedRecordNum"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            scfcWaitingtotansmit.add(segWaitingTransmit);
            fcTransmitWait.add(lblTransmitWait, CopyFlexContainer0e4d55485531f4e, scfcWaitingtotansmit);
            FlexContainer0ieddbe59b4424e.add(fcTransmitWait);
            var fcHomeButtons = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcHomeButtons",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20%",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcHomeButtons.setDefaultUnit(voltmx.flex.DP);
            var fcbtnNew = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "fcbtnNew",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "verticalScrollIndicator": true,
                "width": "33%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            fcbtnNew.setDefaultUnit(voltmx.flex.DP);
            var btnNew = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "100px",
                "id": "btnNew",
                "isVisible": true,
                "left": "0dp",
                "onClick": controller.AS_Button_jcd29a3920f8497fad00fb728a98790d,
                "skin": "sknbtnNew",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcbtnNew.add(btnNew);
            var fcbtnSync = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "fcbtnSync",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "verticalScrollIndicator": true,
                "width": "30%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            fcbtnSync.setDefaultUnit(voltmx.flex.DP);
            var btnSync = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "100px",
                "id": "btnSync",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknbtnSync",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcbtnSync.add(btnSync);
            var fcbtnTransmitAll = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "fcbtnTransmitAll",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "40%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            fcbtnTransmitAll.setDefaultUnit(voltmx.flex.DP);
            var btnTransmitAll = new voltmx.ui.Button({
                "centerX": "50%",
                "focusSkin": "defBtnFocus",
                "height": "100px",
                "id": "btnTransmitAll",
                "isVisible": true,
                "right": "0",
                "skin": "sknbtnTransmitAll",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcbtnTransmitAll.add(btnTransmitAll);
            fcHomeButtons.add(fcbtnNew, fcbtnSync, fcbtnTransmitAll);
            fcHomeOne.add(FlexContainer0a6e76b788f3b49, FlexContainer0ieddbe59b4424e, fcHomeButtons);
            fcThree.add(fcHomeOne);
            this.add(fcOne, fcTwo, fcThree);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "postShow": controller.AS_Form_df5bc4c27ed64d5092bae578211499d5,
            "preShow": function(eventobject) {
                controller.AS_Form_dcc0d3087f7e4c4683b1f14b4d3d2b9b(eventobject);
            },
            "skin": "sknfrmHomescreen",
            "appName": "AMII"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_BOTH,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});