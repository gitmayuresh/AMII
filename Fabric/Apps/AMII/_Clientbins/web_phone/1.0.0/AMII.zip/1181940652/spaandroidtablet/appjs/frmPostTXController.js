define("userfrmPostTXController", {
    collectfrmPostTXData: function() {
        var self = this;
        this.patientTreatmentData.TreatmentType_Results = self.view.tbxTreatmentTypeResults.text;
        this.patientTreatmentData.Treatment_Start_Time = self.view.tbxTreatmentStartTime.text;
        // ... collect other fields from this form
        this.patientTreatmentData.ID = voltmx.visualizer.toNumber(self.view.tbxID.text); //Example
    }, //Type your controller code here 
});
define("frmPostTXControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_d3e9d3055fba4da9b022ca14e7dd81cb: function AS_Button_d3e9d3055fba4da9b022ca14e7dd81cb(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    },
    AS_Button_a02a2c736e89455b9d2cc7d350bc2ce3: function AS_Button_a02a2c736e89455b9d2cc7d350bc2ce3(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_db5d81a515ab4f6ea151ebc0a97f8307: function AS_FlexContainer_db5d81a515ab4f6ea151ebc0a97f8307(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frnACOI"
        });
        ntf.navigate();
    },
    AS_FlexContainer_d21c8db1c2464ef485c4a3142d26d089: function AS_FlexContainer_d21c8db1c2464ef485c4a3142d26d089(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frnOtherDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_eab2cd76af4040879d8a3eeebb5cdfb2: function AS_FlexContainer_eab2cd76af4040879d8a3eeebb5cdfb2(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPatientDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_a5fa8524bc66444d9fc4f1011688383d: function AS_FlexContainer_a5fa8524bc66444d9fc4f1011688383d(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    }
});
define("frmPostTXController", ["userfrmPostTXController", "frmPostTXControllerActions"], function() {
    var controller = require("userfrmPostTXController");
    var controllerActions = ["frmPostTXControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
