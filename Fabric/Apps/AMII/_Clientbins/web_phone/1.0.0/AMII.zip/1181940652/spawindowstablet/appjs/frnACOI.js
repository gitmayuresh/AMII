define("frnACOI", function() {
    return function(controller) {
        function addWidgetsfrnACOI() {
            this.setDefaultUnit(voltmx.flex.DP);
            var Segment0bce5387eec0b45 = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "50dp",
                "id": "Segment0bce5387eec0b45",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": "fcMainheader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "FlexContainer0f9a5d5a46d0045": "FlexContainer0f9a5d5a46d0045",
                    "FlexContainer0i002cdfd3b8f4c": "FlexContainer0i002cdfd3b8f4c",
                    "Label0gf45b249bf6445": "Label0gf45b249bf6445",
                    "btnHeaderBack": "btnHeaderBack",
                    "btnHeaderNext": "btnHeaderNext",
                    "fcMainheader": "fcMainheader",
                    "lblHeader": "lblHeader"
                },
                "width": "100%",
                "appName": "AMII"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var fcMain = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "fcMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMain.setDefaultUnit(voltmx.flex.DP);
            var fcLeftPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcLeftPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfclightGreyborder",
                "top": 0,
                "width": "33%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcLeftPane.setDefaultUnit(voltmx.flex.DP);
            var fcPatient = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPatient",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_dd6962c7274344ca87f997e472f38bf5,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPatient.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0fecbd5d4f3644c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "FlexContainer0fecbd5d4f3644c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0fecbd5d4f3644c.setDefaultUnit(voltmx.flex.DP);
            var lblPatientNav = new voltmx.ui.Label({
                "id": "lblPatientNav",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Patient Data",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            FlexContainer0fecbd5d4f3644c.add(lblPatientNav, lblErrorMsg);
            fcPatient.add(FlexContainer0fecbd5d4f3644c);
            var fcTreatment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcTreatment",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_h760cd0b348745e6967ff8de0b477a4c,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTreatment.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0df4325fbec3c44 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0df4325fbec3c44",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0df4325fbec3c44.setDefaultUnit(voltmx.flex.DP);
            var lblTreatmentScreen = new voltmx.ui.Label({
                "id": "lblTreatmentScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Treatment Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblTreatmentErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblTreatmentErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            CopyFlexContainer0df4325fbec3c44.add(lblTreatmentScreen, lblTreatmentErrorMsg);
            fcTreatment.add(CopyFlexContainer0df4325fbec3c44);
            var fcOther = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcOther",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_c51a6ba1f64c429da2f75cdcfb0d88a8,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOther.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0a75a811f614948 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0a75a811f614948",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0a75a811f614948.setDefaultUnit(voltmx.flex.DP);
            var lblOtherScreen = new voltmx.ui.Label({
                "id": "lblOtherScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Other Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblOtherErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblOtherErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            CopyFlexContainer0a75a811f614948.add(lblOtherScreen, lblOtherErrorMsg);
            fcOther.add(CopyFlexContainer0a75a811f614948);
            var fcPostTX = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPostTX",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_g830f6b6c5424a69b0bc9d90a4c43fa3,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPostTX.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0f6b7a0518ac744 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0f6b7a0518ac744",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0f6b7a0518ac744.setDefaultUnit(voltmx.flex.DP);
            var lblPostTxScreen = new voltmx.ui.Label({
                "id": "lblPostTxScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Post Treatment",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblPostTxErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblPostTxErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            CopyFlexContainer0f6b7a0518ac744.add(lblPostTxScreen, lblPostTxErrormsg);
            fcPostTX.add(CopyFlexContainer0f6b7a0518ac744);
            var fcACOI = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcACOI",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcselectedButton",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcACOI.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0e24933d63b4840 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0e24933d63b4840",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0e24933d63b4840.setDefaultUnit(voltmx.flex.DP);
            var lblACOIDetails = new voltmx.ui.Label({
                "id": "lblACOIDetails",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "ACOI Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var lblAcoiErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblAcoiErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            CopyFlexContainer0e24933d63b4840.add(lblACOIDetails, lblAcoiErrormsg);
            var FlexContainer0b0b44683307d49 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0",
                "centerY": "50%",
                "clipBounds": false,
                "id": "FlexContainer0b0b44683307d49",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "width": "11%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0b0b44683307d49.setDefaultUnit(voltmx.flex.DP);
            var imgArrow = new voltmx.ui.Image2({
                "height": "100%",
                "id": "imgArrow",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "arrow_blue.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0b0b44683307d49.add(imgArrow);
            fcACOI.add(CopyFlexContainer0e24933d63b4840, FlexContainer0b0b44683307d49);
            fcLeftPane.add(fcPatient, fcTreatment, fcOther, fcPostTX, fcACOI);
            var fcRightPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcRightPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0",
                "skin": "sknfcrightPane",
                "top": "0dp",
                "width": "66%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRightPane.setDefaultUnit(voltmx.flex.DP);
            var fcTwo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": false,
                "height": "100px",
                "id": "fcTwo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "top": "20px",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTwo.setDefaultUnit(voltmx.flex.DP);
            var CopylblPatientNameCaptured0cab18c7e6a194d = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopylblPatientNameCaptured0cab18c7e6a194d",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Patient Name:",
                "textStyle": {},
                "width": "27%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var CopylblCapturedPatientName0dacd65860f0849 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopylblCapturedPatientName0dacd65860f0849",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            fcTwo.add(CopylblPatientNameCaptured0cab18c7e6a194d, CopylblCapturedPatientName0dacd65860f0849);
            var fcOne = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcOne",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOne.setDefaultUnit(voltmx.flex.DP);
            var fscACOI = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "fscACOI",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "minHeight": "1400px",
                "pagingEnabled": false,
                "right": "2%",
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "noSkinFcScrollbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "96%"
            }, {
                "paddingInPixel": false
            }, {});
            fscACOI.setDefaultUnit(voltmx.flex.DP);
            var fcVA = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcVA",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcVA.setDefaultUnit(voltmx.flex.DP);
            var lblVAInfec = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblVAInfec",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Were complete orders present when TM arrived to perform treatment?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtVAInfec = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtVAInfec",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcVA.add(lblVAInfec, rbtVAInfec);
            var fcAccess = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcAccess",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcAccess.setDefaultUnit(voltmx.flex.DP);
            var lblAcessProb = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblAcessProb",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was Physician notified of access issues ? (N/A if no issues)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtAcessProb = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtAcessProb",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcAccess.add(lblAcessProb, rbtAcessProb);
            var fcUnauthor = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcUnauthor",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcUnauthor.setDefaultUnit(voltmx.flex.DP);
            var lblUnauthUseAcc = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblUnauthUseAcc",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was there evidence of non dialysis use of access?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtUnauthUseAcc = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtUnauthUseAcc",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcUnauthor.add(lblUnauthUseAcc, rbtUnauthUseAcc);
            var fcWasAccess = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcWasAccess",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcWasAccess.setDefaultUnit(voltmx.flex.DP);
            var lblWasAccessfun = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblWasAccessfun",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was access functional upon initial assessment?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtWasAccessfun = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtWasAccessfun",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcWasAccess.add(lblWasAccessfun, rbtWasAccessfun);
            var fcTimeMet = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcTimeMet",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTimeMet.setDefaultUnit(voltmx.flex.DP);
            var lblTXtimemet = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblTXtimemet",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Did ordered time (includes intra-dialytic order changes) = Run Time?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtTXtimemet = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtTXtimemet",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcTimeMet.add(lblTXtimemet, rbtTXtimemet);
            var fcUF = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcUF",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcUF.setDefaultUnit(voltmx.flex.DP);
            var lblUFgoalmet = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblUFgoalmet",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Did ordered UF goal (includes intra-dialytic order changes) = Net UF?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtUFgoalmet = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtUFgoalmet",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcUF.add(lblUFgoalmet, rbtUFgoalmet);
            var fcPrewtDone = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPrewtDone",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPrewtDone.setDefaultUnit(voltmx.flex.DP);
            var lblPrewtdone = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPrewtdone",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was Pre Weight performed? (N/A if not ordered)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtPrewtdone = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtPrewtdone",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcPrewtDone.add(lblPrewtdone, rbtPrewtdone);
            var fcPostWieght = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPostWieght",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPostWieght.setDefaultUnit(voltmx.flex.DP);
            var lblPostWtDone = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPostWtDone",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was Post Weight performed? (N/A if not ordered)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtPostWTdone = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtPostWTdone",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcPostWieght.add(lblPostWtDone, rbtPostWTdone);
            var fcHypoTensn = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcHypoTensn",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcHypoTensn.setDefaultUnit(voltmx.flex.DP);
            var lblHypoTension = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblHypoTension",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was treatment delayed due to Patient, Floor, Escort or other Depts?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtHypoTension = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtHypoTension",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcHypoTensn.add(lblHypoTension, rbtHypoTension);
            var fcLowBP = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcLowBP",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcLowBP.setDefaultUnit(voltmx.flex.DP);
            var lblLowBPTx = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblLowBPTx",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was treatment delayed due to access, machine or dialysis staffing?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtLowBPTx = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtLowBPTx",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcLowBP.add(lblLowBPTx, rbtLowBPTx);
            var fcDLYz = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcDLYz",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcDLYz.setDefaultUnit(voltmx.flex.DP);
            var lblDLYz = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblDLYz",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Access (CVC/AVF/AVG) without signs or symptoms of infection?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtDLYz = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtDLYz",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcDLYz.add(lblDLYz, rbtDLYz);
            var fcPainEvaluation = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPainEvaluation",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPainEvaluation.setDefaultUnit(voltmx.flex.DP);
            var lblPainEval = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPainEval",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was pain assessed and documented prior to treatment initiation?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtPainEval = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtPainEval",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcPainEvaluation.add(lblPainEval, rbtPainEval);
            var fcAntiCoag = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcAntiCoag",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcAntiCoag.setDefaultUnit(voltmx.flex.DP);
            var lblAntiCoag = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblAntiCoag",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was response to pain medication documented? (N/A if no med given)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtAntiCoag = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtAntiCoag",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcAntiCoag.add(lblAntiCoag, rbtAntiCoag);
            var fcESRD = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcESRD",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcESRD.setDefaultUnit(voltmx.flex.DP);
            var lblESRD = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblESRD",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was education provided to patient &/or family and documented?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtESRD = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtESRD",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcESRD.add(lblESRD, rbtESRD);
            var fcTimeoutDone = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcTimeoutDone",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTimeoutDone.setDefaultUnit(voltmx.flex.DP);
            var lblTimeOut = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblTimeOut",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Time-Out/Safety Process per DaVita P&P performed and documented?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtTimeOut = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtTimeOut",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcTimeoutDone.add(lblTimeOut, rbtTimeOut);
            var fcCallorCrit = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcCallorCrit",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcCallorCrit.setDefaultUnit(voltmx.flex.DP);
            var lblCallorCrit = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblCallorCrit",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Any Hypotensive episodes leading to a decrease in UF Goal?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtCallorCrit = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtCallorCrit",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcCallorCrit.add(lblCallorCrit, rbtCallorCrit);
            var fcHgbLess = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcHgbLess",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcHgbLess.setDefaultUnit(voltmx.flex.DP);
            var lblHgbLess = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblHgbLess",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Any Hypotensive episode leading to Albumin administration?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtHgbless = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtHgbless",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcHgbLess.add(lblHgbLess, rbtHgbless);
            var fcKAbove6 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcKAbove6",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcKAbove6.setDefaultUnit(voltmx.flex.DP);
            var lblKAbove6 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblKAbove6",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Any Hypotension leading to Vasopressors initiated / titrated during HD?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtKAbove6 = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtKAbove6",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcKAbove6.add(lblKAbove6, rbtKAbove6);
            var fcKAbove3 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcKAbove3",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcKAbove3.setDefaultUnit(voltmx.flex.DP);
            var lblKabove3 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblKabove3",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Any Hypotension leading to Vasopressors initiated / titrated during HD?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtKabove3 = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtKabove3",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcKAbove3.add(lblKabove3, rbtKabove3);
            var fcOrderonArr = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcOrderonArr",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOrderonArr.setDefaultUnit(voltmx.flex.DP);
            var lblOrderonArr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblOrderonArr",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was treatment terminated early due to hypotension?",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtOrderonArr = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtOrderonArr",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcOrderonArr.add(lblOrderonArr, rbtOrderonArr);
            var fcWasCVCDZSoiled = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcWasCVCDZSoiled",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcWasCVCDZSoiled.setDefaultUnit(voltmx.flex.DP);
            var lblWasCVCDZSoiled = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblWasCVCDZSoiled",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was the CVC dressing soiled upon arrival? (N/A if CVC is not present)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtWasCVCDZSoiled = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtWasCVCDZSoiled",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcWasCVCDZSoiled.add(lblWasCVCDZSoiled, rbtWasCVCDZSoiled);
            var fcWasCVCDZLblInt = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcWasCVCDZLblInt",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcWasCVCDZLblInt.setDefaultUnit(voltmx.flex.DP);
            var lblWasCVCDZLblInt = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblWasCVCDZLblInt",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was the CVC dressing soiled upon arrival? (N/A if CVC is not present)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtWasCVCDZLblInt = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtWasCVCDZLblInt",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcWasCVCDZLblInt.add(lblWasCVCDZLblInt, rbtWasCVCDZLblInt);
            var fcWasCVCDZMis = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcWasCVCDZMis",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcWasCVCDZMis.setDefaultUnit(voltmx.flex.DP);
            var lblWasCVCDZMis = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblWasCVCDZMis",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was the dressing missing on the patient's CVC upon arrival? (N/A if CVC is not present)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtWasCVCDZMis = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtWasCVCDZMis",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcWasCVCDZMis.add(lblWasCVCDZMis, rbtWasCVCDZMis);
            var fcPtTemp = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcPtTemp",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPtTemp.setDefaultUnit(voltmx.flex.DP);
            var lblPtTemp = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPtTemp",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Was the patient's temperature >= 100.4 degrees Fahrenheit pretreatment? (N/A if CVC is not present)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtPtTemp = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtPtTemp",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcPtTemp.add(lblPtTemp, rbtPtTemp);
            var fcBldCltPer = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcBldCltPer",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcBldCltPer.setDefaultUnit(voltmx.flex.DP);
            var lblBldCltPer = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblBldCltPer",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Were blood cultures drawn peripherally? (N/A if CVC is not present)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtBldCltPer = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtBldCltPer",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcBldCltPer.add(lblBldCltPer, rbtBldCltPer);
            var fcBldCltCVC = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120px",
                "id": "fcBldCltCVC",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "noSkinFC",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcBldCltCVC.setDefaultUnit(voltmx.flex.DP);
            var lblBldCltCVC = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblBldCltCVC",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Were blood cultures drawn from the CVC? (N/A if CVC is not present)",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false
            });
            var rbtBldCltCVC = new voltmx.ui.RadioButtonGroup({
                "centerY": "50%",
                "id": "rbtBldCltCVC",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["a", "Yes"],
                    ["b", "No"],
                    ["c", "NA"]
                ],
                "skin": "sknradioblueborder",
                "width": "27%"
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcBldCltCVC.add(lblBldCltCVC, rbtBldCltCVC);
            fscACOI.add(fcVA, fcAccess, fcUnauthor, fcWasAccess, fcTimeMet, fcUF, fcPrewtDone, fcPostWieght, fcHypoTensn, fcLowBP, fcDLYz, fcPainEvaluation, fcAntiCoag, fcESRD, fcTimeoutDone, fcCallorCrit, fcHgbLess, fcKAbove6, fcKAbove3, fcOrderonArr, fcWasCVCDZSoiled, fcWasCVCDZLblInt, fcWasCVCDZMis, fcPtTemp, fcBldCltPer, fcBldCltCVC);
            fcOne.add(fscACOI);
            fcRightPane.add(fcTwo, fcOne);
            fcMain.add(fcLeftPane, fcRightPane);
            this.add(Segment0bce5387eec0b45, fcMain);
        };
        return [{
            "addWidgets": addWidgetsfrnACOI,
            "enabledForIdleTimeout": false,
            "id": "frnACOI",
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "skin": "sknform",
            "appName": "AMII"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_BOTH,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});