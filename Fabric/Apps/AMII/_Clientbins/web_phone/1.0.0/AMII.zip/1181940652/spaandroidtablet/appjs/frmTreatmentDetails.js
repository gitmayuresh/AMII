define("frmTreatmentDetails", function() {
    return function(controller) {
        function addWidgetsfrmTreatmentDetails() {
            this.setDefaultUnit(voltmx.flex.DP);
            var fcMainHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "5%",
                "id": "fcMainHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknfcHeader",
                "top": "0",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMainHeader.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0ef6ae736d2ae45 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopyLabel0ef6ae736d2ae45",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblWhiteLogin",
                "text": "Acutes Charge Capture",
                "textStyle": {},
                "width": "33%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopyFlexContainer0c833ac39b80c4c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0c833ac39b80c4c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcbluebgwithblackborder12",
                "top": "0",
                "width": "67%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0c833ac39b80c4c.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0h115220ee8cc4d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0h115220ee8cc4d",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "90%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0h115220ee8cc4d.setDefaultUnit(voltmx.flex.DP);
            var btnBack = new voltmx.ui.Button({
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "height": "80%",
                "id": "btnBack",
                "isVisible": true,
                "left": "0%",
                "onClick": controller.AS_Button_f2be68c4ffea4d248b2d224121347e41,
                "skin": "sknbtnback",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_appHeader_btnBack\")",
                "top": "0",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [3, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var CopylblHeader0b8ecf484c63746 = new voltmx.ui.Label({
                "id": "CopylblHeader0b8ecf484c63746",
                "isVisible": true,
                "skin": "sknlblWhiteLogin",
                "text": "Patient Data",
                "textStyle": {},
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopybtnHeaderNext0a87fde2554714c = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "80%",
                "id": "CopybtnHeaderNext0a87fde2554714c",
                "isVisible": true,
                "onClick": controller.AS_Button_c1ef1a9c7cdb4c78ac6e4abd663abf3a,
                "skin": "sknbtnnext",
                "text": "Next",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [3, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0h115220ee8cc4d.add(btnBack, CopylblHeader0b8ecf484c63746, CopybtnHeaderNext0a87fde2554714c);
            CopyFlexContainer0c833ac39b80c4c.add(CopyFlexContainer0h115220ee8cc4d);
            fcMainHeader.add(CopyLabel0ef6ae736d2ae45, CopyFlexContainer0c833ac39b80c4c);
            var fcMain = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": false,
                "height": "90%",
                "id": "fcMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "right": 0,
                "skin": "noSkinFC",
                "top": "5%",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcMain.setDefaultUnit(voltmx.flex.DP);
            var fcLeftPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcLeftPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfclightGreyborder",
                "top": 0,
                "width": "33%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcLeftPane.setDefaultUnit(voltmx.flex.DP);
            var fcPatient = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPatient",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_fc9106fa175b441782f4ce5d85b51bfc,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPatient.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0fecbd5d4f3644c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "FlexContainer0fecbd5d4f3644c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0fecbd5d4f3644c.setDefaultUnit(voltmx.flex.DP);
            var lblPatientNav = new voltmx.ui.Label({
                "id": "lblPatientNav",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Patient Data",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            FlexContainer0fecbd5d4f3644c.add(lblPatientNav, lblErrorMsg);
            fcPatient.add(FlexContainer0fecbd5d4f3644c);
            var fcTreatment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcTreatment",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfcselectedButton",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTreatment.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0df4325fbec3c44 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0df4325fbec3c44",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0df4325fbec3c44.setDefaultUnit(voltmx.flex.DP);
            var lblTreatmentScreen = new voltmx.ui.Label({
                "id": "lblTreatmentScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Treatment Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblTreatmentErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblTreatmentErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0df4325fbec3c44.add(lblTreatmentScreen, lblTreatmentErrorMsg);
            var FlexContainer0b0b44683307d49 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0",
                "centerY": "50%",
                "clipBounds": false,
                "id": "FlexContainer0b0b44683307d49",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "width": "11%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0b0b44683307d49.setDefaultUnit(voltmx.flex.DP);
            var imgArrow = new voltmx.ui.Image2({
                "height": "100%",
                "id": "imgArrow",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "arrow_blue.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0b0b44683307d49.add(imgArrow);
            fcTreatment.add(CopyFlexContainer0df4325fbec3c44, FlexContainer0b0b44683307d49);
            var fcOther = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcOther",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_e2370251344341fb83d5abde982be3e7,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOther.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0a75a811f614948 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0a75a811f614948",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0a75a811f614948.setDefaultUnit(voltmx.flex.DP);
            var lblOtherScreen = new voltmx.ui.Label({
                "id": "lblOtherScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Other Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblOtherErrorMsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblOtherErrorMsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0a75a811f614948.add(lblOtherScreen, lblOtherErrorMsg);
            fcOther.add(CopyFlexContainer0a75a811f614948);
            var fcPostTX = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcPostTX",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f006e3a4a21641f19c09c47406d66a88,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPostTX.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0f6b7a0518ac744 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0f6b7a0518ac744",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0f6b7a0518ac744.setDefaultUnit(voltmx.flex.DP);
            var lblPostTxScreen = new voltmx.ui.Label({
                "id": "lblPostTxScreen",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "Post Treatment",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblPostTxErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblPostTxErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0f6b7a0518ac744.add(lblPostTxScreen, lblPostTxErrormsg);
            fcPostTX.add(CopyFlexContainer0f6b7a0518ac744);
            var fcACOI = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "fcACOI",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_h0ba2bb3b5404c44aa75f60de936ab5d,
                "skin": "noSkinFC",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcACOI.setDefaultUnit(voltmx.flex.DP);
            var CopyFlexContainer0e24933d63b4840 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "CopyFlexContainer0e24933d63b4840",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "noSkinFcHBox",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            CopyFlexContainer0e24933d63b4840.setDefaultUnit(voltmx.flex.DP);
            var lblACOIDetails = new voltmx.ui.Label({
                "id": "lblACOIDetails",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblLeftPaneButtonNav",
                "text": "ACOI Details",
                "textStyle": {},
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 12, 3, 9],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblAcoiErrormsg = new voltmx.ui.Label({
                "bottom": "4%",
                "id": "lblAcoiErrormsg",
                "isVisible": true,
                "left": "0",
                "right": 0,
                "skin": "sknlblErrortxt",
                "textStyle": {},
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 1, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            CopyFlexContainer0e24933d63b4840.add(lblACOIDetails, lblAcoiErrormsg);
            fcACOI.add(CopyFlexContainer0e24933d63b4840);
            fcLeftPane.add(fcPatient, fcTreatment, fcOther, fcPostTX, fcACOI);
            var fcRightPane = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "fcRightPane",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknfcrightPane",
                "top": "0",
                "width": "66%",
                "zIndex": 1,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcRightPane.setDefaultUnit(voltmx.flex.DP);
            var fcTwo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": false,
                "height": "100px",
                "id": "fcTwo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "top": "20px",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTwo.setDefaultUnit(voltmx.flex.DP);
            var lblPatientNameCaptured = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPatientNameCaptured",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "text": "Patient Name:",
                "textStyle": {},
                "width": "27%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblCapturedPatientName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblCapturedPatientName",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblGreyFont80",
                "textStyle": {},
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            fcTwo.add(lblPatientNameCaptured, lblCapturedPatientName);
            var fcOne = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": false,
                "id": "fcOne",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknfcroundedcorner",
                "width": "96%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcOne.setDefaultUnit(voltmx.flex.DP);
            var fscTreatmentDetails = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "fscTreatmentDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "minHeight": "1400px",
                "pagingEnabled": false,
                "right": "0%",
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "noSkinFcScrollbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "96%"
            }, {
                "paddingInPixel": false
            }, {});
            fscTreatmentDetails.setDefaultUnit(voltmx.flex.DP);
            var fcTreatType = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcTreatType",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "minHeight": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcTreatType.setDefaultUnit(voltmx.flex.DP);
            var lblTretType = new voltmx.ui.Label({
                "bottom": 0,
                "id": "lblTretType",
                "isVisible": true,
                "left": "0dp",
                "right": 0,
                "skin": "sknlblGreyFont80",
                "text": "Treatment Type",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbTreatType = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbTreatType",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["0", "Hemodialysis"],
                    ["1", "PD"],
                    ["2", "CRRT"],
                    ["3", "Apheresis"],
                    ["4", "Cancellation"],
                    ["5", "Non Treatment Service"],
                    ["6", "Hemoperfusion"],
                    ["7", "Immunoabsorption"],
                    ["null", "Please Select..."]
                ],
                "right": "0%",
                "selectedKey": "null",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcTreatType.add(lblTretType, cmbTreatType);
            var fcCancelType = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcCancelType",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "minHeight": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcCancelType.setDefaultUnit(voltmx.flex.DP);
            var lblCancelType = new voltmx.ui.Label({
                "id": "lblCancelType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Cancel Type",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbCancelType = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbCancelType",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "0%",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcCancelType.add(lblCancelType, cmbCancelType);
            var fcHDtype = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcHDtype",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "minHeight": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcHDtype.setDefaultUnit(voltmx.flex.DP);
            var lblHDType = new voltmx.ui.Label({
                "id": "lblHDType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "HD Type",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbHDType = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbHDType",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "0%",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcHDtype.add(lblHDType, cmbHDType);
            var fcPDtype = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcPDtype",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "minHeight": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcPDtype.setDefaultUnit(voltmx.flex.DP);
            var lblPDType = new voltmx.ui.Label({
                "id": "lblPDType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "PD Type",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbPDType = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbPDType",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "0%",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcPDtype.add(lblPDType, cmbPDType);
            var fcCRTTtype = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcCRTTtype",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "minHeight": "100px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcCRTTtype.setDefaultUnit(voltmx.flex.DP);
            var lblCRRTtype = new voltmx.ui.Label({
                "id": "lblCRRTtype",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "CRRT Type",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbCRTTtype = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbCRTTtype",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "0%",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcCRTTtype.add(lblCRRTtype, cmbCRTTtype);
            var fcAphtype = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcAphtype",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "minHeight": "100px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcAphtype.setDefaultUnit(voltmx.flex.DP);
            var lblAphType = new voltmx.ui.Label({
                "id": "lblAphType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Apheresis Type",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbAphtype = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbAphtype",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "0%",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcAphtype.add(lblAphType, cmbAphtype);
            var fcAccess = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcAccess",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "minHeight": "100px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcAccess.setDefaultUnit(voltmx.flex.DP);
            var lblAccess = new voltmx.ui.Label({
                "id": "lblAccess",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "Access",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbAccessType = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbAccessType",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "0%",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcAccess.add(lblAccess, cmbAccessType);
            var fcHbsag = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcHbsag",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "minHeight": "100px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcHbsag.setDefaultUnit(voltmx.flex.DP);
            var lblHbsag = new voltmx.ui.Label({
                "id": "lblHbsag",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "HbsAg",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbHbsag = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbHbsag",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "0%",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcHbsag.add(lblHbsag, cmbHbsag);
            var fcHbsAb = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "1%",
                "clipBounds": false,
                "height": "120px",
                "id": "fcHbsAb",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "minHeight": "100px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcHbsAb.setDefaultUnit(voltmx.flex.DP);
            var lblHbsAb = new voltmx.ui.Label({
                "id": "lblHbsAb",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblGreyFont80",
                "text": "HbsAb",
                "textStyle": {},
                "top": "0",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cmbHbsab = new voltmx.ui.ListBox({
                "bottom": "0%",
                "focusSkin": "defListBoxFocus",
                "id": "cmbHbsab",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "0%",
                "skin": "skncmbWhiteBG",
                "top": "0",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            fcHbsAb.add(lblHbsAb, cmbHbsab);
            fscTreatmentDetails.add(fcTreatType, fcCancelType, fcHDtype, fcPDtype, fcCRTTtype, fcAphtype, fcAccess, fcHbsag, fcHbsAb);
            fcOne.add(fscTreatmentDetails);
            fcRightPane.add(fcTwo, fcOne);
            fcMain.add(fcLeftPane, fcRightPane);
            var fcappFooter = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "5%",
                "id": "fcappFooter",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            fcappFooter.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0ac17401cea3043 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "FlexContainer0ac17401cea3043",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0ac17401cea3043.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0eb12b1e1a9e845 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": 100,
                "id": "FlexContainer0eb12b1e1a9e845",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "33%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0eb12b1e1a9e845.setDefaultUnit(voltmx.flex.DP);
            var Label0b57e7188fec34d = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "Label0b57e7188fec34d",
                "isVisible": true,
                "left": 0,
                "skin": "defLabel",
                "textStyle": {},
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            FlexContainer0eb12b1e1a9e845.add(Label0b57e7188fec34d);
            var FlexContainer0g87434182ad74c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": 100,
                "id": "FlexContainer0g87434182ad74c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "66%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0g87434182ad74c.setDefaultUnit(voltmx.flex.DP);
            var btnSave = new voltmx.ui.Button({
                "bottom": "1%",
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "id": "btnSave",
                "isVisible": true,
                "left": "3%",
                "onClick": controller.AS_Button_d364b817e58344eab6fca7c420717199,
                "right": "0%",
                "skin": "sknbtnSave",
                "text": "Save",
                "top": "1%",
                "width": "24%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 2, 0, 2],
                "paddingInPixel": false
            }, {});
            var btnSubmit = new voltmx.ui.Button({
                "bottom": "1%",
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "id": "btnSubmit",
                "isVisible": true,
                "left": "3%",
                "right": "0%",
                "skin": "sknbtnSubmit",
                "text": "Submit",
                "top": "1%",
                "width": "24%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 2, 0, 2],
                "paddingInPixel": false
            }, {});
            var btnSubmit2 = new voltmx.ui.Button({
                "bottom": "1%",
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "id": "btnSubmit2",
                "isVisible": false,
                "left": "0%",
                "right": "0%",
                "skin": "sknbtnSubmit2",
                "text": "Button",
                "top": "1%",
                "width": "24%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDelete = new voltmx.ui.Button({
                "bottom": "1%",
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "id": "btnDelete",
                "isVisible": true,
                "left": "20%",
                "right": "3%",
                "skin": "sknbtnDelete",
                "text": "Delete",
                "top": "1%",
                "width": "24%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 2, 0, 2],
                "paddingInPixel": false
            }, {});
            FlexContainer0g87434182ad74c.add(btnSave, btnSubmit, btnSubmit2, btnDelete);
            FlexContainer0ac17401cea3043.add(FlexContainer0eb12b1e1a9e845, FlexContainer0g87434182ad74c);
            fcappFooter.add(FlexContainer0ac17401cea3043);
            this.add(fcMainHeader, fcMain, fcappFooter);
        };

        function preOrientfrmTreatmentDetails() {
            if (voltmx.os.getDeviceCurrentOrientation() == constants.DEVICE_ORIENTATION_PORTRAIT) {
                this.fcMain.top = '5%';
                this.forceLayout();
            } else if (voltmx.os.getDeviceCurrentOrientation() == constants.DEVICE_ORIENTATION_LANDSCAPE) {
                this.fcMain.top = 0;
                this.forceLayout();
            }
        }
        return [{
            "addWidgets": addWidgetsfrmTreatmentDetails,
            "enabledForIdleTimeout": false,
            "id": "frmTreatmentDetails",
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "postShow": controller.AS_Form_bd6ea424817741fba65e9d89a5044ac3,
            "preShow": function(eventobject) {
                controller.AS_Form_af1edc76653848f8b0591f958548c5fa(eventobject);
            },
            "skin": "sknform",
            "preOrientationChange": preOrientfrmTreatmentDetails,
            "appName": "AMII"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_BOTH,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});