// define(['require/utils'], function(Utils){
define("userfrmPatientDetailsController", {
    populateListBoxFromObject: function(objectName, listBoxName, keyField, valueField, targetForm) {
        if (!targetForm) {
            voltmx.print("Target Form is not defined");
            return;
        }
        var callbackSuccess = function(response) {
            voltmx.print("******In " + objectName + " Callback********");
            this.populateListBox(response, listBoxName, keyField, valueField, targetForm, objectName);
        }.bind(this); // Very important: bind 'this'
        var callbackFail = function(error) {
            voltmx.print("unable to retrieve records from db" + error.code);
            console.log(error);
        }
        var ofl_objectName = new voltmx.sdk.VMXObj(objectName);
        // 	var ref_CRRTType_Desc = new voltmx.sdk.VMXObj("Ref_Room_Type_Desc");
        // all records of object are returned as an argument to success callback.
        ofl_objectName.get(null, callbackSuccess, callbackFail);
    },
    populateListBoxFromService: function(serviceName, operationName, inputParams, listBoxName, keyField, valueField, targetForm) {
        voltmx.print("Getting Hospital Data for Nurse: " + inputParams);
        if (!targetForm) {
            voltmx.print("Target Form is not defined");
            return;
        }
        var headers;
        var params = {
            "nurseID": inputParams
        };
        var serviceSuccessCallback = function(response) {
            if (response && response.opstatus === 0) { // Added response check
                this.populateListBox(response, listBoxName, keyField, valueField, targetForm, serviceName);
            } else {
                voltmx.print(objectName + " Callback - Error: " + JSON.stringify(response));
            }
        }.bind(this); // Very important: bind 'this'
        try {
            var integrationSvc = voltmx.sdk.getCurrentInstance().getIntegrationService(serviceName);
            var options = {
                "httpRequestOptions": {
                    "timeoutIntervalForRequest": 60,
                    "timeoutIntervalForResource": 600
                }
            };
            integrationSvc.invokeOperation(operationName, headers, params, function(response) {
                voltmx.print("Integration Service Response is: " + JSON.stringify(response));
                serviceSuccessCallback(response);
            }, function(error) {
                voltmx.print("Integration Service Failure:" + JSON.stringify(error));
            }, options);
        } catch (exception) {
            console.log("Exception invoking service: " + exception); //         voltmx.print("Exception invoking service: " + JSON.stringify(exception));
        }
    },
    populateListBox: function(response, listBoxName, keyField, valueField, targetForm, objectName) {
        var listData = [];
        var data = response; // Access data using response.records
        if (data && data.length > 0) { // Check if data exists AND is not empty
            listData.push(["null", "Please Select..."]);
            for (var i = 0; i < data.length; i++) {
                var item = data[i];
                var key = item[keyField];
                var value = item[valueField];
                listData.push([key, value]);
                voltmx.print(key + " - " + value);
            }
            targetForm[listBoxName].masterData = listData;
        } else {
            voltmx.print("No data received from service for " + objectName);
        }
    },
    populateDivisionListBox: function(context) {
        var grpSelKey = this.view.cmbGroup.selectedKeyValue[0];
        voltmx.print("In getdivID - Getting Divisions from Group - " + grpSelKey);
        if (grpSelKey != null) {
            //       var query = "select d.DivisionID, d.Division_Desc from  Ref_GroupDivisionMappingInfo g, Ref_Division_Desc d where g.DivisionID = d.DivisionID and g.GroupID ='"+grpSelKey+"' order by d.Division_Desc";	
            //       var query = "select d.DivisionID, d.Division_Desc from  Ref_Division_Desc d where d.DivisionID = '98'" ;	
            var query = "select * from Ref_Group_Desc";
            voltmx.print(query);
            var successCallback = function(response) {
                this.populateListBox(response, "cmbDivision", "DivisionID", "Division_Desc", this.view, "Ref_GroupDivisionMappingInfo-join-Ref_Division_Desc");
            }
            var failureCallback = function(error) {
                voltmx.print("executeSelectQuery failed with error:" + error.code);
                console.log(error);
            }
            VMXFoundry.OfflineObjects.executeSelectQuery(query, successCallback, failureCallback);
        }
    },
    onFormPatientDetailsPreShow: function(context) {
        voltmx.print("In frmPatientDetails preShow");
        if (this.view) {
            this.view.fcpopupHospitalSearch.setVisibility = false;
            gblNurseUserID = 637700915;
            if (gblNurseUserID && gblNurseUserID !== null) {
                this.populateListBoxFromService("NurseService", "getHosptalsForNurseID", gblNurseUserID, "cmbHospital", "HospitalID", "Hospital_Desc", this.view);
            } else {
                voltmx.print("Global variable gblNurseUserID is not set");
            }
            this.populateListBoxFromObject("Ref_Room_Type_Desc", "cmbRoomType", "Room_TypeID", "Room_Type_Desc", this.view);
            this.populateListBoxFromObject("Ref_Group_Desc", "cmbGroup", "GroupID", "Group_Desc", this.view);
            //       this.populateListBoxFromObject("Ref_Division_Desc", "cmbDivision", "DivisionD", "Division_Desc", this.view);
            //       this.populateListBoxFromObject("Ref_Region_Desc", "cmbRegion", "RegionID", "Region_Desc", this.view);
        } else {
            voltmx.print("this.view is undefined. Cannot populate listboxes.");
        }
    }
});
define("frmPatientDetailsControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_a28d2fa27f464f3cbad7591d1bfe22d5: function AS_Button_a28d2fa27f464f3cbad7591d1bfe22d5(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    },
    AS_ListBox_fe3acfb2285d4456ac78699ad0a38a4a: function AS_ListBox_fe3acfb2285d4456ac78699ad0a38a4a(eventobject) {
        var self = this;
        return self.populateDivisionListBox.call(this, null);
    },
    AS_FlexContainer_e1e98b4ed818484d807c907627358124: function AS_FlexContainer_e1e98b4ed818484d807c907627358124(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frnACOI"
        });
        ntf.navigate();
    },
    AS_FlexContainer_f19beae0f091477aad9acdafb2ee3a25: function AS_FlexContainer_f19beae0f091477aad9acdafb2ee3a25(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frnOtherDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_h2ae983dff6d4f019e24c742d7419e14: function AS_FlexContainer_h2ae983dff6d4f019e24c742d7419e14(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPatientDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_a296ac9a63c1428190a8049b93d7c15f: function AS_FlexContainer_a296ac9a63c1428190a8049b93d7c15f(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPostTX"
        });
        ntf.navigate();
    },
    AS_FlexContainer_adf3c6e6080d4de591053967485c170c: function AS_FlexContainer_adf3c6e6080d4de591053967485c170c(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    },
    AS_Form_i386ac18cbe543cba4f3bc0e85348c1f: function AS_Form_i386ac18cbe543cba4f3bc0e85348c1f(eventobject) {
        var self = this;
    },
    AS_Form_d6695b5549d6428eb19178f9161badfb: function AS_Form_d6695b5549d6428eb19178f9161badfb(eventobject) {
        var self = this;
    },
    AS_Form_abe7caa7ee744c28840c016c4492109a: function AS_Form_abe7caa7ee744c28840c016c4492109a(eventobject) {
        var self = this;
        return self.onFormPatientDetailsPreShow.call(this, null);
    }
});
define("frmPatientDetailsController", ["userfrmPatientDetailsController", "frmPatientDetailsControllerActions"], function() {
    var controller = require("userfrmPatientDetailsController");
    var controllerActions = ["frmPatientDetailsControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
