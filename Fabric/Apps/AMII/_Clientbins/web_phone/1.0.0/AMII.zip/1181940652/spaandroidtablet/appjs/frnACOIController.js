define("userfrnACOIController", {
    //Type your controller code here 
});
define("frnACOIControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_c51a6ba1f64c429da2f75cdcfb0d88a8: function AS_FlexContainer_c51a6ba1f64c429da2f75cdcfb0d88a8(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frnOtherDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_dd6962c7274344ca87f997e472f38bf5: function AS_FlexContainer_dd6962c7274344ca87f997e472f38bf5(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPatientDetails"
        });
        ntf.navigate();
    },
    AS_FlexContainer_g830f6b6c5424a69b0bc9d90a4c43fa3: function AS_FlexContainer_g830f6b6c5424a69b0bc9d90a4c43fa3(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmPostTX"
        });
        ntf.navigate();
    },
    AS_FlexContainer_h760cd0b348745e6967ff8de0b477a4c: function AS_FlexContainer_h760cd0b348745e6967ff8de0b477a4c(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "AMII",
            "friendlyName": "frmTreatmentDetails"
        });
        ntf.navigate();
    }
});
define("frnACOIController", ["userfrnACOIController", "frnACOIControllerActions"], function() {
    var controller = require("userfrnACOIController");
    var controllerActions = ["frnACOIControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
