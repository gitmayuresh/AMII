define("userfrmLoginController", {
    /*
     **************************************************
     *  Name    : login_Click
     *  Purpose : Checks the presence of NurseUserName 
     *            in device DB RefNurseDesc table
     ****************************************************
     */
    login_Click: function() {
        var userName = this.view.txtUsername.text; // Access the username from the form's text field
        // Check if username is empty or invalid
        if (!userName || userName === "") {
            voltmx.ui.Alert({
                message: voltmx.i18n.getLocalizedString("i18n_EnterValidTeammate_Msg"),
                alertType: constants.ALERT_TYPE_INFO,
                alertTitle: "",
                yesLabel: voltmx.i18n.getLocalizedString("i18n_AlertOK"),
                noLabel: "",
                alertHandler: null
            }, {});
        } else if ((userName.indexOf(".") !== -1) || (userName.indexOf(",") !== -1)) {
            voltmx.ui.Alert({
                message: voltmx.i18n.getLocalizedString("i18n_EnterValidTeammate_Msg"),
                alertType: constants.ALERT_TYPE_INFO,
                alertTitle: "",
                yesLabel: voltmx.i18n.getLocalizedString("i18n_AlertOK"),
                noLabel: "",
                alertHandler: null
            }, {});
        } else {
            try {
                // Setting up input parameters for service call
                var Ref_Nurse_Desc_inputparam = {};
                Ref_Nurse_Desc_inputparam["serviceID"] = "InBound$Ref_Nurse_Desc$get";
                Ref_Nurse_Desc_inputparam["options"] = {
                    "access": "online",
                    "CRUD_TYPE": "get"
                };
                var odataParams = [];
                var filters = [];
                filters.push("Nurse_UserName eq '" + userName + "'");
                odataParams.push("$filter=" + filters.join(' and '));
                Ref_Nurse_Desc_inputparam["options"]["odataurl"] = odataParams.join("&");
                var Ref_Nurse_Desc_httpheaders = {};
                Ref_Nurse_Desc_inputparam["httpheaders"] = Ref_Nurse_Desc_httpheaders;
                var Ref_Nurse_Desc_httpconfigs = {};
                Ref_Nurse_Desc_inputparam["httpconfig"] = Ref_Nurse_Desc_httpconfigs;
                // Making the service call
                mfobjectsecureinvokerasync(Ref_Nurse_Desc_inputparam, "InBound", "Ref_Nurse_Desc", this.Ref_Nurse_Desc_Callback.bind(this));
            } catch (e) {
                voltmx.ui.Alert({
                    message: "Unknown Teammate ID"
                }, {});
            }
        }
    },
    // Callback function to handle response from service call
    Ref_Nurse_Desc_Callback: function(Ref_Nurse_Desc) {
        voltmx.print("******In Ref_Nurse_Desc_Callback********");
        if (Ref_Nurse_Desc.opstatus == 0) {
            if (Ref_Nurse_Desc.records && Ref_Nurse_Desc.records.length > 0) {
                gblNurseUserID = Ref_Nurse_Desc.records[0].NurseID;
                gblNurseName = Ref_Nurse_Desc.records[0].Nurse_UserName;
                gblNurseDescription = Ref_Nurse_Desc.records[0].Description;
                voltmx.print(gblNurseUserID + "--" + gblNurseName + "--" + gblNurseDescription);
                this.LoginTransmitOperation();
            } else {
                gblNurseUserID = this.view.txtUsername.text;
                voltmx.ui.Alert({
                    message: voltmx.i18n.getLocalizedString("i18n_EnterTreatmentsUsing_Msg"),
                    alertType: constants.ALERT_TYPE_CONFIRMATION,
                    alertTitle: "Invalid Teammate ID",
                    yesLabel: "Yes",
                    noLabel: "No",
                    alertHandler: this.alertCallback.bind(this) // Binding `this` to the current context
                }, {});
            }
        } else {
            // Error case: If opstatus is not 0
            voltmx.ui.Alert({
                message: "Unknown Teammate ID"
            }, {});
        }
    },
    // Alert callback to handle user's response
    alertCallback: function(response) {
        if (response) {
            this.LoginTransmitOperation();
        }
    },
    // Method to handle login and transmit operation
    LoginTransmitOperation: function() {
        try {
            var ntf = new voltmx.mvc.Navigation("frmHome");
            ntf.navigate();
        } catch (e) {
            console.log(e);
            var ntf = new voltmx.mvc.Navigation("frmHome");
            ntf.navigate();
        }
    },
    /*
     **************************************************
     *  Name    : Start_Sync
     *  Purpose : Start Sync Process
     ****************************************************
     */
    Start_Sync: function() {
        if (voltmx.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
            if (!gbl_IsDownloadSyncInProgress) {
                gbl_IsDownloadSyncInProgress = true;
                syncStartSession(true, false, voltmx.i18n.getLocalizedString("i18n_Sync_Msg")); // Download true, no upload
            }
        } else {
            this.loadLookupData(); // Load master data even without connectivity
        }
    }
});
define("frmLoginControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_iff0dcb0e76c49e3906a78f9a2e44ee5: function AS_Button_iff0dcb0e76c49e3906a78f9a2e44ee5(eventobject) {
        var self = this;
        return self.login_Click.call(this);
    }
});
define("frmLoginController", ["userfrmLoginController", "frmLoginControllerActions"], function() {
    var controller = require("userfrmLoginController");
    var controllerActions = ["frmLoginControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
