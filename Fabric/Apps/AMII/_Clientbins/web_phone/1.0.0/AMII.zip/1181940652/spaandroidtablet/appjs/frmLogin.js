define("frmLogin", function() {
    return function(controller) {
        function addWidgetsfrmLogin() {
            this.setDefaultUnit(voltmx.flex.DP);
            var FlexGroup0g1a6a9b65f1941 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "10%",
                "id": "FlexGroup0g1a6a9b65f1941",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexGroup0g1a6a9b65f1941.setDefaultUnit(voltmx.flex.DP);
            var FlexGroup0g0517ed9b2d648 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "84.58%",
                "id": "FlexGroup0g0517ed9b2d648",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25%",
                "width": "100%",
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexGroup0g0517ed9b2d648.setDefaultUnit(voltmx.flex.DP);
            var lblAcutes = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "lblAcutes",
                "isVisible": true,
                "skin": "CopydefLabel0h4322da48ecc41",
                "text": "A C U T E S",
                "textStyle": {},
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblChargeCapture = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "lblChargeCapture",
                "isVisible": true,
                "skin": "CopydefLabel0g151d9d6881349",
                "text": "C H A R G E   C A P T U R E",
                "textStyle": {},
                "top": "15px",
                "width": "100%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            FlexGroup0g0517ed9b2d648.add(lblAcutes, lblChargeCapture);
            var FlexGroup0d76c7f8cfa2048 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "40%",
                "id": "FlexGroup0d76c7f8cfa2048",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 10,
                "width": "100%",
                "zIndex": 2,
                "appName": "AMII"
            }, {
                "paddingInPixel": false
            }, {});
            FlexGroup0d76c7f8cfa2048.setDefaultUnit(voltmx.flex.DP);
            var txtUsername = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "0dp",
                "centerX": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtUsername",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Teammate ID",
                "right": 0,
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0e87e64dfa06a44",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "top": "0dp",
                "width": "46%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var btnLogin = new voltmx.ui.Button({
                "bottom": "0",
                "centerX": "50%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnLogin",
                "isVisible": true,
                "left": "0dp",
                "onClick": controller.AS_Button_iff0dcb0e76c49e3906a78f9a2e44ee5,
                "skin": "CopydefBtnNormal0b3188797e1da4d",
                "top": 10,
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexGroup0d76c7f8cfa2048.add(txtUsername, btnLogin);
            FlexGroup0g1a6a9b65f1941.add(FlexGroup0g0517ed9b2d648, FlexGroup0d76c7f8cfa2048);
            this.add(FlexGroup0g1a6a9b65f1941);
        };
        return [{
            "addWidgets": addWidgetsfrmLogin,
            "enabledForIdleTimeout": false,
            "id": "frmLogin",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "CopyslForm0f51b4fbbe73940",
            "appName": "AMII"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_BOTH,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});