//
//  LogListener.h
//  KonyLogger
//
typedef void(^LogListener)(NSArray<NSString *> *logs);
